import React, { createContext, useContext, useState, useEffect } from 'react';
import { type Currency } from '../utils/currency';

interface CurrencyContextType {
  globalCurrency: Currency;
  setGlobalCurrency: (currency: Currency) => void;
  formatAmount: (amount: number) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [globalCurrency, setGlobalCurrency] = useState<Currency>('XOF');

  // Charger la devise depuis le localStorage au démarrage
  useEffect(() => {
    const savedCurrency = localStorage.getItem('cabinet-currency');
    if (savedCurrency && ['XOF', 'USD', 'EUR', 'CDF'].includes(savedCurrency)) {
      setGlobalCurrency(savedCurrency as Currency);
    }
  }, []);

  // Sauvegarder la devise dans le localStorage quand elle change
  const updateGlobalCurrency = (currency: Currency) => {
    setGlobalCurrency(currency);
    localStorage.setItem('cabinet-currency', currency);
  };

  // Fonction de formatage globale
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: globalCurrency,
      minimumFractionDigits: globalCurrency === 'XOF' || globalCurrency === 'CDF' ? 0 : 2
    }).format(amount);
  };

  return (
    <CurrencyContext.Provider value={{
      globalCurrency,
      setGlobalCurrency: updateGlobalCurrency,
      formatAmount
    }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}