import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, AuthState } from '../types';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (user: User) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Utilisateurs de démonstration
const mockUsers: User[] = [
  {
    id: '1',
    nom: 'KOUAME',
    prenom: 'Jean-Baptiste',
    email: 'jb.kouame@caccompta.ci',
    password: 'admin123',
    role: 'expert-comptable',
    statut: 'actif',
    dateCreation: new Date('2020-01-15'),
    derniereConnexion: new Date(),
    permissions: ['all'],
    telephone: '+225 27 20 12 34 56',
    numeroOrdre: 'OEC-CI-2020-456',
    cabinet: 'Cabinet KOUAME & Associés'
  },
  {
    id: '2',
    nom: 'TRAORE',
    prenom: 'Aminata',
    email: 'a.traore@caccompta.ci',
    password: 'assistant123',
    role: 'assistant',
    statut: 'actif',
    dateCreation: new Date('2021-03-10'),
    derniereConnexion: new Date(),
    permissions: ['clients', 'ecritures', 'facturation'],
    telephone: '+225 27 21 45 67 89'
  },
  {
    id: '3',
    nom: 'DIALLO',
    prenom: 'Mamadou',
    email: 'm.diallo@caccompta.ci',
    password: 'stagiaire123',
    role: 'stagiaire',
    statut: 'actif',
    dateCreation: new Date('2023-09-01'),
    derniereConnexion: new Date(),
    permissions: ['ecritures'],
    telephone: '+225 07 12 34 56 78'
  },
  {
    id: '4',
    nom: 'ADMIN',
    prenom: 'Système',
    email: 'admin@caccompta.ci',
    password: 'admin2024',
    role: 'admin',
    statut: 'actif',
    dateCreation: new Date('2020-01-01'),
    derniereConnexion: new Date(),
    permissions: ['all'],
    cabinet: 'Administration Système'
  }
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    loading: true
  });

  // Vérifier si l'utilisateur est déjà connecté au démarrage
  useEffect(() => {
    const savedUser = localStorage.getItem('caccompta-user');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        setAuthState({
          isAuthenticated: true,
          user,
          loading: false
        });
      } catch (error) {
        localStorage.removeItem('caccompta-user');
        setAuthState({
          isAuthenticated: false,
          user: null,
          loading: false
        });
      }
    } else {
      setAuthState(prev => ({ ...prev, loading: false }));
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setAuthState(prev => ({ ...prev, loading: true }));

    // Simulation d'une requête de connexion
    await new Promise(resolve => setTimeout(resolve, 1000));

    const user = mockUsers.find(u => 
      u.email.toLowerCase() === email.toLowerCase() && 
      u.password === password &&
      u.statut === 'actif'
    );

    if (user) {
      const updatedUser = {
        ...user,
        derniereConnexion: new Date()
      };

      localStorage.setItem('caccompta-user', JSON.stringify(updatedUser));
      
      setAuthState({
        isAuthenticated: true,
        user: updatedUser,
        loading: false
      });
      
      return true;
    } else {
      setAuthState({
        isAuthenticated: false,
        user: null,
        loading: false
      });
      
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('caccompta-user');
    setAuthState({
      isAuthenticated: false,
      user: null,
      loading: false
    });
  };

  const updateUser = (user: User) => {
    localStorage.setItem('caccompta-user', JSON.stringify(user));
    setAuthState(prev => ({
      ...prev,
      user
    }));
  };

  return (
    <AuthContext.Provider value={{
      ...authState,
      login,
      logout,
      updateUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export { mockUsers };