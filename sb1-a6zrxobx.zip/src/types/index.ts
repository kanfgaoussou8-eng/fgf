export interface Client {
  id: string;
  nom: string;
  raisonSociale: string;
  secteurActivite: string;
  numeroContribuable: string;
  adresse: string;
  telephone: string;
  email: string;
  dateCreation: Date;
  responsableComptable: string;
  statut: 'actif' | 'inactif' | 'suspendu';
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
  tauxChange?: number; // Taux de change par rapport au XOF
}

export interface CompteComptable {
  numero: string;
  intitule: string;
  classe: number;
  type: 'debit' | 'credit';
  solde: number;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface EcritureComptable {
  id: string;
  clientId: string;
  dateEcriture: Date;
  numeroJournal: string;
  libelle: string;
  reference: string;
  lignes: LigneEcriture[];
  statut: 'brouillon' | 'validee' | 'cloturee';
  createdBy: string;
  createdAt: Date;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface LigneEcriture {
  id: string;
  compteNumero: string;
  compteIntitule: string;
  debit: number;
  credit: number;
  libelle: string;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface EtatFinancier {
  id: string;
  clientId: string;
  type: 'bilan' | 'compte-resultat' | 'tafire' | 'tableau-tresorerie';
  exercice: string;
  dateGeneration: Date;
  donnees: any;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface Facture {
  id: string;
  clientId: string;
  numeroFacture: string;
  dateEmission: Date;
  dateEcheance: Date;
  montantHT: number;
  tva: number;
  montantTTC: number;
  statut: 'brouillon' | 'envoyee' | 'payee' | 'impayee';
  services: ServiceFacture[];
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface ServiceFacture {
  id: string;
  description: string;
  quantite: number;
  prixUnitaire: number;
  montantHT: number;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface DeclarationFiscale {
  id: string;
  clientId: string;
  type: 'tva' | 'impot-societe' | 'patente' | 'cnss';
  periode: string;
  dateEcheance: Date;
  statut: 'a-faire' | 'en-cours' | 'deposee' | 'retard';
  montant?: number;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface Immobilisation {
  id: string;
  clientId: string;
  designation: string;
  categorie: 'terrain' | 'batiment' | 'materiel' | 'transport' | 'mobilier' | 'informatique' | 'incorporel';
  dateAcquisition: Date;
  valeurAcquisition: number;
  dureeAmortissement: number;
  tauxAmortissement: number;
  amortissementCumule: number;
  valeurNetteComptable: number;
  compteImmobilisation: string;
  compteAmortissement: string;
  statut: 'en-service' | 'cede' | 'reforme' | 'en-cours';
  numeroInventaire?: string;
  fournisseur?: string;
  numeroFacture?: string;
  exerciceAcquisition: string;
  methodeAmortissement: 'lineaire' | 'degressif' | 'variable';
  observations?: string;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
}

export interface User {
  id: string;
  nom: string;
  prenom: string;
  email: string;
  password: string;
  role: 'expert-comptable' | 'assistant' | 'stagiaire' | 'admin';
  statut: 'actif' | 'inactif' | 'suspendu';
  dateCreation: Date;
  derniereConnexion?: Date;
  permissions: string[];
  telephone?: string;
  numeroOrdre?: string;
  cabinet?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
}