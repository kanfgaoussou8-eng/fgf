export type Currency = 'XOF' | 'USD' | 'EUR' | 'CDF';

export interface CurrencyInfo {
  code: Currency;
  name: string;
  symbol: string;
  flag: string;
  country: string;
  decimals: number;
}

export const CURRENCIES: Record<Currency, CurrencyInfo> = {
  XOF: {
    code: 'XOF',
    name: 'Franc CFA (BCEAO)',
    symbol: 'FCFA',
    flag: '🇨🇮',
    country: 'Zone UEMOA',
    decimals: 0
  },
  USD: {
    code: 'USD',
    name: 'Dollar Américain',
    symbol: '$',
    flag: '🇺🇸',
    country: 'États-Unis',
    decimals: 2
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    flag: '🇪🇺',
    country: 'Zone Euro',
    decimals: 2
  },
  CDF: {
    code: 'CDF',
    name: 'Franc Congolais',
    symbol: 'FC',
    flag: '🇨🇩',
    country: 'RD Congo',
    decimals: 0
  }
};

// Taux de change par rapport au XOF (Franc CFA)
export const EXCHANGE_RATES: Record<Currency, number> = {
  XOF: 1, // Base
  USD: 0.0016, // 1 USD ≈ 620 XOF
  EUR: 0.0015, // 1 EUR ≈ 655 XOF
  CDF: 1.35 // 1 CDF ≈ 0.74 XOF
};

export class CurrencyFormatter {
  static formatAmount(amount: number, currency: Currency): string {
    const currencyInfo = CURRENCIES[currency];
    
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: currencyInfo.decimals,
      maximumFractionDigits: currencyInfo.decimals
    }).format(amount);
  }

  static formatAmountWithSymbol(amount: number, currency: Currency): string {
    const currencyInfo = CURRENCIES[currency];
    const formattedNumber = new Intl.NumberFormat('fr-FR', {
      minimumFractionDigits: currencyInfo.decimals,
      maximumFractionDigits: currencyInfo.decimals
    }).format(amount);
    
    return `${formattedNumber} ${currencyInfo.symbol}`;
  }

  static convertCurrency(amount: number, fromCurrency: Currency, toCurrency: Currency): number {
    if (fromCurrency === toCurrency) return amount;
    
    // Convertir d'abord vers XOF (base)
    const amountInXOF = amount / EXCHANGE_RATES[fromCurrency];
    
    // Puis vers la devise cible
    return amountInXOF * EXCHANGE_RATES[toCurrency];
  }

  static getCurrencyInfo(currency: Currency): CurrencyInfo {
    return CURRENCIES[currency];
  }

  static getAllCurrencies(): CurrencyInfo[] {
    return Object.values(CURRENCIES);
  }

  static formatExchangeRate(fromCurrency: Currency, toCurrency: Currency): string {
    if (fromCurrency === toCurrency) return '1:1';
    
    const rate = EXCHANGE_RATES[toCurrency] / EXCHANGE_RATES[fromCurrency];
    return `1 ${CURRENCIES[fromCurrency].symbol} = ${rate.toFixed(4)} ${CURRENCIES[toCurrency].symbol}`;
  }
}