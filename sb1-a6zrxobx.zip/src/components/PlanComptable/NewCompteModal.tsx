import React, { useState } from 'react';
import { X, BookOpen, Save, AlertCircle, Calculator, Hash } from 'lucide-react';
import type { CompteComptable } from '../../types';

interface NewCompteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (compte: CompteComptable) => void;
}

const classesComptables = [
  { 
    numero: 1, 
    titre: 'Comptes de Ressources Durables',
    description: 'Capital, réserves, emprunts à long terme',
    typeDefaut: 'credit',
    exemples: ['101 - Capital social', '106 - Réserves', '16 - Emprunts']
  },
  { 
    numero: 2, 
    titre: 'Comptes d\'Actif Immobilisé',
    description: 'Immobilisations corporelles et incorporelles',
    typeDefaut: 'debit',
    exemples: ['22 - Terrains', '23 - Bâtiments', '24 - Matériel']
  },
  { 
    numero: 3, 
    titre: 'Comptes de Stocks',
    description: 'Stocks de marchandises, matières premières',
    typeDefaut: 'debit',
    exemples: ['31 - Matières premières', '35 - Produits finis', '37 - Marchandises']
  },
  { 
    numero: 4, 
    titre: 'Comptes de Tiers',
    description: 'Clients, fournisseurs, personnel, État',
    typeDefaut: 'debit',
    exemples: ['401 - Fournisseurs', '411 - Clients', '443 - TVA facturée']
  },
  { 
    numero: 5, 
    titre: 'Comptes de Trésorerie',
    description: 'Banques, caisse, valeurs mobilières',
    typeDefaut: 'debit',
    exemples: ['52 - Banques', '57 - Caisse', '531 - Chèques postaux']
  },
  { 
    numero: 6, 
    titre: 'Comptes de Charges',
    description: 'Achats, services extérieurs, charges de personnel',
    typeDefaut: 'debit',
    exemples: ['601 - Achats', '62 - Services extérieurs', '66 - Charges personnel']
  },
  { 
    numero: 7, 
    titre: 'Comptes de Produits',
    description: 'Ventes, prestations de services, produits financiers',
    typeDefaut: 'credit',
    exemples: ['701 - Ventes marchandises', '706 - Services vendus', '77 - Revenus financiers']
  },
  { 
    numero: 8, 
    titre: 'Comptes Spéciaux',
    description: 'Comptes de résultat, engagements hors bilan',
    typeDefaut: 'debit',
    exemples: ['89 - Bilan', '80 - Engagements donnés']
  }
];

const comptesExistants = [
  '10', '101', '106', '12', '13', '16',
  '20', '21', '22', '23', '24', '245', '246',
  '31', '32', '33', '35', '37',
  '401', '411', '421', '422', '431', '441', '443', '445',
  '52', '521', '531', '57',
  '60', '601', '602', '61', '62', '63', '64', '66', '68',
  '70', '701', '702', '706', '75', '77'
];

export default function NewCompteModal({ isOpen, onClose, onSave }: NewCompteModalProps) {
  const [formData, setFormData] = useState({
    numero: '',
    intitule: '',
    classe: '',
    type: 'debit' as 'debit' | 'credit',
    soldeInitial: '',
    description: '',
    actif: true
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Auto-remplissage selon la classe sélectionnée
    if (name === 'classe' && value) {
      const classeInfo = classesComptables.find(c => c.numero.toString() === value);
      if (classeInfo) {
        setFormData(prev => ({
          ...prev,
          type: classeInfo.typeDefaut as 'debit' | 'credit'
        }));
      }
    }

    // Validation en temps réel du numéro de compte
    if (name === 'numero') {
      // Extraire la classe du numéro de compte
      const premierChiffre = value.charAt(0);
      if (premierChiffre && /[1-8]/.test(premierChiffre)) {
        setFormData(prev => ({
          ...prev,
          classe: premierChiffre
        }));
        
        const classeInfo = classesComptables.find(c => c.numero.toString() === premierChiffre);
        if (classeInfo) {
          setFormData(prev => ({
            ...prev,
            type: classeInfo.typeDefaut as 'debit' | 'credit'
          }));
        }
      }
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Validation du numéro de compte
    if (!formData.numero.trim()) {
      newErrors.numero = 'Le numéro de compte est obligatoire';
    } else {
      // Vérifier le format (doit commencer par un chiffre de 1 à 8)
      if (!/^[1-8]\d*$/.test(formData.numero)) {
        newErrors.numero = 'Le numéro doit commencer par un chiffre de 1 à 8';
      }
      
      // Vérifier l'unicité
      if (comptesExistants.includes(formData.numero)) {
        newErrors.numero = 'Ce numéro de compte existe déjà';
      }
      
      // Validation de la longueur
      if (formData.numero.length > 10) {
        newErrors.numero = 'Le numéro ne peut pas dépasser 10 caractères';
      }
    }

    // Validation de l'intitulé
    if (!formData.intitule.trim()) {
      newErrors.intitule = 'L\'intitulé du compte est obligatoire';
    } else if (formData.intitule.length < 3) {
      newErrors.intitule = 'L\'intitulé doit contenir au moins 3 caractères';
    } else if (formData.intitule.length > 100) {
      newErrors.intitule = 'L\'intitulé ne peut pas dépasser 100 caractères';
    }

    // Validation de la classe
    if (!formData.classe) {
      newErrors.classe = 'La classe comptable est obligatoire';
    }

    // Validation du solde initial
    if (formData.soldeInitial && parseFloat(formData.soldeInitial) < 0) {
      newErrors.soldeInitial = 'Le solde initial ne peut pas être négatif';
    }

    // Validation de cohérence classe/numéro
    if (formData.numero && formData.classe) {
      const premierChiffre = formData.numero.charAt(0);
      if (premierChiffre !== formData.classe) {
        newErrors.numero = `Le numéro doit commencer par ${formData.classe} pour la classe ${formData.classe}`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const nouveauCompte: CompteComptable = {
        numero: formData.numero.trim(),
        intitule: formData.intitule.trim(),
        classe: parseInt(formData.classe),
        type: formData.type,
        solde: formData.soldeInitial ? parseFloat(formData.soldeInitial) : 0
      };

      onSave(nouveauCompte);
      onClose();
      
      // Reset form
      setFormData({
        numero: '',
        intitule: '',
        classe: '',
        type: 'debit',
        soldeInitial: '',
        description: '',
        actif: true
      });
      setErrors({});
    } catch (error) {
      console.error('Erreur lors de la création du compte:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getClasseInfo = () => {
    return classesComptables.find(c => c.numero.toString() === formData.classe);
  };

  const formatMontant = (montant: string) => {
    if (!montant) return '';
    const num = parseFloat(montant);
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(num);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouveau Compte Comptable</h3>
                <p className="text-sm text-gray-600">Ajouter un compte au plan comptable OHADA</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Informations de base */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Hash className="h-5 w-5 mr-2 text-blue-600" />
              Informations de base
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro de compte <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="numero"
                  value={formData.numero}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.numero ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: 2441, 701, 6611"
                  maxLength={10}
                />
                {errors.numero && <p className="text-red-500 text-xs mt-1">{errors.numero}</p>}
                <p className="text-xs text-gray-500 mt-1">
                  Le numéro doit commencer par le chiffre de la classe (1-8)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Classe comptable <span className="text-red-500">*</span>
                </label>
                <select
                  name="classe"
                  value={formData.classe}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.classe ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner une classe</option>
                  {classesComptables.map(classe => (
                    <option key={classe.numero} value={classe.numero}>
                      Classe {classe.numero} - {classe.titre}
                    </option>
                  ))}
                </select>
                {errors.classe && <p className="text-red-500 text-xs mt-1">{errors.classe}</p>}
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Intitulé du compte <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="intitule"
                  value={formData.intitule}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.intitule ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: Matériel informatique et bureautique"
                  maxLength={100}
                />
                {errors.intitule && <p className="text-red-500 text-xs mt-1">{errors.intitule}</p>}
                <p className="text-xs text-gray-500 mt-1">
                  {formData.intitule.length}/100 caractères
                </p>
              </div>
            </div>
          </div>

          {/* Informations sur la classe sélectionnée */}
          {formData.classe && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h5 className="font-medium text-blue-900 mb-2 flex items-center">
                <BookOpen className="h-4 w-4 mr-2" />
                Classe {formData.classe} - {getClasseInfo()?.titre}
              </h5>
              <p className="text-sm text-blue-800 mb-3">
                {getClasseInfo()?.description}
              </p>
              <div>
                <p className="text-sm font-medium text-blue-900 mb-1">Exemples de comptes dans cette classe :</p>
                <ul className="text-sm text-blue-700 space-y-1">
                  {getClasseInfo()?.exemples.map((exemple, index) => (
                    <li key={index}>• {exemple}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Paramètres comptables */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calculator className="h-5 w-5 mr-2 text-green-600" />
              Paramètres comptables
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nature du compte <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'debit' }))}
                    className={`p-4 border-2 rounded-lg flex items-center justify-center space-x-2 transition-colors ${
                      formData.type === 'debit'
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <span className="font-medium">Débiteur</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'credit' }))}
                    className={`p-4 border-2 rounded-lg flex items-center justify-center space-x-2 transition-colors ${
                      formData.type === 'credit'
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <span className="font-medium">Créditeur</span>
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  {formData.type === 'debit' 
                    ? 'Les augmentations sont enregistrées au débit' 
                    : 'Les augmentations sont enregistrées au crédit'
                  }
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Solde initial (FCFA)
                </label>
                <input
                  type="number"
                  name="soldeInitial"
                  value={formData.soldeInitial}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.soldeInitial ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="0"
                  min="0"
                  step="1"
                />
                {errors.soldeInitial && <p className="text-red-500 text-xs mt-1">{errors.soldeInitial}</p>}
                {formData.soldeInitial && (
                  <p className="text-sm text-gray-600 mt-1">
                    {formatMontant(formData.soldeInitial)}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Solde d'ouverture du compte (optionnel)
                </p>
              </div>
            </div>
          </div>

          {/* Description et notes */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4">Description et utilisation</h4>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              rows={4}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Description de l'utilisation de ce compte, règles de gestion particulières..."
            />
            <p className="text-xs text-gray-500 mt-1">
              Optionnel : précisez l'usage spécifique de ce compte
            </p>
          </div>

          {/* Aperçu du compte */}
          {formData.numero && formData.intitule && formData.classe && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Aperçu du compte</h4>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-50 rounded-lg">
                      <BookOpen className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">
                        {formData.numero} - {formData.intitule}
                      </div>
                      <div className="text-sm text-gray-600">
                        Classe {formData.classe} - {getClasseInfo()?.titre}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      formData.type === 'debit' 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {formData.type === 'debit' ? 'Débit' : 'Crédit'}
                    </span>
                    {formData.soldeInitial && (
                      <div className="text-sm font-mono text-gray-900 mt-1">
                        {formatMontant(formData.soldeInitial)}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Règles OHADA */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h5 className="font-medium text-yellow-900 mb-2 flex items-center">
              <AlertCircle className="h-4 w-4 mr-2" />
              Règles du plan comptable OHADA
            </h5>
            <ul className="text-sm text-yellow-800 space-y-1">
              <li>• Les comptes de classe 1, 4 (partiellement), 7 sont généralement créditeurs</li>
              <li>• Les comptes de classe 2, 3, 5, 6 sont généralement débiteurs</li>
              <li>• La numérotation doit respecter la hiérarchie : compte principal → sous-compte</li>
              <li>• Les comptes de détail doivent être rattachés à un compte principal existant</li>
              <li>• Respecter la nomenclature OHADA pour la cohérence des états financiers</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Création...' : 'Créer le compte'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}