import React, { useState } from 'react';
import { Search, Plus, BookOpen, ChevronRight, ChevronDown } from 'lucide-react';
import type { CompteComptable } from '../../types';
import NewCompteModal from './NewCompteModal';
import { useCurrency } from '../../contexts/CurrencyContext';

const planComptableOHADA: CompteComptable[] = [
  // Classe 1 - Comptes de Ressources Durables
  { numero: '10', intitule: 'Capital', classe: 1, type: 'credit', solde: 0 },
  { numero: '101', intitule: 'Capital social', classe: 1, type: 'credit', solde: 50000000 },
  { numero: '106', intitule: 'Réserves', classe: 1, type: 'credit', solde: 8500000 },
  { numero: '12', intitule: 'Résultat de l\'exercice', classe: 1, type: 'credit', solde: 0 },
  { numero: '13', intitule: 'Résultat net en instance d\'affectation', classe: 1, type: 'credit', solde: 0 },
  { numero: '16', intitule: 'Emprunts et dettes assimilées', classe: 1, type: 'credit', solde: 25000000 },
  
  // Classe 2 - Comptes d'Actif Immobilisé  
  { numero: '20', intitule: 'Charges immobilisées', classe: 2, type: 'debit', solde: 2500000 },
  { numero: '21', intitule: 'Immobilisations incorporelles', classe: 2, type: 'debit', solde: 5000000 },
  { numero: '22', intitule: 'Terrains', classe: 2, type: 'debit', solde: 15000000 },
  { numero: '23', intitule: 'Bâtiments, installations techniques', classe: 2, type: 'debit', solde: 45000000 },
  { numero: '24', intitule: 'Matériel', classe: 2, type: 'debit', solde: 18000000 },
  { numero: '245', intitule: 'Matériel de transport', classe: 2, type: 'debit', solde: 12000000 },
  { numero: '246', intitule: 'Matériel et mobilier de bureau', classe: 2, type: 'debit', solde: 3500000 },
  
  // Classe 3 - Comptes de Stocks
  { numero: '31', intitule: 'Matières premières', classe: 3, type: 'debit', solde: 8500000 },
  { numero: '32', intitule: 'Autres approvisionnements', classe: 3, type: 'debit', solde: 2200000 },
  { numero: '33', intitule: 'En-cours de production', classe: 3, type: 'debit', solde: 1800000 },
  { numero: '35', intitule: 'Stocks de produits', classe: 3, type: 'debit', solde: 12500000 },
  { numero: '37', intitule: 'Stocks de marchandises', classe: 3, type: 'debit', solde: 15000000 },
  
  // Classe 4 - Comptes de Tiers
  { numero: '401', intitule: 'Fournisseurs', classe: 4, type: 'credit', solde: 8500000 },
  { numero: '411', intitule: 'Clients', classe: 4, type: 'debit', solde: 18500000 },
  { numero: '421', intitule: 'Personnel - Avances et acomptes', classe: 4, type: 'debit', solde: 650000 },
  { numero: '422', intitule: 'Personnel - Rémunérations dues', classe: 4, type: 'credit', solde: 3200000 },
  { numero: '431', intitule: 'Sécurité Sociale', classe: 4, type: 'credit', solde: 1200000 },
  { numero: '441', intitule: 'État - Impôts sur bénéfices', classe: 4, type: 'credit', solde: 2500000 },
  { numero: '443', intitule: 'État - TVA facturée', classe: 4, type: 'credit', solde: 3600000 },
  { numero: '445', intitule: 'État - TVA récupérable', classe: 4, type: 'debit', solde: 2100000 },
  
  // Classe 5 - Comptes de Trésorerie
  { numero: '52', intitule: 'Banques', classe: 5, type: 'debit', solde: 8500000 },
  { numero: '521', intitule: 'Banques locales', classe: 5, type: 'debit', solde: 6500000 },
  { numero: '531', intitule: 'Chèques postaux', classe: 5, type: 'debit', solde: 850000 },
  { numero: '57', intitule: 'Caisse', classe: 5, type: 'debit', solde: 1150000 },
  
  // Classe 6 - Comptes de Charges
  { numero: '60', intitule: 'Achats', classe: 6, type: 'debit', solde: 0 },
  { numero: '601', intitule: 'Achats de marchandises', classe: 6, type: 'debit', solde: 0 },
  { numero: '602', intitule: 'Achats de matières premières', classe: 6, type: 'debit', solde: 0 },
  { numero: '61', intitule: 'Transports', classe: 6, type: 'debit', solde: 0 },
  { numero: '62', intitule: 'Services extérieurs A', classe: 6, type: 'debit', solde: 0 },
  { numero: '63', intitule: 'Services extérieurs B', classe: 6, type: 'debit', solde: 0 },
  { numero: '64', intitule: 'Impôts et taxes', classe: 6, type: 'debit', solde: 0 },
  { numero: '66', intitule: 'Charges de personnel', classe: 6, type: 'debit', solde: 0 },
  { numero: '68', intitule: 'Dotations aux amortissements', classe: 6, type: 'debit', solde: 0 },
  
  // Classe 7 - Comptes de Produits
  { numero: '70', intitule: 'Ventes', classe: 7, type: 'credit', solde: 0 },
  { numero: '701', intitule: 'Ventes de marchandises', classe: 7, type: 'credit', solde: 0 },
  { numero: '702', intitule: 'Ventes de produits finis', classe: 7, type: 'credit', solde: 0 },
  { numero: '706', intitule: 'Services vendus', classe: 7, type: 'credit', solde: 0 },
  { numero: '75', intitule: 'Autres produits', classe: 7, type: 'credit', solde: 0 },
  { numero: '77', intitule: 'Revenus financiers', classe: 7, type: 'credit', solde: 0 }
];

const classeTitles = {
  1: 'Comptes de Ressources Durables',
  2: 'Comptes d\'Actif Immobilisé',
  3: 'Comptes de Stocks',
  4: 'Comptes de Tiers',
  5: 'Comptes de Trésorerie',
  6: 'Comptes de Charges',
  7: 'Comptes de Produits',
  8: 'Comptes Spéciaux'
};

export default function PlanComptable() {
  const { formatAmount } = useCurrency();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClasse, setSelectedClasse] = useState<number | null>(null);
  const [expandedClasses, setExpandedClasses] = useState<Set<number>>(new Set([1, 2, 3, 4, 5, 6, 7]));
  const [comptes, setComptes] = useState<CompteComptable[]>(planComptableOHADA);
  const [isNewCompteModalOpen, setIsNewCompteModalOpen] = useState(false);

  const filteredComptes = comptes.filter((compte) => {
    const matchesSearch = compte.numero.includes(searchTerm) || 
                         compte.intitule.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClasse = selectedClasse === null || compte.classe === selectedClasse;
    return matchesSearch && matchesClasse;
  });

  const groupedComptes = filteredComptes.reduce((acc, compte) => {
    if (!acc[compte.classe]) {
      acc[compte.classe] = [];
    }
    acc[compte.classe].push(compte);
    return acc;
  }, {} as Record<number, CompteComptable[]>);

  const toggleClasse = (classe: number) => {
    const newExpanded = new Set(expandedClasses);
    if (newExpanded.has(classe)) {
      newExpanded.delete(classe);
    } else {
      newExpanded.add(classe);
    }
    setExpandedClasses(newExpanded);
  };


  const handleSaveNewCompte = (newCompte: CompteComptable) => {
    setComptes(prev => [...prev, newCompte]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Plan Comptable OHADA</h3>
          <p className="text-sm text-gray-600 mt-1">
            Plan comptable général selon le référentiel OHADA
          </p>
        </div>
        <button
          onClick={() => setIsNewCompteModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouveau compte</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro ou intitulé de compte..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={selectedClasse || ''}
            onChange={(e) => setSelectedClasse(e.target.value ? Number(e.target.value) : null)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Toutes les classes</option>
            {Object.entries(classeTitles).map(([classe, titre]) => (
              <option key={classe} value={classe}>
                Classe {classe} - {titre}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Plan Comptable */}
      <div className="bg-white rounded-lg border border-gray-200">
        {Object.entries(groupedComptes).map(([classeStr, comptes]) => {
          const classe = Number(classeStr);
          const isExpanded = expandedClasses.has(classe);
          
          return (
            <div key={classe} className="border-b border-gray-200 last:border-b-0">
              <button
                onClick={() => toggleClasse(classe)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <BookOpen className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-semibold text-gray-900">
                      Classe {classe} - {classeTitles[classe as keyof typeof classeTitles]}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {comptes.length} compte{comptes.length > 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                )}
              </button>

              {isExpanded && (
                <div className="px-6 pb-4">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Numéro
                          </th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Intitulé
                          </th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Type
                          </th>
                          <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Solde
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {comptes.map((compte) => (
                          <tr key={compte.numero} className="hover:bg-gray-50">
                            <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">
                              {compte.numero}
                            </td>
                            <td className="px-4 py-2 text-sm text-gray-900">
                              {compte.intitule}
                            </td>
                            <td className="px-4 py-2 whitespace-nowrap">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                compte.type === 'debit' 
                                  ? 'bg-blue-100 text-blue-800' 
                                  : 'bg-green-100 text-green-800'
                              }`}>
                                {compte.type === 'debit' ? 'Débit' : 'Crédit'}
                              </span>
                            </td>
                            <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                              {compte.solde > 0 ? formatAmount(compte.solde) : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {Object.keys(groupedComptes).length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun compte trouvé</h3>
          <p className="text-gray-600">
            Essayez de modifier vos critères de recherche
          </p>
        </div>
      )}

      {/* New Compte Modal */}
      <NewCompteModal
        isOpen={isNewCompteModalOpen}
        onClose={() => setIsNewCompteModalOpen(false)}
        onSave={handleSaveNewCompte}
      />
    </div>
  );
}