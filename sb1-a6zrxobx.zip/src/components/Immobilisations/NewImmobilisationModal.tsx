import React, { useState } from 'react';
import { X, Building, Calendar, Calculator, FileText, Save, AlertCircle } from 'lucide-react';
import type { Immobilisation, Client } from '../../types';

interface NewImmobilisationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (immobilisation: Omit<Immobilisation, 'id'>) => void;
}

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif'
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'actif'
  }
];

const categoriesImmobilisations = [
  { 
    value: 'terrain', 
    label: 'Terrain', 
    dureeDefaut: 0, 
    tauxDefaut: 0,
    compteImmo: '22',
    compteAmort: ''
  },
  { 
    value: 'batiment', 
    label: 'Bâtiment', 
    dureeDefaut: 20, 
    tauxDefaut: 5,
    compteImmo: '231',
    compteAmort: '2831'
  },
  { 
    value: 'materiel', 
    label: 'Matériel industriel', 
    dureeDefaut: 10, 
    tauxDefaut: 10,
    compteImmo: '241',
    compteAmort: '2841'
  },
  { 
    value: 'transport', 
    label: 'Matériel de transport', 
    dureeDefaut: 5, 
    tauxDefaut: 20,
    compteImmo: '245',
    compteAmort: '2845'
  },
  { 
    value: 'mobilier', 
    label: 'Mobilier de bureau', 
    dureeDefaut: 10, 
    tauxDefaut: 10,
    compteImmo: '246',
    compteAmort: '2846'
  },
  { 
    value: 'informatique', 
    label: 'Matériel informatique', 
    dureeDefaut: 3, 
    tauxDefaut: 33.33,
    compteImmo: '2441',
    compteAmort: '28441'
  },
  { 
    value: 'incorporel', 
    label: 'Immobilisation incorporelle', 
    dureeDefaut: 5, 
    tauxDefaut: 20,
    compteImmo: '211',
    compteAmort: '2811'
  }
];

const methodesAmortissement = [
  { value: 'lineaire', label: 'Linéaire' },
  { value: 'degressif', label: 'Dégressif' },
  { value: 'variable', label: 'Variable' }
];

const statutsImmobilisation = [
  { value: 'en-service', label: 'En service' },
  { value: 'en-cours', label: 'En cours d\'acquisition' },
  { value: 'cede', label: 'Cédé' },
  { value: 'reforme', label: 'Réformé' }
];

export default function NewImmobilisationModal({ isOpen, onClose, onSave }: NewImmobilisationModalProps) {
  const [formData, setFormData] = useState({
    clientId: '',
    designation: '',
    categorie: '',
    dateAcquisition: new Date().toISOString().split('T')[0],
    valeurAcquisition: '',
    dureeAmortissement: '',
    tauxAmortissement: '',
    methodeAmortissement: 'lineaire',
    compteImmobilisation: '',
    compteAmortissement: '',
    statut: 'en-service',
    numeroInventaire: '',
    fournisseur: '',
    numeroFacture: '',
    exerciceAcquisition: new Date().getFullYear().toString(),
    observations: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Auto-remplissage selon la catégorie
    if (name === 'categorie') {
      const categorie = categoriesImmobilisations.find(c => c.value === value);
      if (categorie) {
        setFormData(prev => ({
          ...prev,
          dureeAmortissement: categorie.dureeDefaut.toString(),
          tauxAmortissement: categorie.tauxDefaut.toString(),
          compteImmobilisation: categorie.compteImmo,
          compteAmortissement: categorie.compteAmort
        }));
      }
    }

    // Génération automatique du numéro d'inventaire
    if (name === 'clientId' && value) {
      const client = mockClients.find(c => c.id === value);
      if (client) {
        const prefix = client.nom.split(' ')[0].toUpperCase();
        const nextNumber = String(Math.floor(Math.random() * 999) + 1).padStart(3, '0');
        setFormData(prev => ({ 
          ...prev, 
          numeroInventaire: `${prefix}-IMM-${nextNumber}` 
        }));
      }
    }

    // Calcul automatique du taux d'amortissement
    if (name === 'dureeAmortissement' && value && parseFloat(value) > 0) {
      const taux = (100 / parseFloat(value)).toFixed(2);
      setFormData(prev => ({ ...prev, tauxAmortissement: taux }));
    }

    // Mise à jour de l'exercice selon la date d'acquisition
    if (name === 'dateAcquisition' && value) {
      const annee = new Date(value).getFullYear().toString();
      setFormData(prev => ({ ...prev, exerciceAcquisition: annee }));
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Champs obligatoires
    if (!formData.clientId) newErrors.clientId = 'Le client est obligatoire';
    if (!formData.designation.trim()) newErrors.designation = 'La désignation est obligatoire';
    if (!formData.categorie) newErrors.categorie = 'La catégorie est obligatoire';
    if (!formData.dateAcquisition) newErrors.dateAcquisition = 'La date d\'acquisition est obligatoire';
    if (!formData.valeurAcquisition || parseFloat(formData.valeurAcquisition) <= 0) {
      newErrors.valeurAcquisition = 'La valeur d\'acquisition doit être supérieure à 0';
    }
    if (!formData.dureeAmortissement || parseFloat(formData.dureeAmortissement) < 0) {
      newErrors.dureeAmortissement = 'La durée d\'amortissement est obligatoire';
    }
    if (!formData.compteImmobilisation.trim()) {
      newErrors.compteImmobilisation = 'Le compte d\'immobilisation est obligatoire';
    }

    // Validation spécifique pour les terrains (non amortissables)
    if (formData.categorie === 'terrain') {
      if (formData.dureeAmortissement !== '0') {
        newErrors.dureeAmortissement = 'Les terrains ne sont pas amortissables (durée = 0)';
      }
    } else {
      // Pour les autres immobilisations, durée > 0
      if (parseFloat(formData.dureeAmortissement) <= 0) {
        newErrors.dureeAmortissement = 'La durée d\'amortissement doit être supérieure à 0';
      }
      if (!formData.compteAmortissement.trim()) {
        newErrors.compteAmortissement = 'Le compte d\'amortissement est obligatoire';
      }
    }

    // Validation des montants
    if (formData.valeurAcquisition && parseFloat(formData.valeurAcquisition) > 1000000000) {
      newErrors.valeurAcquisition = 'La valeur semble trop élevée';
    }

    // Validation de la date
    const dateAcquisition = new Date(formData.dateAcquisition);
    const today = new Date();
    if (dateAcquisition > today) {
      newErrors.dateAcquisition = 'La date d\'acquisition ne peut pas être dans le futur';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const valeurAcquisition = parseFloat(formData.valeurAcquisition);
      const dureeAmortissement = parseFloat(formData.dureeAmortissement);
      const tauxAmortissement = parseFloat(formData.tauxAmortissement);
      
      // Calcul de l'amortissement cumulé (simulation basée sur l'âge)
      const dateAcquisition = new Date(formData.dateAcquisition);
      const today = new Date();
      const ageEnAnnees = (today.getTime() - dateAcquisition.getTime()) / (1000 * 60 * 60 * 24 * 365);
      
      let amortissementCumule = 0;
      if (dureeAmortissement > 0 && ageEnAnnees > 0) {
        const amortissementAnnuel = valeurAcquisition / dureeAmortissement;
        amortissementCumule = Math.min(
          amortissementAnnuel * Math.floor(ageEnAnnees),
          valeurAcquisition
        );
      }

      const valeurNetteComptable = valeurAcquisition - amortissementCumule;

      const nouvelleImmobilisation: Omit<Immobilisation, 'id'> = {
        clientId: formData.clientId,
        designation: formData.designation.trim(),
        categorie: formData.categorie as Immobilisation['categorie'],
        dateAcquisition: new Date(formData.dateAcquisition),
        valeurAcquisition,
        dureeAmortissement,
        tauxAmortissement,
        amortissementCumule,
        valeurNetteComptable,
        compteImmobilisation: formData.compteImmobilisation.trim(),
        compteAmortissement: formData.compteAmortissement.trim(),
        statut: formData.statut as Immobilisation['statut'],
        numeroInventaire: formData.numeroInventaire.trim(),
        fournisseur: formData.fournisseur.trim(),
        numeroFacture: formData.numeroFacture.trim(),
        exerciceAcquisition: formData.exerciceAcquisition,
        methodeAmortissement: formData.methodeAmortissement as Immobilisation['methodeAmortissement'],
        observations: formData.observations.trim()
      };

      onSave(nouvelleImmobilisation);
      onClose();
      
      // Reset form
      setFormData({
        clientId: '',
        designation: '',
        categorie: '',
        dateAcquisition: new Date().toISOString().split('T')[0],
        valeurAcquisition: '',
        dureeAmortissement: '',
        tauxAmortissement: '',
        methodeAmortissement: 'lineaire',
        compteImmobilisation: '',
        compteAmortissement: '',
        statut: 'en-service',
        numeroInventaire: '',
        fournisseur: '',
        numeroFacture: '',
        exerciceAcquisition: new Date().getFullYear().toString(),
        observations: ''
      });
    } catch (error) {
      console.error('Erreur lors de la création de l\'immobilisation:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatMontant = (montant: string) => {
    if (!montant) return '';
    const num = parseFloat(montant);
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(num);
  };

  const calculerAmortissementAnnuel = () => {
    const valeur = parseFloat(formData.valeurAcquisition);
    const duree = parseFloat(formData.dureeAmortissement);
    if (valeur && duree && duree > 0) {
      return valeur / duree;
    }
    return 0;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Building className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouvelle Immobilisation</h3>
                <p className="text-sm text-gray-600">Ajouter une immobilisation au patrimoine client</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Informations générales */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Building className="h-5 w-5 mr-2 text-blue-600" />
              Informations générales
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.clientId ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un client</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.nom}</option>
                  ))}
                </select>
                {errors.clientId && <p className="text-red-500 text-xs mt-1">{errors.clientId}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Catégorie <span className="text-red-500">*</span>
                </label>
                <select
                  name="categorie"
                  value={formData.categorie}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.categorie ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner une catégorie</option>
                  {categoriesImmobilisations.map(cat => (
                    <option key={cat.value} value={cat.value}>{cat.label}</option>
                  ))}
                </select>
                {errors.categorie && <p className="text-red-500 text-xs mt-1">{errors.categorie}</p>}
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Désignation <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="designation"
                  value={formData.designation}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.designation ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: Ordinateur portable Dell Latitude 5520"
                />
                {errors.designation && <p className="text-red-500 text-xs mt-1">{errors.designation}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro d'inventaire
                </label>
                <input
                  type="text"
                  name="numeroInventaire"
                  value={formData.numeroInventaire}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Généré automatiquement"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Statut
                </label>
                <select
                  name="statut"
                  value={formData.statut}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {statutsImmobilisation.map(statut => (
                    <option key={statut.value} value={statut.value}>{statut.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Informations d'acquisition */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-600" />
              Informations d'acquisition
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date d'acquisition <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="dateAcquisition"
                  value={formData.dateAcquisition}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.dateAcquisition ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.dateAcquisition && <p className="text-red-500 text-xs mt-1">{errors.dateAcquisition}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Exercice d'acquisition
                </label>
                <input
                  type="text"
                  name="exerciceAcquisition"
                  value={formData.exerciceAcquisition}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="2024"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Valeur d'acquisition (FCFA) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="valeurAcquisition"
                  value={formData.valeurAcquisition}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.valeurAcquisition ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="0"
                  min="0"
                  step="1"
                />
                {errors.valeurAcquisition && <p className="text-red-500 text-xs mt-1">{errors.valeurAcquisition}</p>}
                {formData.valeurAcquisition && (
                  <p className="text-sm text-gray-600 mt-1">
                    {formatMontant(formData.valeurAcquisition)}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fournisseur
                </label>
                <input
                  type="text"
                  name="fournisseur"
                  value={formData.fournisseur}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Nom du fournisseur"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro de facture
                </label>
                <input
                  type="text"
                  name="numeroFacture"
                  value={formData.numeroFacture}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ex: FAC-2024-001"
                />
              </div>
            </div>
          </div>

          {/* Paramètres d'amortissement */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calculator className="h-5 w-5 mr-2 text-purple-600" />
              Paramètres d'amortissement
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Méthode d'amortissement
                </label>
                <select
                  name="methodeAmortissement"
                  value={formData.methodeAmortissement}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {methodesAmortissement.map(methode => (
                    <option key={methode.value} value={methode.value}>{methode.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Durée d'amortissement (années) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="dureeAmortissement"
                  value={formData.dureeAmortissement}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.dureeAmortissement ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="0"
                  min="0"
                  step="1"
                />
                {errors.dureeAmortissement && <p className="text-red-500 text-xs mt-1">{errors.dureeAmortissement}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Taux d'amortissement (%)
                </label>
                <input
                  type="number"
                  name="tauxAmortissement"
                  value={formData.tauxAmortissement}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="0"
                  min="0"
                  max="100"
                  step="0.01"
                  readOnly
                />
                <p className="text-xs text-gray-500 mt-1">Calculé automatiquement</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Amortissement annuel
                </label>
                <div className="w-full border border-gray-200 bg-gray-50 rounded-lg px-3 py-2 text-sm font-mono">
                  {formatMontant(calculerAmortissementAnnuel().toString())}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Compte d'immobilisation <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="compteImmobilisation"
                  value={formData.compteImmobilisation}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.compteImmobilisation ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: 241"
                />
                {errors.compteImmobilisation && <p className="text-red-500 text-xs mt-1">{errors.compteImmobilisation}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Compte d'amortissement {formData.categorie !== 'terrain' && <span className="text-red-500">*</span>}
                </label>
                <input
                  type="text"
                  name="compteAmortissement"
                  value={formData.compteAmortissement}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.compteAmortissement ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: 2841"
                  disabled={formData.categorie === 'terrain'}
                />
                {errors.compteAmortissement && <p className="text-red-500 text-xs mt-1">{errors.compteAmortissement}</p>}
                {formData.categorie === 'terrain' && (
                  <p className="text-xs text-gray-500 mt-1">Les terrains ne sont pas amortissables</p>
                )}
              </div>
            </div>
          </div>

          {/* Observations */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-gray-600" />
              Observations
            </h4>
            <textarea
              name="observations"
              value={formData.observations}
              onChange={handleInputChange}
              rows={4}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Notes et observations particulières sur cette immobilisation..."
            />
          </div>

          {/* Résumé */}
          {formData.valeurAcquisition && formData.dureeAmortissement && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Résumé de l'immobilisation</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Valeur d'acquisition:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {formatMontant(formData.valeurAcquisition)}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Amortissement annuel:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {formatMontant(calculerAmortissementAnnuel().toString())}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Durée:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {formData.dureeAmortissement} {formData.dureeAmortissement === '1' ? 'an' : 'ans'}
                  </span>
                </div>
              </div>
              {formData.categorie === 'terrain' && (
                <div className="mt-2 p-2 bg-yellow-100 border border-yellow-200 rounded flex items-center">
                  <AlertCircle className="h-4 w-4 text-yellow-600 mr-2" />
                  <span className="text-sm text-yellow-800">
                    Les terrains ne sont pas amortissables selon les normes OHADA
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Enregistrement...' : 'Enregistrer l\'immobilisation'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}