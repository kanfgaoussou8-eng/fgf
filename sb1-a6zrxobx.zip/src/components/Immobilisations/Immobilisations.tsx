import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, CreditCard as Edit, Trash2, Building, Car, Monitor, Calendar, TrendingDown, Calculator, Users, FileText, Download } from 'lucide-react';
import type { Immobilisation, Client } from '../../types';
import NewImmobilisationModal from './NewImmobilisationModal';
import { useCurrency } from '../../contexts/CurrencyContext';

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif'
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'actif'
  }
];

const mockImmobilisations: Immobilisation[] = [
  {
    id: '1',
    clientId: '1',
    designation: 'Terrain commercial - Cocody',
    categorie: 'terrain',
    dateAcquisition: new Date('2020-03-15'),
    valeurAcquisition: 25000000,
    dureeAmortissement: 0,
    tauxAmortissement: 0,
    amortissementCumule: 0,
    valeurNetteComptable: 25000000,
    compteImmobilisation: '22',
    compteAmortissement: '',
    statut: 'en-service',
    numeroInventaire: 'TEKNO-IMM-001',
    fournisseur: 'AGENCE IMMOBILIERE PLATEAU',
    numeroFacture: 'AI-2020-045',
    exerciceAcquisition: '2020',
    methodeAmortissement: 'lineaire',
    observations: 'Terrain non amortissable'
  },
  {
    id: '2',
    clientId: '1',
    designation: 'Bâtiment administratif',
    categorie: 'batiment',
    dateAcquisition: new Date('2021-06-10'),
    valeurAcquisition: 45000000,
    dureeAmortissement: 20,
    tauxAmortissement: 5,
    amortissementCumule: 6750000,
    valeurNetteComptable: 38250000,
    compteImmobilisation: '231',
    compteAmortissement: '2831',
    statut: 'en-service',
    numeroInventaire: 'TEKNO-BAT-001',
    fournisseur: 'ENTREPRISE BTP MODERNE',
    numeroFacture: 'BTP-2021-128',
    exerciceAcquisition: '2021',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '3',
    clientId: '2',
    designation: 'Véhicule utilitaire Toyota Hilux',
    categorie: 'transport',
    dateAcquisition: new Date('2022-01-20'),
    valeurAcquisition: 18000000,
    dureeAmortissement: 5,
    tauxAmortissement: 20,
    amortissementCumule: 7200000,
    valeurNetteComptable: 10800000,
    compteImmobilisation: '245',
    compteAmortissement: '2845',
    statut: 'en-service',
    numeroInventaire: 'MAMADOU-VEH-001',
    fournisseur: 'TOYOTA ABIDJAN',
    numeroFacture: 'TOY-2022-089',
    exerciceAcquisition: '2022',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '4',
    clientId: '1',
    designation: 'Ordinateurs de bureau (10 unités)',
    categorie: 'informatique',
    dateAcquisition: new Date('2023-03-15'),
    valeurAcquisition: 8500000,
    dureeAmortissement: 3,
    tauxAmortissement: 33.33,
    amortissementCumule: 2833333,
    valeurNetteComptable: 5666667,
    compteImmobilisation: '2441',
    compteAmortissement: '28441',
    statut: 'en-service',
    numeroInventaire: 'TEKNO-INFO-001',
    fournisseur: 'COMPUTER SHOP CI',
    numeroFacture: 'CS-2023-156',
    exerciceAcquisition: '2023',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '5',
    clientId: '3',
    designation: 'Mobilier de bureau',
    categorie: 'mobilier',
    dateAcquisition: new Date('2021-09-05'),
    valeurAcquisition: 3500000,
    dureeAmortissement: 10,
    tauxAmortissement: 10,
    amortissementCumule: 875000,
    valeurNetteComptable: 2625000,
    compteImmobilisation: '246',
    compteAmortissement: '2846',
    statut: 'en-service',
    numeroInventaire: 'AFRICAN-MOB-001',
    fournisseur: 'MOBILIER MODERNE',
    numeroFacture: 'MM-2021-234',
    exerciceAcquisition: '2021',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '6',
    clientId: '4',
    designation: 'Camion de transport 20T',
    categorie: 'transport',
    dateAcquisition: new Date('2019-08-12'),
    valeurAcquisition: 35000000,
    dureeAmortissement: 8,
    tauxAmortissement: 12.5,
    amortissementCumule: 21875000,
    valeurNetteComptable: 13125000,
    compteImmobilisation: '245',
    compteAmortissement: '2845',
    statut: 'en-service',
    numeroInventaire: 'TRANSPORT-CAM-001',
    fournisseur: 'IVECO ABIDJAN',
    numeroFacture: 'IVE-2019-067',
    exerciceAcquisition: '2019',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '7',
    clientId: '2',
    designation: 'Logiciel de gestion commerciale',
    categorie: 'incorporel',
    dateAcquisition: new Date('2023-01-10'),
    valeurAcquisition: 2500000,
    dureeAmortissement: 5,
    tauxAmortissement: 20,
    amortissementCumule: 500000,
    valeurNetteComptable: 2000000,
    compteImmobilisation: '211',
    compteAmortissement: '2811',
    statut: 'en-service',
    numeroInventaire: 'MAMADOU-LOG-001',
    fournisseur: 'SOFT SOLUTIONS CI',
    numeroFacture: 'SS-2023-012',
    exerciceAcquisition: '2023',
    methodeAmortissement: 'lineaire'
  },
  {
    id: '8',
    clientId: '3',
    designation: 'Machine d\'emballage industrielle',
    categorie: 'materiel',
    dateAcquisition: new Date('2022-11-20'),
    valeurAcquisition: 28000000,
    dureeAmortissement: 10,
    tauxAmortissement: 10,
    amortissementCumule: 2800000,
    valeurNetteComptable: 25200000,
    compteImmobilisation: '241',
    compteAmortissement: '2841',
    statut: 'en-service',
    numeroInventaire: 'AFRICAN-MAC-001',
    fournisseur: 'INDUSTRIAL EQUIPMENT',
    numeroFacture: 'IE-2022-234',
    exerciceAcquisition: '2022',
    methodeAmortissement: 'lineaire'
  }
];

const categorieLabels = {
  'terrain': 'Terrain',
  'batiment': 'Bâtiment',
  'materiel': 'Matériel industriel',
  'transport': 'Matériel de transport',
  'mobilier': 'Mobilier de bureau',
  'informatique': 'Matériel informatique',
  'incorporel': 'Immobilisation incorporelle'
};

const categorieIcons = {
  'terrain': Building,
  'batiment': Building,
  'materiel': Calculator,
  'transport': Car,
  'mobilier': Monitor,
  'informatique': Monitor,
  'incorporel': Calendar
};

export default function Immobilisations() {
  const { formatAmount } = useCurrency();
  const [immobilisations, setImmobilisations] = useState<Immobilisation[]>(mockImmobilisations);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClient, setFilterClient] = useState<string>('tous');
  const [filterCategorie, setFilterCategorie] = useState<string>('tous');
  const [filterStatut, setFilterStatut] = useState<string>('tous');
  const [selectedImmobilisation, setSelectedImmobilisation] = useState<Immobilisation | null>(null);
  const [isNewImmobilisationModalOpen, setIsNewImmobilisationModalOpen] = useState(false);

  const filteredImmobilisations = immobilisations.filter(immo => {
    const client = mockClients.find(c => c.id === immo.clientId);
    const clientName = client ? client.nom : '';
    
    const matchesSearch = immo.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         immo.numeroInventaire?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         clientName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClient = filterClient === 'tous' || immo.clientId === filterClient;
    const matchesCategorie = filterCategorie === 'tous' || immo.categorie === filterCategorie;
    const matchesStatut = filterStatut === 'tous' || immo.statut === filterStatut;
    return matchesSearch && matchesClient && matchesCategorie && matchesStatut;
  });

  const getStatutBadge = (statut: Immobilisation['statut']) => {
    switch (statut) {
      case 'en-service':
        return 'bg-green-100 text-green-800';
      case 'cede':
        return 'bg-blue-100 text-blue-800';
      case 'reforme':
        return 'bg-red-100 text-red-800';
      case 'en-cours':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };


  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : 'Client inconnu';
  };

  const getTotalValeurAcquisition = () => {
    return filteredImmobilisations.reduce((sum, immo) => sum + immo.valeurAcquisition, 0);
  };

  const getTotalAmortissementCumule = () => {
    return filteredImmobilisations.reduce((sum, immo) => sum + immo.amortissementCumule, 0);
  };

  const getTotalValeurNette = () => {
    return filteredImmobilisations.reduce((sum, immo) => sum + immo.valeurNetteComptable, 0);
  };

  const getNombreClients = () => {
    const clientsUniques = new Set(filteredImmobilisations.map(immo => immo.clientId));
    return clientsUniques.size;
  };

  const calculerAmortissementAnnuel = (immo: Immobilisation) => {
    if (immo.dureeAmortissement === 0) return 0;
    return immo.valeurAcquisition / immo.dureeAmortissement;
  };

  const getImmobilisationsParClient = () => {
    const stats = mockClients.map(client => {
      const immosClient = immobilisations.filter(immo => immo.clientId === client.id);
      const valeurTotale = immosClient.reduce((sum, immo) => sum + immo.valeurNetteComptable, 0);
      return {
        client: client.nom,
        nombre: immosClient.length,
        valeur: valeurTotale
      };
    }).filter(stat => stat.nombre > 0);
    
    return stats.sort((a, b) => b.valeur - a.valeur);
  };

  const handleSaveNewImmobilisation = (newImmobilisationData: Omit<Immobilisation, 'id'>) => {
    const newImmobilisation: Immobilisation = {
      ...newImmobilisationData,
      id: (immobilisations.length + 1).toString()
    };
    setImmobilisations(prev => [...prev, newImmobilisation]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gestion des Immobilisations</h3>
          <p className="text-sm text-gray-600 mt-1">
            Suivi du patrimoine immobilisé de vos clients et calcul des amortissements
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button
            onClick={() => setIsNewImmobilisationModalOpen(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Nouvelle immobilisation</span>
          </button>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Valeur d'acquisition</p>
              <p className="text-2xl font-bold text-gray-900">{formatAmount(getTotalValeurAcquisition())}</p>
              <p className="text-sm text-gray-500 mt-1">Portfolio total</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Building className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Amortissements cumulés</p>
              <p className="text-2xl font-bold text-gray-900">{formatAmount(getTotalAmortissementCumule())}</p>
              <p className="text-sm text-gray-500 mt-1">Tous clients</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <TrendingDown className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Valeur nette comptable</p>
              <p className="text-2xl font-bold text-gray-900">{formatAmount(getTotalValeurNette())}</p>
              <p className="text-sm text-gray-500 mt-1">Patrimoine net</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <Calculator className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Clients concernés</p>
              <p className="text-2xl font-bold text-gray-900">{getNombreClients()}</p>
              <p className="text-sm text-gray-500 mt-1">{filteredImmobilisations.length} immobilisations</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Client Portfolio Summary */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Répartition par Client</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {getImmobilisationsParClient().map((stat, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-medium text-gray-900 text-sm truncate">{stat.client}</h5>
                <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                  {stat.nombre}
                </span>
              </div>
              <p className="text-lg font-bold text-gray-900">{formatAmount(stat.valeur)}</p>
              <p className="text-xs text-gray-500">Valeur nette</p>
            </div>
          ))}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par désignation, inventaire ou client..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterClient}
              onChange={(e) => setFilterClient(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les clients</option>
              {mockClients.map(client => (
                <option key={client.id} value={client.id}>{client.nom}</option>
              ))}
            </select>
            <select
              value={filterCategorie}
              onChange={(e) => setFilterCategorie(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Toutes catégories</option>
              {Object.entries(categorieLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
            <select
              value={filterStatut}
              onChange={(e) => setFilterStatut(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous statuts</option>
              <option value="en-service">En service</option>
              <option value="cede">Cédé</option>
              <option value="reforme">Réformé</option>
              <option value="en-cours">En cours</option>
            </select>
          </div>
        </div>
      </div>

      {/* Immobilisations Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client / Désignation
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Catégorie
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date acquisition
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valeur acquisition
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amort. cumulé
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  VNC
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredImmobilisations.map((immo) => {
                const CategorieIcon = categorieIcons[immo.categorie];
                
                return (
                  <tr key={immo.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-900">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          <CategorieIcon className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium text-blue-600">{getClientName(immo.clientId)}</div>
                          <div className="text-gray-900">{immo.designation}</div>
                          <div className="text-xs text-gray-500">{immo.numeroInventaire}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                        {categorieLabels[immo.categorie]}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div>
                        {immo.dateAcquisition.toLocaleDateString('fr-FR')}
                        <div className="text-xs text-gray-500">Exercice {immo.exerciceAcquisition}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                      {formatAmount(immo.valeurAcquisition)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                      {formatAmount(immo.amortissementCumule)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono font-bold">
                      {formatAmount(immo.valeurNetteComptable)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatutBadge(immo.statut)}`}>
                        {immo.statut}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedImmobilisation(immo)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button className="text-gray-600 hover:text-gray-800">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="text-red-600 hover:text-red-800">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedImmobilisation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Fiche d'Immobilisation
                  </h3>
                  <p className="text-sm text-blue-600 font-medium">
                    {getClientName(selectedImmobilisation.clientId)}
                  </p>
                  <p className="text-sm text-gray-600">
                    {selectedImmobilisation.designation}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedImmobilisation(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Informations générales</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Client:</span>
                      <span className="font-medium text-blue-600">{getClientName(selectedImmobilisation.clientId)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Catégorie:</span>
                      <span>{categorieLabels[selectedImmobilisation.categorie]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">N° inventaire:</span>
                      <span className="font-mono">{selectedImmobilisation.numeroInventaire}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Exercice acquisition:</span>
                      <span>{selectedImmobilisation.exerciceAcquisition}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Fournisseur:</span>
                      <span>{selectedImmobilisation.fournisseur}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">N° facture:</span>
                      <span>{selectedImmobilisation.numeroFacture}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Statut:</span>
                      <span className="capitalize">{selectedImmobilisation.statut}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Paramètres d'amortissement</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Méthode:</span>
                      <span className="capitalize">{selectedImmobilisation.methodeAmortissement}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Durée:</span>
                      <span>{selectedImmobilisation.dureeAmortissement} ans</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Taux:</span>
                      <span>{selectedImmobilisation.tauxAmortissement}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Amort. annuel:</span>
                      <span className="font-mono">{formatAmount(calculerAmortissementAnnuel(selectedImmobilisation))}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Compte immo:</span>
                      <span className="font-mono">{selectedImmobilisation.compteImmobilisation}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Compte amort:</span>
                      <span className="font-mono">{selectedImmobilisation.compteAmortissement || 'N/A'}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <h4 className="font-medium text-gray-900 mb-4">Valeurs comptables</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {formatAmount(selectedImmobilisation.valeurAcquisition)}
                    </div>
                    <div className="text-sm text-gray-600">Valeur d'acquisition</div>
                  </div>
                  <div className="text-center p-4 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">
                      {formatAmount(selectedImmobilisation.amortissementCumule)}
                    </div>
                    <div className="text-sm text-gray-600">Amortissement cumulé</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {formatAmount(selectedImmobilisation.valeurNetteComptable)}
                    </div>
                    <div className="text-sm text-gray-600">Valeur nette comptable</div>
                  </div>
                </div>
              </div>

              {selectedImmobilisation.observations && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-900 mb-2">Observations</h4>
                  <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-lg">
                    {selectedImmobilisation.observations}
                  </p>
                </div>
              )}

              <div className="mt-6 pt-6 border-t border-gray-200 flex justify-end space-x-3">
                <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2">
                  <FileText className="h-4 w-4" />
                  <span>Fiche détaillée</span>
                </button>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                  <Edit className="h-4 w-4" />
                  <span>Modifier</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Immobilisation Modal */}
      <NewImmobilisationModal
        isOpen={isNewImmobilisationModalOpen}
        onClose={() => setIsNewImmobilisationModalOpen(false)}
        onSave={handleSaveNewImmobilisation}
      />

      {filteredImmobilisations.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune immobilisation trouvée</h3>
          <p className="text-gray-600">
            {searchTerm || filterClient !== 'tous' ? 'Essayez de modifier vos critères de recherche' : 'Commencez par ajouter les immobilisations de vos clients'}
          </p>
        </div>
      )}
    </div>
  );
}