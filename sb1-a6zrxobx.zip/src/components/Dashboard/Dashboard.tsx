import React, { useState } from 'react';
import { 
  Users, 
  FileText, 
  DollarSign, 
  AlertTriangle,
  TrendingUp,
  Calendar,
  Clock,
  CheckCircle,
  Globe,
  BarChart3
} from 'lucide-react';
import CurrencyConverter from '../Currency/CurrencyConverter';
import { CURRENCIES, type Currency } from '../../utils/currency';
import { useCurrency } from '../../contexts/CurrencyContext';

const recentActivities = [
  {
    id: 1,
    type: 'ecriture',
    description: 'Validation écritures - SARL TEKNO',
    time: 'Il y a 2 heures',
    status: 'completed',
    currency: 'XOF'
  },
  {
    id: 2,
    type: 'declaration',
    description: 'TVA déposée - ETS MAMADOU',
    time: 'Il y a 4 heures',
    status: 'completed',
    currency: 'USD'
  },
  {
    id: 3,
    type: 'client',
    description: 'Nouveau client ajouté - SARL AFRICAN TRADE',
    time: 'Il y a 1 jour',
    status: 'new',
    currency: 'EUR'
  },
  {
    id: 4,
    type: 'facture',
    description: 'Facture envoyée - GIE TRANSPORT PLUS',
    time: 'Il y a 2 jours',
    status: 'pending',
    currency: 'CDF'
  }
];

const upcomingTasks = [
  {
    id: 1,
    description: 'Clôture mensuelle - SARL INDUSTRIAL',
    deadline: 'Aujourd\'hui',
    priority: 'high'
  },
  {
    id: 2,
    description: 'Déclaration TVA - ETS COMMERCE',
    deadline: 'Demain',
    priority: 'high'
  },
  {
    id: 3,
    description: 'Révision comptes - SARL BUILDING',
    deadline: '3 jours',
    priority: 'medium'
  },
  {
    id: 4,
    description: 'États financiers - GIE SERVICES',
    deadline: '1 semaine',
    priority: 'low'
  }
];

export default function Dashboard() {
  const { formatAmount } = useCurrency();
  const [selectedPeriod, setSelectedPeriod] = useState('6-mois');

  const performanceData = [
    { mois: 'Août', ca: 98500000, clients: 42, factures: 18 },
    { mois: 'Sept', ca: 112300000, clients: 44, factures: 22 },
    { mois: 'Oct', ca: 125600000, clients: 46, factures: 25 },
    { mois: 'Nov', ca: 118900000, clients: 47, factures: 23 },
    { mois: 'Déc', ca: 134200000, clients: 48, factures: 28 },
    { mois: 'Jan', ca: 125450000, clients: 48, factures: 26 }
  ];

  const stats = [
    {
      id: 'clients',
      label: 'Clients actifs',
      value: '48',
      change: '+12%',
      changeType: 'positive' as const,
      icon: Users,
      color: 'blue'
    },
    {
      id: 'chiffre-affaires',
      label: 'CA mensuel',
      value: formatAmount(125450000),
      change: '+8.5%',
      changeType: 'positive' as const,
      icon: DollarSign,
      color: 'green'
    },
    {
      id: 'declarations',
      label: 'Déclarations à faire',
      value: '7',
      change: '-2',
      changeType: 'neutral' as const,
      icon: Calendar,
      color: 'orange'
    },
    {
      id: 'retards',
      label: 'En retard',
      value: '3',
      change: '+1',
      changeType: 'negative' as const,
      icon: AlertTriangle,
      color: 'red'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-2">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <span
                      className={`text-sm font-medium ${
                        stat.changeType === 'positive'
                          ? 'text-green-600'
                          : stat.changeType === 'negative'
                          ? 'text-red-600'
                          : 'text-gray-600'
                      }`}
                    >
                      {stat.change}
                    </span>
                    <span className="text-sm text-gray-500 ml-1">ce mois</span>
                  </div>
                </div>
                <div
                  className={`p-3 rounded-lg ${
                    stat.color === 'blue'
                      ? 'bg-blue-50 text-blue-600'
                      : stat.color === 'green'
                      ? 'bg-green-50 text-green-600'
                      : stat.color === 'orange'
                      ? 'bg-orange-50 text-orange-600'
                      : 'bg-red-50 text-red-600'
                  }`}
                >
                  <Icon className="h-6 w-6" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Activités récentes</h3>
            <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
              Voir tout
            </button>
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div
                  className={`p-2 rounded-lg ${
                    activity.status === 'completed'
                      ? 'bg-green-50 text-green-600'
                      : activity.status === 'new'
                      ? 'bg-blue-50 text-blue-600'
                      : 'bg-orange-50 text-orange-600'
                  }`}
                >
                  {activity.status === 'completed' ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : activity.status === 'new' ? (
                    <Users className="h-4 w-4" />
                  ) : (
                    <Clock className="h-4 w-4" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
                <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                  {CURRENCIES[activity.currency as keyof typeof CURRENCIES].flag} {CURRENCIES[activity.currency as keyof typeof CURRENCIES].symbol}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Currency Converter */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-green-50 rounded-lg">
              <Globe className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Convertisseur</h3>
              <p className="text-sm text-gray-600">Multi-devises</p>
            </div>
          </div>
          <CurrencyConverter />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Tasks */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Tâches à venir</h3>
            <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
              Planifier
            </button>
          </div>
          <div className="space-y-4">
            {upcomingTasks.map((task) => (
              <div key={task.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{task.description}</p>
                  <p className="text-xs text-gray-500 mt-1">Échéance: {task.deadline}</p>
                </div>
                <span
                  className={`px-2 py-1 text-xs font-medium rounded-full ${
                    task.priority === 'high'
                      ? 'bg-red-100 text-red-800'
                      : task.priority === 'medium'
                      ? 'bg-orange-100 text-orange-800'
                      : 'bg-green-100 text-green-800'
                  }`}
                >
                  {task.priority === 'high' ? 'Urgent' : task.priority === 'medium' ? 'Moyen' : 'Faible'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
              Performance mensuelle
            </h3>
            <select 
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="6-mois">6 derniers mois</option>
              <option value="12-mois">12 derniers mois</option>
              <option value="annee">Cette année</option>
            </select>
          </div>
          
          {/* Graphique en barres */}
          <div className="h-64 flex items-end justify-between space-x-2 mb-4 p-3 bg-gradient-to-t from-gray-50 to-white rounded-lg overflow-hidden">
            {performanceData.map((item, index) => {
              const maxValue = Math.max(...performanceData.map(d => d.ca));
              const height = (item.ca / maxValue) * 100;
              
              return (
                <div key={index} className="flex-1 flex flex-col items-center group">
                  <div className="w-full bg-gray-200 rounded-t-lg relative" style={{ height: '180px' }}>
                    <div
                      className="bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-lg absolute bottom-0 w-full transition-all duration-700 hover:from-blue-600 hover:to-blue-500 cursor-pointer"
                      style={{ height: `${height}%` }}
                      title={`${item.mois}: ${formatAmount(item.ca)}`}
                    ></div>
                    
                    {/* Tooltip au survol */}
                    <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs rounded-lg px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10">
                      <div className="text-center">
                        <div className="font-bold">{formatAmount(item.ca)}</div>
                        <div className="text-xs">{item.clients} clients</div>
                      </div>
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-2 h-2 bg-gray-900 rotate-45"></div>
                    </div>
                  </div>
                  <div className="mt-2 text-center">
                    <div className="text-xs font-medium text-gray-900">{item.mois}</div>
                    <div className="text-xs text-gray-500">{item.clients}c</div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Statistiques de performance */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-gray-200">
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {formatAmount(performanceData.reduce((sum, item) => sum + item.ca, 0))}
              </div>
              <div className="text-xs text-gray-600">CA Total</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {formatAmount(performanceData.reduce((sum, item) => sum + item.ca, 0) / performanceData.length)}
              </div>
              <div className="text-xs text-gray-600">CA Moyen</div>
            </div>
            <div className="text-center p-3 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {Math.max(...performanceData.map(d => d.clients))}
              </div>
              <div className="text-xs text-gray-600">Pic Clients</div>
            </div>
            <div className="text-center p-3 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                +{((performanceData[performanceData.length - 1].ca - performanceData[0].ca) / performanceData[0].ca * 100).toFixed(1)}%
              </div>
              <div className="text-xs text-gray-600">Croissance</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}