import React, { useState } from 'react';
import { Building, Users, Globe, Database, Download, Copy, ExternalLink, Plus, Settings, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

interface CabinetInstance {
  id: string;
  nom: string;
  expertComptable: string;
  url: string;
  statut: 'actif' | 'en-cours' | 'maintenance' | 'suspendu';
  dateCreation: Date;
  dernierAcces: Date;
  nombreUtilisateurs: number;
  nombreClients: number;
  version: string;
  pays: string;
}

const mockInstances: CabinetInstance[] = [
  {
    id: '1',
    nom: 'Cabinet KOUAME & Associés',
    expertComptable: 'Jean-Baptiste KOUAME',
    url: 'https://cabinet-kouame.caccompta.com',
    statut: 'actif',
    dateCreation: new Date('2024-01-15'),
    dernierAcces: new Date(),
    nombreUtilisateurs: 4,
    nombreClients: 48,
    version: '3.25',
    pays: 'Côte d\'Ivoire'
  },
  {
    id: '2',
    nom: 'Cabinet TRAORE Expertise',
    expertComptable: 'Aminata TRAORE',
    url: 'https://cabinet-traore.caccompta.com',
    statut: 'actif',
    dateCreation: new Date('2024-01-20'),
    dernierAcces: new Date(Date.now() - 2 * 60 * 60 * 1000),
    nombreUtilisateurs: 3,
    nombreClients: 32,
    version: '3.25',
    pays: 'Mali'
  },
  {
    id: '3',
    nom: 'CAGESI Cabinet',
    expertComptable: 'Mamadou DIALLO',
    url: 'https://cagesi-cabinet.caccompta.com',
    statut: 'en-cours',
    dateCreation: new Date(),
    dernierAcces: new Date(),
    nombreUtilisateurs: 1,
    nombreClients: 0,
    version: '3.25',
    pays: 'Mali'
  }
];

export default function InstallationManager() {
  const [instances, setInstances] = useState<CabinetInstance[]>(mockInstances);
  const [showNewInstallation, setShowNewInstallation] = useState(false);
  const [selectedInstance, setSelectedInstance] = useState<CabinetInstance | null>(null);

  const getStatutBadge = (statut: CabinetInstance['statut']) => {
    switch (statut) {
      case 'actif':
        return { class: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Actif' };
      case 'en-cours':
        return { class: 'bg-yellow-100 text-yellow-800', icon: Clock, label: 'En cours' };
      case 'maintenance':
        return { class: 'bg-blue-100 text-blue-800', icon: Settings, label: 'Maintenance' };
      case 'suspendu':
        return { class: 'bg-red-100 text-red-800', icon: AlertTriangle, label: 'Suspendu' };
      default:
        return { class: 'bg-gray-100 text-gray-800', icon: Clock, label: 'Inconnu' };
    }
  };

  const getCountryFlag = (pays: string) => {
    const flags: Record<string, string> = {
      'Côte d\'Ivoire': '🇨🇮',
      'Mali': '🇲🇱',
      'Sénégal': '🇸🇳',
      'Burkina Faso': '🇧🇫',
      'Niger': '🇳🇪',
      'Togo': '🇹🇬',
      'Bénin': '🇧🇯',
      'RD Congo': '🇨🇩',
      'Cameroun': '🇨🇲'
    };
    return flags[pays] || '🌍';
  };

  const getTotalStats = () => {
    return {
      totalCabinets: instances.length,
      cabinetActifs: instances.filter(i => i.statut === 'actif').length,
      totalUtilisateurs: instances.reduce((sum, i) => sum + i.nombreUtilisateurs, 0),
      totalClients: instances.reduce((sum, i) => sum + i.nombreClients, 0)
    };
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('✅ URL copiée dans le presse-papiers !');
  };

  const generateInstallationPackage = () => {
    const packageData = {
      instances: instances.map(instance => ({
        nom: instance.nom,
        url: instance.url,
        expertComptable: instance.expertComptable,
        pays: instance.pays,
        statut: instance.statut,
        dateCreation: instance.dateCreation,
        version: instance.version
      })),
      statistiques: getTotalStats(),
      dateGeneration: new Date().toISOString(),
      version: '3.25'
    };

    const dataStr = JSON.stringify(packageData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `installations-caccompta-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
  };

  const stats = getTotalStats();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gestionnaire d'Installations</h3>
          <p className="text-sm text-gray-600 mt-1">
            Gestion centralisée des instances CACCompta V3.25
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={generateInstallationPackage}
            className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span>Export Global</span>
          </button>
          <button
            onClick={() => setShowNewInstallation(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Nouvelle Installation</span>
          </button>
        </div>
      </div>

      {/* Global Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total Cabinets</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalCabinets}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Building className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Cabinets Actifs</p>
              <p className="text-2xl font-bold text-green-600">{stats.cabinetActifs}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total Utilisateurs</p>
              <p className="text-2xl font-bold text-purple-600">{stats.totalUtilisateurs}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total Clients</p>
              <p className="text-2xl font-bold text-orange-600">{stats.totalClients}</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg">
              <Database className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Instances List */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h4 className="text-lg font-semibold text-gray-900">Instances Déployées</h4>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cabinet
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  URL d'Accès
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Utilisateurs
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Clients
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dernier Accès
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {instances.map((instance) => {
                const statusInfo = getStatutBadge(instance.statut);
                const StatusIcon = statusInfo.icon;
                
                return (
                  <tr key={instance.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          <Building className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{instance.nom}</div>
                          <div className="text-sm text-gray-500">{instance.expertComptable}</div>
                          <div className="text-xs text-gray-400 flex items-center space-x-1">
                            <span>{getCountryFlag(instance.pays)}</span>
                            <span>{instance.pays}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <code className="text-sm bg-gray-100 px-2 py-1 rounded text-blue-600">
                          {instance.url}
                        </code>
                        <button
                          onClick={() => copyToClipboard(instance.url)}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full ${statusInfo.class}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {statusInfo.label}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span>{instance.nombreUtilisateurs}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center space-x-1">
                        <Database className="h-4 w-4 text-gray-400" />
                        <span>{instance.nombreClients}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div>
                        {instance.dernierAcces.toLocaleDateString('fr-FR')}
                        <div className="text-xs text-gray-500">
                          {instance.dernierAcces.toLocaleTimeString('fr-FR')}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center space-x-2">
                        <a
                          href={instance.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800"
                          title="Ouvrir l'instance"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                        <button
                          onClick={() => setSelectedInstance(instance)}
                          className="text-gray-600 hover:text-gray-800"
                          title="Voir les détails"
                        >
                          <Settings className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Instance Detail Modal */}
      {selectedInstance && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {selectedInstance.nom}
                  </h3>
                  <p className="text-sm text-gray-600">{selectedInstance.expertComptable}</p>
                </div>
                <button
                  onClick={() => setSelectedInstance(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Informations Techniques</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">URL d'accès:</span>
                      <code className="text-blue-600 bg-gray-100 px-2 py-1 rounded text-xs">
                        {selectedInstance.url}
                      </code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Version:</span>
                      <span className="font-medium">v{selectedInstance.version}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date création:</span>
                      <span>{selectedInstance.dateCreation.toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Dernier accès:</span>
                      <span>{selectedInstance.dernierAcces.toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Pays:</span>
                      <span>{getCountryFlag(selectedInstance.pays)} {selectedInstance.pays}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Statistiques d'Usage</h4>
                  <div className="space-y-3">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-blue-800 text-sm">Utilisateurs</span>
                        <span className="text-blue-600 font-bold text-lg">{selectedInstance.nombreUtilisateurs}</span>
                      </div>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-green-800 text-sm">Clients</span>
                        <span className="text-green-600 font-bold text-lg">{selectedInstance.nombreClients}</span>
                      </div>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-purple-800 text-sm">Statut</span>
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${getStatutBadge(selectedInstance.statut).class}`}>
                          {getStatutBadge(selectedInstance.statut).label}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200 flex justify-end space-x-3">
                <button
                  onClick={() => copyToClipboard(selectedInstance.url)}
                  className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2"
                >
                  <Copy className="h-4 w-4" />
                  <span>Copier URL</span>
                </button>
                <a
                  href={selectedInstance.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>Ouvrir</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Installation Guide */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">📋 Guide d'Installation Multi-Cabinets</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-gray-900 mb-3">🏗️ Processus d'Installation</h5>
            <ol className="text-sm text-gray-700 space-y-2">
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">1</span>
                <span>Collecte des informations du cabinet</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">2</span>
                <span>Configuration technique et préférences</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">3</span>
                <span>Déploiement automatique sur Bolt Hosting</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">4</span>
                <span>Formation et remise des accès</span>
              </li>
            </ol>
          </div>

          <div>
            <h5 className="font-medium text-gray-900 mb-3">⚡ Avantages Techniques</h5>
            <ul className="text-sm text-gray-700 space-y-2">
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Instance dédiée par cabinet</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Base de données isolée</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>SSL automatique</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Sauvegarde quotidienne</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Mises à jour automatiques</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <h5 className="font-medium text-orange-900 mb-2">📞 Support Installation</h5>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-orange-800"><strong>Cabinet CAGESI</strong></p>
              <p className="text-orange-700">Tél: +223 90 14 78 57 / +223 75 44 74 41</p>
              <p className="text-orange-700">Email: info@cagesicabinet.com</p>
            </div>
            <div>
              <p className="text-orange-800"><strong>Services Inclus</strong></p>
              <p className="text-orange-700">• Installation et configuration</p>
              <p className="text-orange-700">• Formation initiale (2h)</p>
              <p className="text-orange-700">• Support technique 6 mois</p>
            </div>
          </div>
        </div>
      </div>

      {instances.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune Installation</h3>
          <p className="text-gray-600 mb-4">
            Commencez par créer votre première installation de cabinet
          </p>
          <button
            onClick={() => setShowNewInstallation(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 mx-auto"
          >
            <Plus className="h-5 w-5" />
            <span>Première Installation</span>
          </button>
        </div>
      )}
    </div>
  );
}