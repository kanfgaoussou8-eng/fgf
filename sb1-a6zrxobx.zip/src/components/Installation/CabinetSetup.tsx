import React, { useState } from 'react';
import { Building, User, Globe, Database, Check, ArrowRight, Download, Copy, ExternalLink } from 'lucide-react';
import { CABINET_CONFIG } from '../Parametres/Parametres';

interface CabinetInfo {
  nom: string;
  expertComptable: string;
  numeroOrdre: string;
  adresse: string;
  telephone: string;
  email: string;
  siteWeb: string;
  logo: string;
  devise: 'XOF' | 'USD' | 'EUR' | 'CDF';
  pays: string;
  ville: string;
}

interface InstallationStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  current: boolean;
}

export default function CabinetSetup() {
  const [currentStep, setCurrentStep] = useState(0);
  const [cabinetData, setCabinetData] = useState<CabinetInfo>({
    nom: '',
    expertComptable: '',
    numeroOrdre: '',
    adresse: '',
    telephone: '',
    email: '',
    siteWeb: '',
    logo: '',
    devise: 'XOF',
    pays: 'Côte d\'Ivoire',
    ville: ''
  });

  const [deploymentUrl, setDeploymentUrl] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentComplete, setDeploymentComplete] = useState(false);

  const steps: InstallationStep[] = [
    {
      id: 'cabinet-info',
      title: 'Informations du Cabinet',
      description: 'Renseignez les informations de base du cabinet',
      completed: false,
      current: true
    },
    {
      id: 'configuration',
      title: 'Configuration Technique',
      description: 'Paramètres système et préférences',
      completed: false,
      current: false
    },
    {
      id: 'deployment',
      title: 'Déploiement',
      description: 'Installation et mise en ligne',
      completed: false,
      current: false
    },
    {
      id: 'access',
      title: 'Accès et Formation',
      description: 'Comptes utilisateurs et documentation',
      completed: false,
      current: false
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCabinetData(prev => ({ ...prev, [name]: value }));
  };

  const generateSubdomain = () => {
    if (!cabinetData.nom) return '';
    return cabinetData.nom
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  };

  const generateDeploymentUrl = () => {
    const subdomain = generateSubdomain();
    return `https://${subdomain}.caccompta.com`;
  };

  const handleDeploy = async () => {
    setIsDeploying(true);
    
    // Simulation du déploiement
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const url = generateDeploymentUrl();
    setDeploymentUrl(url);
    setDeploymentComplete(true);
    setIsDeploying(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('✅ Copié dans le presse-papiers !');
  };

  const generateConfigFile = () => {
    const config = {
      cabinet: cabinetData,
      installation: {
        date: new Date().toISOString(),
        version: '3.25',
        url: deploymentUrl
      },
      users: [
        {
          nom: cabinetData.expertComptable.split(' ')[1] || 'EXPERT',
          prenom: cabinetData.expertComptable.split(' ')[0] || 'Expert',
          email: cabinetData.email,
          role: 'expert-comptable',
          password: 'admin123'
        }
      ]
    };

    const configStr = JSON.stringify(config, null, 2);
    const blob = new Blob([configStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `config-${generateSubdomain()}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom du Cabinet <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="nom"
                  value={cabinetData.nom}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Cabinet KOUAME & Associés"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expert-Comptable <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="expertComptable"
                  value={cabinetData.expertComptable}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Jean-Baptiste KOUAME"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  N° Ordre OEC <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="numeroOrdre"
                  value={cabinetData.numeroOrdre}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="OEC-CI-2024-XXX"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={cabinetData.email}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="contact@cabinet.ci"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Téléphone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="telephone"
                  value={cabinetData.telephone}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="+225 27 20 12 34 56"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pays
                </label>
                <select
                  name="pays"
                  value={cabinetData.pays}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Côte d'Ivoire">🇨🇮 Côte d'Ivoire</option>
                  <option value="Sénégal">🇸🇳 Sénégal</option>
                  <option value="Mali">🇲🇱 Mali</option>
                  <option value="Burkina Faso">🇧🇫 Burkina Faso</option>
                  <option value="Niger">🇳🇪 Niger</option>
                  <option value="Guinée-Bissau">🇬🇼 Guinée-Bissau</option>
                  <option value="Togo">🇹🇬 Togo</option>
                  <option value="Bénin">🇧🇯 Bénin</option>
                  <option value="RD Congo">🇨🇩 RD Congo</option>
                  <option value="Cameroun">🇨🇲 Cameroun</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Adresse Complète <span className="text-red-500">*</span>
                </label>
                <textarea
                  name="adresse"
                  value={cabinetData.adresse}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Adresse complète du cabinet"
                />
              </div>
            </div>

            {cabinetData.nom && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-medium text-blue-900 mb-2">🌐 URL de déploiement prévue</h4>
                <p className="text-blue-800 font-mono text-lg">{generateDeploymentUrl()}</p>
                <p className="text-blue-700 text-sm mt-1">Cette URL sera créée lors du déploiement</p>
              </div>
            )}
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Devise Principale
                </label>
                <select
                  name="devise"
                  value={cabinetData.devise}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="XOF">🇨🇮 FCFA (XOF) - Franc CFA BCEAO</option>
                  <option value="USD">🇺🇸 USD - Dollar Américain</option>
                  <option value="EUR">🇪🇺 EUR - Euro</option>
                  <option value="CDF">🇨🇩 CDF - Franc Congolais</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Site Web
                </label>
                <input
                  type="url"
                  name="siteWeb"
                  value={cabinetData.siteWeb}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://www.cabinet.ci"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Logo du Cabinet (URL)
                </label>
                <input
                  type="url"
                  name="logo"
                  value={cabinetData.logo}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://exemple.com/logo.png"
                />
                <p className="text-xs text-gray-500 mt-1">
                  URL d'une image accessible publiquement (PNG, JPG, SVG)
                </p>
              </div>
            </div>

            {cabinetData.logo && (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Aperçu du logo :</p>
                <img
                  src={cabinetData.logo}
                  alt="Logo du cabinet"
                  className="h-16 w-16 object-contain border border-gray-200 rounded bg-white p-2"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
            )}

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-medium text-green-900 mb-2">✅ Configuration Technique</h4>
              <ul className="text-green-800 text-sm space-y-1">
                <li>• Base de données dédiée pour ce cabinet</li>
                <li>• Chiffrement SSL automatique</li>
                <li>• Sauvegarde automatique quotidienne</li>
                <li>• Conformité OHADA intégrée</li>
                <li>• Support multi-devises activé</li>
              </ul>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="p-6 bg-blue-50 rounded-lg border border-blue-200 mb-6">
                <h4 className="text-lg font-semibold text-blue-900 mb-2">🚀 Prêt pour le Déploiement</h4>
                <p className="text-blue-800">
                  Votre instance CACCompta V3.25 va être déployée sur :
                </p>
                <p className="text-xl font-mono text-blue-600 mt-2">{generateDeploymentUrl()}</p>
              </div>

              {!deploymentComplete ? (
                <button
                  onClick={handleDeploy}
                  disabled={isDeploying}
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-3 mx-auto disabled:opacity-50"
                >
                  {isDeploying ? (
                    <>
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                      <span>Déploiement en cours...</span>
                    </>
                  ) : (
                    <>
                      <Database className="h-6 w-6" />
                      <span>Lancer le Déploiement</span>
                    </>
                  )}
                </button>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                    <div className="flex items-center justify-center space-x-3 mb-4">
                      <Check className="h-8 w-8 text-green-600" />
                      <h4 className="text-lg font-semibold text-green-900">Déploiement Réussi !</h4>
                    </div>
                    <p className="text-green-800 text-center mb-4">
                      Votre instance CACCompta V3.25 est maintenant en ligne
                    </p>
                    
                    <div className="flex items-center justify-center space-x-4">
                      <button
                        onClick={() => copyToClipboard(deploymentUrl)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                      >
                        <Copy className="h-4 w-4" />
                        <span>Copier l'URL</span>
                      </button>
                      
                      <a
                        href={deploymentUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>Ouvrir le Site</span>
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {isDeploying && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-medium text-yellow-900 mb-2">⚙️ Étapes du Déploiement</h4>
                <div className="space-y-2 text-yellow-800 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-600"></div>
                    <span>Création de l'instance...</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="animate-pulse w-4 h-4 bg-yellow-400 rounded-full"></div>
                    <span>Configuration de la base de données...</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="animate-pulse w-4 h-4 bg-yellow-400 rounded-full"></div>
                    <span>Installation des paramètres du cabinet...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-lg p-6">
              <h4 className="text-lg font-semibold text-green-900 mb-4">🎉 Installation Terminée !</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-medium text-green-900 mb-2">📍 Accès à votre logiciel</h5>
                  <div className="bg-white border border-green-200 rounded p-3">
                    <p className="text-sm text-gray-600">URL d'accès :</p>
                    <p className="font-mono text-blue-600 break-all">{deploymentUrl}</p>
                    <button
                      onClick={() => copyToClipboard(deploymentUrl)}
                      className="text-xs text-green-600 hover:text-green-800 mt-1"
                    >
                      📋 Copier l'URL
                    </button>
                  </div>
                </div>

                <div>
                  <h5 className="font-medium text-green-900 mb-2">👤 Compte Administrateur</h5>
                  <div className="bg-white border border-green-200 rounded p-3 text-sm">
                    <p><strong>Email :</strong> {cabinetData.email}</p>
                    <p><strong>Mot de passe :</strong> admin123</p>
                    <p className="text-xs text-gray-600 mt-1">
                      ⚠️ Changez ce mot de passe lors de la première connexion
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h4 className="font-medium text-blue-900 mb-4">📚 Prochaines Étapes</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">1</div>
                    <div>
                      <p className="font-medium text-blue-900">Première Connexion</p>
                      <p className="text-blue-700 text-sm">Connectez-vous et changez le mot de passe</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">2</div>
                    <div>
                      <p className="font-medium text-blue-900">Créer les Utilisateurs</p>
                      <p className="text-blue-700 text-sm">Ajoutez vos assistants et stagiaires</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">3</div>
                    <div>
                      <p className="font-medium text-blue-900">Ajouter les Clients</p>
                      <p className="text-blue-700 text-sm">Importez votre portefeuille client</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">4</div>
                    <div>
                      <p className="font-medium text-blue-900">Formation Équipe</p>
                      <p className="text-blue-700 text-sm">Formez votre équipe à l'utilisation</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">5</div>
                    <div>
                      <p className="font-medium text-blue-900">Migration Données</p>
                      <p className="text-blue-700 text-sm">Importez vos données existantes</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">6</div>
                    <div>
                      <p className="font-medium text-blue-900">Mise en Production</p>
                      <p className="text-blue-700 text-sm">Commencez l'utilisation quotidienne</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
              <h4 className="font-medium text-orange-900 mb-4">📞 Support et Formation</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-medium text-orange-900 mb-2">Support Technique CAGESI</h5>
                  <div className="text-orange-800 text-sm space-y-1">
                    <p><strong>Téléphone 1 :</strong> +223 90 14 78 57</p>
                    <p><strong>Téléphone 2 :</strong> +223 75 44 74 41</p>
                    <p><strong>Email :</strong> info@cagesicabinet.com</p>
                    <p><strong>WhatsApp :</strong> +223 90 14 78 57</p>
                  </div>
                </div>
                
                <div>
                  <h5 className="font-medium text-orange-900 mb-2">Services Inclus</h5>
                  <div className="text-orange-800 text-sm space-y-1">
                    <p>✅ Formation initiale (2h)</p>
                    <p>✅ Support technique 6 mois</p>
                    <p>✅ Télé-assistance incluse</p>
                    <p>✅ Mises à jour automatiques</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-4">
              <button
                onClick={generateConfigFile}
                className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors flex items-center space-x-2"
              >
                <Download className="h-5 w-5" />
                <span>Télécharger la Configuration</span>
              </button>
              
              <a
                href={deploymentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
              >
                <ExternalLink className="h-5 w-5" />
                <span>Accéder au Logiciel</span>
              </a>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceedToNext = () => {
    switch (currentStep) {
      case 0:
        return cabinetData.nom && cabinetData.expertComptable && cabinetData.numeroOrdre && 
               cabinetData.email && cabinetData.telephone && cabinetData.adresse;
      case 1:
        return true;
      case 2:
        return deploymentComplete;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Building className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Installation Multi-Cabinets</h1>
              <p className="text-gray-600">CACCompta V3.25 - Configuration Personnalisée</p>
            </div>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  index <= currentStep 
                    ? 'bg-blue-600 border-blue-600 text-white' 
                    : 'bg-white border-gray-300 text-gray-400'
                }`}>
                  {index < currentStep ? (
                    <Check className="h-5 w-5" />
                  ) : (
                    <span className="text-sm font-bold">{index + 1}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-24 h-1 mx-4 ${
                    index < currentStep ? 'bg-blue-600' : 'bg-gray-300'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-4 text-center">
            <h3 className="text-lg font-semibold text-gray-900">{steps[currentStep].title}</h3>
            <p className="text-gray-600">{steps[currentStep].description}</p>
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
          {renderStepContent()}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Précédent
          </button>

          {currentStep < steps.length - 1 ? (
            <button
              onClick={() => setCurrentStep(currentStep + 1)}
              disabled={!canProceedToNext()}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span>Suivant</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <div className="text-sm text-gray-500">
              Installation terminée ✅
            </div>
          )}
        </div>

        {/* Installation Guide */}
        <div className="mt-12 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">📋 Guide d'Installation Multi-Cabinets</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="p-3 bg-blue-600 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <Database className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-medium text-blue-900 mb-2">Instance Dédiée</h4>
              <p className="text-blue-800 text-sm">
                Chaque cabinet a sa propre instance avec base de données isolée
              </p>
            </div>

            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="p-3 bg-green-600 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <User className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-medium text-green-900 mb-2">Multi-Utilisateurs</h4>
              <p className="text-green-800 text-sm">
                Gestion complète des rôles et permissions par cabinet
              </p>
            </div>

            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="p-3 bg-purple-600 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <h4 className="font-medium text-purple-900 mb-2">Accès Sécurisé</h4>
              <p className="text-purple-800 text-sm">
                HTTPS, authentification et sauvegarde automatique
              </p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h5 className="font-medium text-gray-900 mb-2">💡 Avantages de cette Approche</h5>
            <ul className="text-gray-700 text-sm space-y-1">
              <li>✅ <strong>Sécurité maximale :</strong> Données complètement isolées entre cabinets</li>
              <li>✅ <strong>Personnalisation totale :</strong> Chaque cabinet a ses paramètres</li>
              <li>✅ <strong>Performance optimale :</strong> Pas de partage de ressources</li>
              <li>✅ <strong>Conformité OHADA :</strong> Respect total de la confidentialité</li>
              <li>✅ <strong>Évolutivité :</strong> Ajout facile de nouveaux cabinets</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}