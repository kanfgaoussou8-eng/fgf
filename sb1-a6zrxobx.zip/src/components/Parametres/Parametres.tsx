import React, { useState, useEffect } from 'react';
import { Settings, Building, User, Globe, Save, RefreshCw, Download, FileText, Users, Shield, Bell, Database, Palette, Lock } from 'lucide-react';
import UserManagement from './UserManagement';
import { UserManualGenerator } from './UserManualGenerator';
import CurrencySelector from '../Currency/CurrencySelector';
import { useCurrency } from '../../contexts/CurrencyContext';
import { type Currency } from '../../utils/currency';

// Configuration du cabinet avec sauvegarde localStorage
const CABINET_CONFIG = {
  nom: 'Cabinet KOUAME & Associés',
  expertComptable: 'Jean-Baptiste KOUAME',
  numeroOrdre: 'OEC-CI-2020-456',
  adresse: 'Cocody Riviera Golf, Abidjan, Côte d\'Ivoire',
  telephone: '+225 27 20 12 34 56',
  mobile: '+225 07 12 34 56 78',
  email: 'contact@cabinet-kouame.ci',
  siteWeb: 'www.cabinet-kouame.ci',
  numeroRCCM: 'CI-ABJ-2020-B-12345',
  numeroContribuable: '12345678901234',
  logo: '',
  coordonneesBancaires: 'SGBCI - Société Générale de Banques en Côte d\'Ivoire\nCompte N°: 12345678901234567890\nCode SWIFT: SGBCCIAB\nIBAN: CI93 SGBC 1234 5678 9012 3456 7890',
  conditionsPaiement: 'Paiement à 30 jours fin de mois\nPénalités de retard: 1,5% par mois\nEscompte 2% pour paiement à 10 jours',
  mentionsLegales: 'Cabinet inscrit à l\'Ordre des Experts-Comptables de Côte d\'Ivoire\nSociété d\'expertise comptable agréée\nAssurance professionnelle: NSIA Assurances',
  devise: 'XOF' as Currency,
  tauxTVA: 18,
  exerciceFiscal: {
    debut: '01/01',
    fin: '31/12'
  },
  sauvegarde: {
    automatique: true,
    frequence: 'quotidienne',
    conservation: 7
  }
};

// Fonction pour charger la configuration depuis localStorage
const loadConfiguration = () => {
  try {
    const savedConfig = localStorage.getItem('cabinet-configuration');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      return { ...CABINET_CONFIG, ...parsed };
    }
  } catch (error) {
    console.error('Erreur lors du chargement de la configuration:', error);
  }
  return CABINET_CONFIG;
};

// Fonction pour sauvegarder la configuration dans localStorage
const saveConfiguration = (config: typeof CABINET_CONFIG) => {
  try {
    localStorage.setItem('cabinet-configuration', JSON.stringify(config));
    return true;
  } catch (error) {
    console.error('Erreur lors de la sauvegarde de la configuration:', error);
    return false;
  }
};

export default function Parametres() {
  const { globalCurrency, setGlobalCurrency } = useCurrency();
  const [activeTab, setActiveTab] = useState('cabinet');
  const [config, setConfig] = useState(loadConfiguration());
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  // Charger la configuration au montage du composant
  useEffect(() => {
    const loadedConfig = loadConfiguration();
    setConfig(loadedConfig);
  }, []);

  const handleConfigChange = (field: string, value: any) => {
    setConfig(prev => {
      const newConfig = { ...prev, [field]: value };
      setHasChanges(true);
      return newConfig;
    });
  };

  const handleNestedConfigChange = (section: string, field: string, value: any) => {
    setConfig(prev => {
      const newConfig = {
        ...prev,
        [section]: {
          ...prev[section as keyof typeof prev],
          [field]: value
        }
      };
      setHasChanges(true);
      return newConfig;
    });
  };

  const handleSaveConfiguration = async () => {
    setIsSaving(true);
    setSaveMessage('');

    try {
      // Validation des champs obligatoires
      if (!config.nom.trim()) {
        setSaveMessage('❌ Le nom du cabinet est obligatoire');
        setIsSaving(false);
        return;
      }

      if (!config.expertComptable.trim()) {
        setSaveMessage('❌ Le nom de l\'expert-comptable est obligatoire');
        setIsSaving(false);
        return;
      }

      if (!config.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(config.email)) {
        setSaveMessage('❌ Un email valide est obligatoire');
        setIsSaving(false);
        return;
      }

      // Simulation d'une sauvegarde (délai pour l'UX)
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Sauvegarder dans localStorage
      const success = saveConfiguration(config);
      
      if (success) {
        setSaveMessage('✅ Configuration sauvegardée avec succès !');
        setHasChanges(false);
        
        // Mettre à jour la devise globale si elle a changé
        if (config.devise !== globalCurrency) {
          setGlobalCurrency(config.devise);
        }
        
        // Effacer le message après 3 secondes
        setTimeout(() => setSaveMessage(''), 3000);
      } else {
        setSaveMessage('❌ Erreur lors de la sauvegarde');
      }
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      setSaveMessage('❌ Erreur technique lors de la sauvegarde');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetConfiguration = () => {
    if (confirm('Êtes-vous sûr de vouloir restaurer la configuration par défaut ? Toutes les modifications seront perdues.')) {
      setConfig(CABINET_CONFIG);
      setHasChanges(true);
      setSaveMessage('⚠️ Configuration restaurée - N\'oubliez pas de sauvegarder');
    }
  };

  const handleExportConfiguration = () => {
    try {
      const configToExport = {
        ...config,
        exportDate: new Date().toISOString(),
        version: '3.25'
      };
      
      const dataStr = JSON.stringify(configToExport, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `configuration-cabinet-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      
      URL.revokeObjectURL(url);
      setSaveMessage('📁 Configuration exportée avec succès');
      setTimeout(() => setSaveMessage(''), 3000);
    } catch (error) {
      console.error('Erreur lors de l\'export:', error);
      setSaveMessage('❌ Erreur lors de l\'export');
    }
  };

  const handleGenerateManual = () => {
    const format = prompt(
      'Choisissez le format du manuel d\'utilisation:\n\n' +
      '1 - Manuel PDF (.pdf)\n' +
      '2 - Manuel HTML imprimable (.html)\n' +
      '3 - Aperçu et impression directe\n\n' +
      'Tapez le numéro de votre choix (1-3):'
    );

    if (!format || !['1', '2', '3'].includes(format)) {
      return;
    }

    try {
      const timestamp = new Date().toISOString().split('T')[0];

      switch (format) {
        case '1':
          UserManualGenerator.generatePDFManual();
          setSaveMessage('📄 Manuel PDF généré et téléchargé avec succès !');
          break;

        case '2':
          const htmlManual = UserManualGenerator.generateHTMLManual();
          UserManualGenerator.downloadManual(htmlManual, `manuel-utilisateur-${timestamp}.html`, 'html');
          setSaveMessage('🌐 Manuel HTML généré et téléchargé avec succès !');
          break;

        case '3':
          const printableManual = UserManualGenerator.generateHTMLManual();
          UserManualGenerator.openPrintableManual(printableManual);
          break;
      }

      if (format !== '3') {
        setTimeout(() => setSaveMessage(''), 3000);
      }
    } catch (error) {
      console.error('Erreur lors de la génération du manuel:', error);
      setSaveMessage('❌ Erreur lors de la génération du manuel');
    }
  };

  const renderCabinetConfig = () => (
    <div className="space-y-6">
      {/* Informations générales */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Building className="h-5 w-5 mr-2 text-blue-600" />
          Informations du Cabinet
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nom du cabinet <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={config.nom}
              onChange={(e) => handleConfigChange('nom', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Cabinet KOUAME & Associés"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Expert-Comptable <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={config.expertComptable}
              onChange={(e) => handleConfigChange('expertComptable', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Jean-Baptiste KOUAME"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              N° Ordre OEC <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={config.numeroOrdre}
              onChange={(e) => handleConfigChange('numeroOrdre', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="OEC-CI-2020-456"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              value={config.email}
              onChange={(e) => handleConfigChange('email', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="contact@cabinet.ci"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Téléphone <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              value={config.telephone}
              onChange={(e) => handleConfigChange('telephone', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="+225 27 20 12 34 56"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mobile
            </label>
            <input
              type="tel"
              value={config.mobile}
              onChange={(e) => handleConfigChange('mobile', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="+225 07 12 34 56 78"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Adresse complète <span className="text-red-500">*</span>
            </label>
            <textarea
              value={config.adresse}
              onChange={(e) => handleConfigChange('adresse', e.target.value)}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Adresse complète du cabinet"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Site web
            </label>
            <input
              type="url"
              value={config.siteWeb}
              onChange={(e) => handleConfigChange('siteWeb', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="www.cabinet.ci"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              N° RCCM
            </label>
            <input
              type="text"
              value={config.numeroRCCM}
              onChange={(e) => handleConfigChange('numeroRCCM', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="CI-ABJ-2020-B-12345"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              N° Contribuable
            </label>
            <input
              type="text"
              value={config.numeroContribuable}
              onChange={(e) => handleConfigChange('numeroContribuable', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="14 chiffres"
              maxLength={14}
            />
          </div>
        </div>
      </div>

      {/* Logo et identité visuelle */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Palette className="h-5 w-5 mr-2 text-purple-600" />
          Logo et Identité Visuelle
        </h4>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              URL du logo
            </label>
            <input
              type="url"
              value={config.logo}
              onChange={(e) => handleConfigChange('logo', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="https://exemple.com/logo.png"
            />
            <p className="text-xs text-gray-500 mt-1">
              URL d'une image accessible publiquement (PNG, JPG, SVG)
            </p>
          </div>

          {/* Aperçu du logo */}
          {config.logo && (
            <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
              <p className="text-sm font-medium text-gray-700 mb-2">Aperçu du logo :</p>
              <div className="flex items-center space-x-4">
                <img
                  src={config.logo}
                  alt="Logo du cabinet"
                  className="h-16 w-16 object-contain border border-gray-200 rounded bg-white p-2"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
                <div className="text-sm text-gray-600">
                  <p>✅ Logo chargé avec succès</p>
                  <p>Sera affiché sur les factures et rapports</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Paramètres financiers */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Globe className="h-5 w-5 mr-2 text-green-600" />
          Paramètres Financiers
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <CurrencySelector
            selectedCurrency={config.devise}
            onCurrencyChange={(currency) => handleConfigChange('devise', currency)}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Taux TVA par défaut (%)
            </label>
            <select
              value={config.tauxTVA}
              onChange={(e) => handleConfigChange('tauxTVA', parseInt(e.target.value))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={0}>0% (Exonéré)</option>
              <option value={9}>9% (Taux réduit)</option>
              <option value={18}>18% (Taux normal)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Début d'exercice fiscal
            </label>
            <input
              type="text"
              value={config.exerciceFiscal.debut}
              onChange={(e) => handleNestedConfigChange('exerciceFiscal', 'debut', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="01/01"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fin d'exercice fiscal
            </label>
            <input
              type="text"
              value={config.exerciceFiscal.fin}
              onChange={(e) => handleNestedConfigChange('exerciceFiscal', 'fin', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="31/12"
            />
          </div>
        </div>
      </div>

      {/* Coordonnées bancaires */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Database className="h-5 w-5 mr-2 text-indigo-600" />
          Coordonnées Bancaires
        </h4>
        <textarea
          value={config.coordonneesBancaires}
          onChange={(e) => handleConfigChange('coordonneesBancaires', e.target.value)}
          rows={4}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Informations bancaires complètes..."
        />
        <p className="text-xs text-gray-500 mt-1">
          Ces informations apparaîtront sur les factures
        </p>
      </div>

      {/* Conditions de paiement */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Conditions de Paiement</h4>
        <textarea
          value={config.conditionsPaiement}
          onChange={(e) => handleConfigChange('conditionsPaiement', e.target.value)}
          rows={3}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Conditions de paiement par défaut..."
        />
      </div>

      {/* Mentions légales */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Mentions Légales</h4>
        <textarea
          value={config.mentionsLegales}
          onChange={(e) => handleConfigChange('mentionsLegales', e.target.value)}
          rows={3}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Mentions légales et informations réglementaires..."
        />
      </div>
    </div>
  );

  const renderSystemConfig = () => (
    <div className="space-y-6">
      {/* Paramètres de sauvegarde */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Database className="h-5 w-5 mr-2 text-green-600" />
          Sauvegarde et Sécurité
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                checked={config.sauvegarde.automatique}
                onChange={(e) => handleNestedConfigChange('sauvegarde', 'automatique', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="text-sm font-medium text-gray-700">
                Sauvegarde automatique
              </span>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fréquence de sauvegarde
            </label>
            <select
              value={config.sauvegarde.frequence}
              onChange={(e) => handleNestedConfigChange('sauvegarde', 'frequence', e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={!config.sauvegarde.automatique}
            >
              <option value="horaire">Toutes les heures</option>
              <option value="quotidienne">Quotidienne</option>
              <option value="hebdomadaire">Hebdomadaire</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Conservation (jours)
            </label>
            <input
              type="number"
              value={config.sauvegarde.conservation}
              onChange={(e) => handleNestedConfigChange('sauvegarde', 'conservation', parseInt(e.target.value))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              min="1"
              max="365"
            />
          </div>
        </div>
      </div>

      {/* Actions système */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Actions Système</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={handleExportConfiguration}
            className="flex items-center justify-center space-x-2 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Download className="h-5 w-5 text-blue-600" />
            <span>Exporter la configuration</span>
          </button>

          <button
            onClick={handleGenerateManual}
            className="flex items-center justify-center space-x-2 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <FileText className="h-5 w-5 text-green-600" />
            <span>Générer le manuel</span>
          </button>

          <button
            onClick={handleResetConfiguration}
            className="flex items-center justify-center space-x-2 p-4 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors"
          >
            <RefreshCw className="h-5 w-5" />
            <span>Restaurer par défaut</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header avec bouton de sauvegarde */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Paramètres du Cabinet</h3>
          <p className="text-sm text-gray-600 mt-1">
            Configuration générale et préférences du cabinet
          </p>
        </div>
        <div className="flex items-center space-x-3">
          {hasChanges && (
            <span className="text-sm text-orange-600 font-medium">
              Modifications non sauvegardées
            </span>
          )}
          <button
            onClick={handleSaveConfiguration}
            disabled={isSaving || !hasChanges}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="h-4 w-4" />
            <span>{isSaving ? 'Sauvegarde...' : 'Sauvegarder'}</span>
          </button>
        </div>
      </div>

      {/* Message de sauvegarde */}
      {saveMessage && (
        <div className={`p-4 rounded-lg border ${
          saveMessage.includes('✅') 
            ? 'bg-green-50 border-green-200 text-green-800'
            : saveMessage.includes('❌')
            ? 'bg-red-50 border-red-200 text-red-800'
            : 'bg-orange-50 border-orange-200 text-orange-800'
        }`}>
          <p className="text-sm font-medium">{saveMessage}</p>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('cabinet')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'cabinet'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Configuration Cabinet
            </button>
            <button
              onClick={() => setActiveTab('utilisateurs')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'utilisateurs'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Gestion des Utilisateurs
            </button>
            <button
              onClick={() => setActiveTab('systeme')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'systeme'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Paramètres Système
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'cabinet' && renderCabinetConfig()}
          {activeTab === 'utilisateurs' && <UserManagement />}
          {activeTab === 'systeme' && renderSystemConfig()}
        </div>
      </div>
    </div>
  );
}

// Export de la configuration pour utilisation dans d'autres composants
export { CABINET_CONFIG, loadConfiguration, saveConfiguration };