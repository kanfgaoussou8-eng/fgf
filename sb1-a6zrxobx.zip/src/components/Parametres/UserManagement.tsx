import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, CreditCard as Edit, Trash2, User, Shield, Users, Mail, Phone, Calendar, CheckCircle, XCircle, Clock, X } from 'lucide-react';
import { mockUsers } from '../../contexts/AuthContext';
import type { User as UserType } from '../../types';
import NewUserModal from './NewUserModal';
import EditUserModal from './EditUserModal';

const roleLabels = {
  'expert-comptable': 'Expert-Comptable',
  'assistant': 'Assistant Comptable',
  'stagiaire': 'Stagiaire',
  'admin': 'Administrateur'
};

const roleColors = {
  'expert-comptable': 'bg-blue-100 text-blue-800',
  'assistant': 'bg-green-100 text-green-800',
  'stagiaire': 'bg-orange-100 text-orange-800',
  'admin': 'bg-purple-100 text-purple-800'
};

const roleIcons = {
  'expert-comptable': Shield,
  'assistant': Users,
  'stagiaire': User,
  'admin': Shield
};

const statutColors = {
  'actif': 'bg-green-100 text-green-800',
  'inactif': 'bg-gray-100 text-gray-800',
  'suspendu': 'bg-red-100 text-red-800'
};

export default function UserManagement() {
  const [users, setUsers] = useState<UserType[]>(mockUsers);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<string>('tous');
  const [filterStatus, setFilterStatus] = useState<string>('tous');
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
  const [isNewUserModalOpen, setIsNewUserModalOpen] = useState(false);
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<UserType | null>(null);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'tous' || user.role === filterRole;
    const matchesStatus = filterStatus === 'tous' || user.statut === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const getUserInitials = (user: UserType) => {
    return `${user.prenom[0]}${user.nom[0]}`;
  };

  const getStatusIcon = (statut: UserType['statut']) => {
    switch (statut) {
      case 'actif': return CheckCircle;
      case 'inactif': return XCircle;
      case 'suspendu': return Clock;
      default: return XCircle;
    }
  };

  const handleEditUser = (user: UserType) => {
    setUserToEdit(user);
    setIsEditUserModalOpen(true);
  };

  const handleSaveNewUser = (newUserData: Omit<UserType, 'id'>) => {
    const newUser: UserType = {
      ...newUserData,
      id: (users.length + 1).toString(),
      dateCreation: new Date(),
      derniereConnexion: undefined
    };
    setUsers(prev => [...prev, newUser]);
  };

  const handleSaveEditedUser = (editedUserData: Omit<UserType, 'id'>) => {
    if (!userToEdit) return;
    
    const updatedUser: UserType = {
      ...editedUserData,
      id: userToEdit.id,
      dateCreation: userToEdit.dateCreation,
      derniereConnexion: userToEdit.derniereConnexion
    };
    
    setUsers(prev => prev.map(u => u.id === userToEdit.id ? updatedUser : u));
    setIsEditUserModalOpen(false);
    setUserToEdit(null);
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      setUsers(prev => prev.filter(u => u.id !== userId));
    }
  };

  const getActiveUsers = () => users.filter(u => u.statut === 'actif').length;
  const getInactiveUsers = () => users.filter(u => u.statut === 'inactif').length;
  const getSuspendedUsers = () => users.filter(u => u.statut === 'suspendu').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gestion des Utilisateurs</h3>
          <p className="text-sm text-gray-600 mt-1">
            Administration des comptes utilisateurs et permissions
          </p>
        </div>
        <button
          onClick={() => setIsNewUserModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouvel utilisateur</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total utilisateurs</p>
              <p className="text-2xl font-bold text-gray-900">{users.length}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Actifs</p>
              <p className="text-2xl font-bold text-green-600">{getActiveUsers()}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Inactifs</p>
              <p className="text-2xl font-bold text-gray-600">{getInactiveUsers()}</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <XCircle className="h-6 w-6 text-gray-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Suspendus</p>
              <p className="text-2xl font-bold text-red-600">{getSuspendedUsers()}</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <Clock className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par nom, prénom ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les rôles</option>
              {Object.entries(roleLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les statuts</option>
              <option value="actif">Actifs</option>
              <option value="inactif">Inactifs</option>
              <option value="suspendu">Suspendus</option>
            </select>
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Utilisateur
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rôle
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dernière connexion
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user) => {
                const RoleIcon = roleIcons[user.role];
                const StatusIcon = getStatusIcon(user.statut);
                
                return (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-sm font-bold">
                          {getUserInitials(user)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {user.prenom} {user.nom}
                          </div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                          {user.cabinet && (
                            <div className="text-xs text-blue-600">{user.cabinet}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <RoleIcon className="h-4 w-4 text-gray-400" />
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${roleColors[user.role]}`}>
                          {roleLabels[user.role]}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="space-y-1">
                        {user.telephone && (
                          <div className="flex items-center space-x-1">
                            <Phone className="h-3 w-3 text-gray-400" />
                            <span>{user.telephone}</span>
                          </div>
                        )}
                        {user.numeroOrdre && (
                          <div className="text-xs text-gray-500">N° Ordre: {user.numeroOrdre}</div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {user.derniereConnexion ? (
                        <div>
                          <div>{user.derniereConnexion.toLocaleDateString('fr-FR')}</div>
                          <div className="text-xs text-gray-500">
                            {user.derniereConnexion.toLocaleTimeString('fr-FR')}
                          </div>
                        </div>
                      ) : (
                        <span className="text-gray-400">Jamais connecté</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <StatusIcon className="h-4 w-4" />
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${statutColors[user.statut]}`}>
                          {user.statut}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedUser(user)}
                          className="text-blue-600 hover:text-blue-800"
                          title="Voir les détails"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleEditUser(user)}
                          className="text-orange-600 hover:text-orange-800"
                          title="Modifier l'utilisateur"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-red-600 hover:text-red-800"
                          title="Supprimer l'utilisateur"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* User Detail Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-lg font-bold">
                    {getUserInitials(selectedUser)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {selectedUser.prenom} {selectedUser.nom}
                    </h3>
                    <p className="text-sm text-gray-600">{roleLabels[selectedUser.role]}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Informations personnelles</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Email:</span>
                      <span className="font-medium">{selectedUser.email}</span>
                    </div>
                    {selectedUser.telephone && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Téléphone:</span>
                        <span>{selectedUser.telephone}</span>
                      </div>
                    )}
                    {selectedUser.numeroOrdre && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">N° Ordre:</span>
                        <span className="font-mono">{selectedUser.numeroOrdre}</span>
                      </div>
                    )}
                    {selectedUser.cabinet && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Cabinet:</span>
                        <span>{selectedUser.cabinet}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Créé le:</span>
                      <span>{selectedUser.dateCreation.toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Dernière connexion:</span>
                      <span>
                        {selectedUser.derniereConnexion 
                          ? selectedUser.derniereConnexion.toLocaleDateString('fr-FR')
                          : 'Jamais'
                        }
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Permissions</h4>
                  <div className="space-y-2">
                    {selectedUser.permissions.includes('all') ? (
                      <div className="flex items-center space-x-2 p-2 bg-green-50 rounded-lg">
                        <Shield className="h-4 w-4 text-green-600" />
                        <span className="text-sm text-green-800 font-medium">Accès complet</span>
                      </div>
                    ) : (
                      selectedUser.permissions.map((permission) => (
                        <div key={permission} className="flex items-center space-x-2 p-2 bg-blue-50 rounded-lg">
                          <CheckCircle className="h-4 w-4 text-blue-600" />
                          <span className="text-sm text-blue-800 capitalize">{permission}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200 flex justify-end space-x-3">
                <button
                  onClick={() => handleEditUser(selectedUser)}
                  className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
                >
                  <Edit className="h-4 w-4" />
                  <span>Modifier</span>
                </button>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New User Modal */}
      <NewUserModal
        isOpen={isNewUserModalOpen}
        onClose={() => setIsNewUserModalOpen(false)}
        onSave={handleSaveNewUser}
      />

      {/* Edit User Modal */}
      <EditUserModal
        isOpen={isEditUserModalOpen}
        onClose={() => {
          setIsEditUserModalOpen(false);
          setUserToEdit(null);
        }}
        onSave={handleSaveEditedUser}
        user={userToEdit}
      />

      {filteredUsers.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun utilisateur trouvé</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Commencez par ajouter votre premier utilisateur'}
          </p>
        </div>
      )}
    </div>
  );
}