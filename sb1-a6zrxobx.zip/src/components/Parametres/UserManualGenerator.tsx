import React from 'react';
import jsPDF from 'jspdf';
import { CABINET_CONFIG } from './Parametres';

interface ManualSection {
  title: string;
  content: string[];
  subsections?: Array<{
    title: string;
    content: string[];
  }>;
}

export class UserManualGenerator {
  private static formatDate(): string {
    return new Date().toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  private static getManualSections(): ManualSection[] {
    return [
      {
        title: "1. INTRODUCTION",
        content: [
          "CACCompta V3.25 est un logiciel de gestion comptable professionnel conforme aux normes OHADA.",
          "Il est destiné aux cabinets d'expertise comptable et aux entreprises de la zone UEMOA.",
          "Ce manuel vous guide dans l'utilisation complète du logiciel."
        ],
        subsections: [
          {
            title: "1.1 Objectifs du logiciel",
            content: [
              "• Gestion complète de la comptabilité selon les normes OHADA",
              "• Suivi multi-clients avec bases de données dédiées",
              "• Génération automatique des états financiers",
              "• Gestion des déclarations fiscales et sociales",
              "• Suivi des immobilisations et calcul des amortissements"
            ]
          },
          {
            title: "1.2 Configuration requise",
            content: [
              "• Navigateur web moderne (Chrome, Firefox, Safari, Edge)",
              "• Connexion internet stable",
              "• Résolution d'écran minimum : 1024x768",
              "• JavaScript activé"
            ]
          }
        ]
      },
      {
        title: "2. PREMIÈRE CONNEXION",
        content: [
          "Lors de votre première utilisation, vous devez vous connecter avec vos identifiants.",
          "Le système propose plusieurs comptes de démonstration pour découvrir les fonctionnalités."
        ],
        subsections: [
          {
            title: "2.1 Comptes de démonstration",
            content: [
              "• Expert-Comptable : jb.kouame@caccompta.ci / admin123",
              "• Assistant : a.traore@caccompta.ci / assistant123",
              "• Stagiaire : m.diallo@caccompta.ci / stagiaire123",
              "• Administrateur : admin@caccompta.ci / admin2024"
            ]
          },
          {
            title: "2.2 Interface principale",
            content: [
              "Après connexion, vous accédez au tableau de bord principal.",
              "La navigation horizontale permet d'accéder aux différents modules.",
              "Le profil utilisateur est affiché en haut à droite."
            ]
          }
        ]
      },
      {
        title: "3. GESTION DES CLIENTS",
        content: [
          "Le module Clients permet de gérer votre portefeuille client de manière complète.",
          "Chaque client dispose d'une base de données dédiée pour ses données comptables."
        ],
        subsections: [
          {
            title: "3.1 Création d'un nouveau client",
            content: [
              "1. Cliquez sur 'Clients' dans la navigation principale",
              "2. Cliquez sur 'Nouveau client'",
              "3. Remplissez les informations obligatoires :",
              "   • Nom commercial et raison sociale",
              "   • Secteur d'activité",
              "   • Numéro de contribuable (14 chiffres)",
              "   • Adresse complète",
              "   • Coordonnées de contact",
              "4. Sélectionnez la devise de travail",
              "5. Définissez les paramètres comptables",
              "6. Cliquez sur 'Créer le client'"
            ]
          },
          {
            title: "3.2 Gestion multi-devises",
            content: [
              "Le logiciel supporte 4 devises principales :",
              "• XOF (Franc CFA BCEAO) - devise de base",
              "• USD (Dollar américain)",
              "• EUR (Euro)",
              "• CDF (Franc congolais)",
              "Les taux de change sont automatiquement appliqués."
            ]
          }
        ]
      },
      {
        title: "4. PLAN COMPTABLE OHADA",
        content: [
          "Le plan comptable est conforme au référentiel OHADA.",
          "Il comprend 8 classes de comptes numérotées de 1 à 8."
        ],
        subsections: [
          {
            title: "4.1 Structure du plan comptable",
            content: [
              "• Classe 1 : Comptes de ressources durables",
              "• Classe 2 : Comptes d'actif immobilisé",
              "• Classe 3 : Comptes de stocks",
              "• Classe 4 : Comptes de tiers",
              "• Classe 5 : Comptes de trésorerie",
              "• Classe 6 : Comptes de charges",
              "• Classe 7 : Comptes de produits",
              "• Classe 8 : Comptes spéciaux"
            ]
          },
          {
            title: "4.2 Création de nouveaux comptes",
            content: [
              "1. Accédez au module 'Plan comptable'",
              "2. Cliquez sur 'Nouveau compte'",
              "3. Saisissez le numéro de compte (doit commencer par le chiffre de la classe)",
              "4. Définissez l'intitulé du compte",
              "5. Sélectionnez la classe comptable",
              "6. Choisissez la nature (débiteur/créditeur)",
              "7. Définissez le solde initial si nécessaire"
            ]
          }
        ]
      },
      {
        title: "5. SAISIE DES ÉCRITURES COMPTABLES",
        content: [
          "La saisie des écritures respecte le principe de la partie double.",
          "Chaque écriture doit être équilibrée (Total Débit = Total Crédit)."
        ],
        subsections: [
          {
            title: "5.1 Nouvelle écriture",
            content: [
              "1. Accédez au module 'Écritures'",
              "2. Cliquez sur 'Nouvelle écriture'",
              "3. Sélectionnez le client concerné",
              "4. Définissez la date d'écriture",
              "5. Choisissez le type de journal (VT, AC, BQ, CA, OD)",
              "6. Saisissez le libellé général",
              "7. Ajoutez les lignes d'écriture :",
              "   • Sélectionnez le compte comptable",
              "   • Saisissez le libellé de la ligne",
              "   • Indiquez le montant en débit ou crédit",
              "8. Vérifiez l'équilibre de l'écriture",
              "9. Enregistrez en brouillon ou validez"
            ]
          },
          {
            title: "5.2 Validation des écritures",
            content: [
              "Les écritures en brouillon peuvent être modifiées.",
              "Une fois validées, elles ne peuvent plus être modifiées.",
              "Seules les écritures validées sont prises en compte dans les états financiers."
            ]
          }
        ]
      },
      {
        title: "6. GESTION DES IMMOBILISATIONS",
        content: [
          "Le module permet de suivre le patrimoine immobilisé et de calculer automatiquement les amortissements."
        ],
        subsections: [
          {
            title: "6.1 Enregistrement d'une immobilisation",
            content: [
              "1. Accédez au module 'Immobilisations'",
              "2. Cliquez sur 'Nouvelle immobilisation'",
              "3. Sélectionnez le client propriétaire",
              "4. Choisissez la catégorie d'immobilisation",
              "5. Saisissez la désignation précise",
              "6. Indiquez la date et valeur d'acquisition",
              "7. Définissez les paramètres d'amortissement :",
              "   • Durée d'amortissement",
              "   • Méthode (linéaire, dégressif, variable)",
              "   • Comptes comptables associés",
              "8. Enregistrez l'immobilisation"
            ]
          },
          {
            title: "6.2 Calcul des amortissements",
            content: [
              "Les amortissements sont calculés automatiquement selon la méthode choisie.",
              "Les terrains ne sont pas amortissables selon les normes OHADA.",
              "Le logiciel génère automatiquement les écritures d'amortissement."
            ]
          }
        ]
      },
      {
        title: "7. TRÉSORERIE",
        content: [
          "La gestion de trésorerie permet de suivre tous les flux financiers de vos clients."
        ],
        subsections: [
          {
            title: "7.1 Comptes de trésorerie",
            content: [
              "Créez les comptes bancaires et caisses de vos clients.",
              "Chaque compte affiche son solde en temps réel.",
              "Supports : banques, caisses, comptes postaux."
            ]
          },
          {
            title: "7.2 Mouvements de trésorerie",
            content: [
              "1. Cliquez sur 'Nouveau mouvement'",
              "2. Sélectionnez le type : Recette ou Dépense",
              "3. Choisissez la catégorie appropriée",
              "4. Indiquez le montant et le mode de paiement",
              "5. Précisez le tiers concerné",
              "6. Enregistrez le mouvement"
            ]
          }
        ]
      },
      {
        title: "8. FACTURATION",
        content: [
          "Le module facturation permet de gérer les honoraires et prestations du cabinet."
        ],
        subsections: [
          {
            title: "8.1 Création d'une facture",
            content: [
              "1. Accédez au module 'Facturation'",
              "2. Cliquez sur 'Nouvelle facture'",
              "3. Sélectionnez le client à facturer",
              "4. Ajoutez les services prestés :",
              "   • Description du service",
              "   • Quantité et prix unitaire",
              "   • Calcul automatique du montant HT",
              "5. Le système calcule automatiquement la TVA",
              "6. Définissez les conditions de paiement",
              "7. Enregistrez la facture"
            ]
          },
          {
            title: "8.2 Impression et envoi",
            content: [
              "Les factures peuvent être :",
              "• Imprimées en PDF professionnel",
              "• Envoyées par email au client",
              "• Exportées pour archivage",
              "Le suivi des paiements est automatique."
            ]
          }
        ]
      },
      {
        title: "9. DÉCLARATIONS FISCALES",
        content: [
          "Gestion complète des obligations fiscales et sociales de vos clients."
        ],
        subsections: [
          {
            title: "9.1 Types de déclarations",
            content: [
              "• TVA : Déclaration mensuelle obligatoire",
              "• Impôt sur les Sociétés : Déclaration annuelle",
              "• CNSS : Cotisations sociales mensuelles",
              "• Patente : Contribution annuelle",
              "• Possibilité d'ajouter des types personnalisés"
            ]
          },
          {
            title: "9.2 Suivi des échéances",
            content: [
              "Le système alerte automatiquement :",
              "• 7 jours avant l'échéance",
              "• Le jour de l'échéance",
              "• En cas de retard",
              "Un tableau de bord centralise toutes les échéances."
            ]
          }
        ]
      },
      {
        title: "10. REPORTING ET ANALYSES",
        content: [
          "Génération automatique de rapports et analyses de performance."
        ],
        subsections: [
          {
            title: "10.1 Types de rapports",
            content: [
              "• Évolution du chiffre d'affaires",
              "• Répartition des clients par secteur",
              "• Analyse de la performance",
              "• États financiers OHADA",
              "• Rapports personnalisés"
            ]
          },
          {
            title: "10.2 Export des rapports",
            content: [
              "Les rapports peuvent être exportés en :",
              "• PDF professionnel avec en-tête cabinet",
              "• HTML pour impression",
              "• CSV pour analyse dans Excel",
              "• Aperçu direct pour impression"
            ]
          }
        ]
      },
      {
        title: "11. PARAMÈTRES ET CONFIGURATION",
        content: [
          "Personnalisation complète du logiciel selon vos besoins."
        ],
        subsections: [
          {
            title: "11.1 Configuration du cabinet",
            content: [
              "• Informations légales et coordonnées",
              "• Logo et charte graphique",
              "• Conditions de paiement",
              "• Coordonnées bancaires"
            ]
          },
          {
            title: "11.2 Gestion des utilisateurs",
            content: [
              "• Création de comptes utilisateurs",
              "• Attribution des rôles et permissions",
              "• Gestion des accès par module",
              "• Suivi des connexions"
            ]
          },
          {
            title: "11.3 Préférences système",
            content: [
              "• Devise de travail par défaut",
              "• Format des dates et nombres",
              "• Paramètres de sauvegarde",
              "• Notifications et alertes"
            ]
          }
        ]
      },
      {
        title: "12. SÉCURITÉ ET SAUVEGARDE",
        content: [
          "La sécurité des données est une priorité absolue."
        ],
        subsections: [
          {
            title: "12.1 Sécurité des accès",
            content: [
              "• Authentification par email/mot de passe",
              "• Gestion des rôles et permissions",
              "• Déconnexion automatique",
              "• Audit des connexions"
            ]
          },
          {
            title: "12.2 Sauvegarde des données",
            content: [
              "• Sauvegarde automatique en temps réel",
              "• Export complet des données",
              "• Restauration en cas de problème",
              "• Archivage des exercices clos"
            ]
          }
        ]
      },
      {
        title: "13. SUPPORT TECHNIQUE",
        content: [
          "En cas de difficulté, plusieurs options de support sont disponibles."
        ],
        subsections: [
          {
            title: "13.1 Contacts support",
            content: [
              "• Cabinet CAGESI : +223 90 14 78 57 / +223 75 44 74 41",
              "• Email : info@cagesicabinet.com",
              "• WhatsApp : +223 90 14 78 57",
              "• Horaires : Lundi-Vendredi 8h-18h"
            ]
          },
          {
            title: "13.2 Ressources disponibles",
            content: [
              "• Manuel utilisateur (ce document)",
              "• Vidéos de formation",
              "• FAQ en ligne",
              "• Télé-assistance à distance"
            ]
          }
        ]
      },
      {
        title: "14. CONFORMITÉ OHADA",
        content: [
          "Le logiciel respecte intégralement les dispositions du droit comptable OHADA."
        ],
        subsections: [
          {
            title: "14.1 Normes respectées",
            content: [
              "• Acte uniforme relatif au droit comptable",
              "• Plan comptable général OHADA",
              "• États financiers normalisés",
              "• Règles d'évaluation et de comptabilisation"
            ]
          },
          {
            title: "14.2 États financiers",
            content: [
              "Le logiciel génère automatiquement :",
              "• Bilan actif/passif",
              "• Compte de résultat",
              "• TAFIRE (Tableau financier des ressources et emplois)",
              "• Notes annexes"
            ]
          }
        ]
      },
      {
        title: "15. BONNES PRATIQUES",
        content: [
          "Recommandations pour une utilisation optimale du logiciel."
        ],
        subsections: [
          {
            title: "15.1 Organisation du travail",
            content: [
              "• Saisissez les écritures régulièrement",
              "• Validez les écritures après vérification",
              "• Effectuez les rapprochements bancaires",
              "• Sauvegardez régulièrement vos données"
            ]
          },
          {
            title: "15.2 Contrôles qualité",
            content: [
              "• Vérifiez l'équilibre des écritures",
              "• Contrôlez les soldes des comptes",
              "• Validez les calculs d'amortissement",
              "• Respectez les échéances fiscales"
            ]
          }
        ]
      }
    ];
  }

  static async generatePDFManual(): Promise<void> {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);
    let yPosition = margin;

    const sections = this.getManualSections();

    // Fonction pour ajouter une nouvelle page
    const addNewPage = () => {
      pdf.addPage();
      yPosition = margin;
    };

    // Fonction pour vérifier si on a besoin d'une nouvelle page
    const checkPageBreak = (requiredSpace: number) => {
      if (yPosition + requiredSpace > pageHeight - margin) {
        addNewPage();
      }
    };

    // Page de couverture
    pdf.setFillColor(41, 98, 255);
    pdf.rect(0, 0, pageWidth, pageHeight, 'F');
    
    // Logo et titre
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(28);
    pdf.setFont('helvetica', 'bold');
    pdf.text('CACCompta V3.25', pageWidth / 2, 80, { align: 'center' });
    
    pdf.setFontSize(18);
    pdf.setFont('helvetica', 'normal');
    pdf.text('Manuel d\'Utilisation Complet', pageWidth / 2, 100, { align: 'center' });
    
    pdf.setFontSize(14);
    pdf.text('Logiciel de Gestion Comptable', pageWidth / 2, 120, { align: 'center' });
    pdf.text('Conforme aux Normes OHADA', pageWidth / 2, 135, { align: 'center' });
    
    // Informations cabinet
    pdf.setFontSize(12);
    pdf.text(CABINET_CONFIG.nom, pageWidth / 2, 160, { align: 'center' });
    pdf.text(CABINET_CONFIG.expertComptable, pageWidth / 2, 175, { align: 'center' });
    pdf.text(`N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre}`, pageWidth / 2, 190, { align: 'center' });
    
    // Date de génération
    pdf.setFontSize(10);
    pdf.text(`Document généré le ${this.formatDate()}`, pageWidth / 2, 220, { align: 'center' });
    pdf.text('© 2024 - Tous droits réservés', pageWidth / 2, 235, { align: 'center' });

    // Nouvelle page pour le contenu
    addNewPage();

    // Table des matières
    pdf.setTextColor(41, 98, 255);
    pdf.setFontSize(18);
    pdf.setFont('helvetica', 'bold');
    pdf.text('TABLE DES MATIÈRES', margin, yPosition);
    yPosition += 15;

    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');

    sections.forEach((section, index) => {
      checkPageBreak(8);
      pdf.text(section.title, margin, yPosition);
      yPosition += 6;
      
      if (section.subsections) {
        section.subsections.forEach((subsection) => {
          checkPageBreak(6);
          pdf.text(`  ${subsection.title}`, margin + 5, yPosition);
          yPosition += 5;
        });
      }
      yPosition += 3;
    });

    // Contenu détaillé
    addNewPage();

    sections.forEach((section) => {
      checkPageBreak(20);
      
      // Titre de section
      pdf.setTextColor(41, 98, 255);
      pdf.setFontSize(16);
      pdf.setFont('helvetica', 'bold');
      pdf.text(section.title, margin, yPosition);
      yPosition += 10;

      // Ligne de séparation
      pdf.setDrawColor(200, 200, 200);
      pdf.line(margin, yPosition, pageWidth - margin, yPosition);
      yPosition += 8;

      // Contenu principal
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      
      section.content.forEach((paragraph) => {
        checkPageBreak(12);
        const lines = pdf.splitTextToSize(paragraph, contentWidth);
        pdf.text(lines, margin, yPosition);
        yPosition += lines.length * 5 + 3;
      });

      // Sous-sections
      if (section.subsections) {
        section.subsections.forEach((subsection) => {
          checkPageBreak(15);
          
          // Titre de sous-section
          pdf.setTextColor(100, 116, 139);
          pdf.setFontSize(12);
          pdf.setFont('helvetica', 'bold');
          pdf.text(subsection.title, margin, yPosition);
          yPosition += 8;

          // Contenu de sous-section
          pdf.setTextColor(0, 0, 0);
          pdf.setFontSize(10);
          pdf.setFont('helvetica', 'normal');
          
          subsection.content.forEach((paragraph) => {
            checkPageBreak(10);
            const lines = pdf.splitTextToSize(paragraph, contentWidth - 10);
            pdf.text(lines, margin + 5, yPosition);
            yPosition += lines.length * 4 + 2;
          });
          
          yPosition += 5;
        });
      }
      
      yPosition += 10;
    });

    // Page de fin
    addNewPage();
    
    pdf.setFillColor(248, 250, 252);
    pdf.rect(margin, yPosition, contentWidth, 60, 'F');
    pdf.setDrawColor(41, 98, 255);
    pdf.rect(margin, yPosition, contentWidth, 60, 'S');
    
    pdf.setTextColor(41, 98, 255);
    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'bold');
    pdf.text('SUPPORT ET ASSISTANCE', pageWidth / 2, yPosition + 15, { align: 'center' });
    
    pdf.setTextColor(0, 0, 0);
    pdf.setFontSize(11);
    pdf.setFont('helvetica', 'normal');
    pdf.text('Cabinet CAGESI', pageWidth / 2, yPosition + 25, { align: 'center' });
    pdf.text('Tél: +223 90 14 78 57 / +223 75 44 74 41', pageWidth / 2, yPosition + 35, { align: 'center' });
    pdf.text('Email: info@cagesicabinet.com', pageWidth / 2, yPosition + 45, { align: 'center' });
    pdf.text('Support disponible du Lundi au Vendredi, 8h-18h', pageWidth / 2, yPosition + 55, { align: 'center' });

    // Télécharger le PDF
    const timestamp = new Date().toISOString().split('T')[0];
    pdf.save(`manuel-utilisateur-caccompta-v3.25-${timestamp}.pdf`);
  }

  static generateHTMLManual(): string {
    const sections = this.getManualSections();
    
    return `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manuel d'Utilisation - CACCompta V3.25</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .page-break { page-break-before: always; }
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .cover {
            background: linear-gradient(135deg, #2962ff, #1e40af);
            color: white;
            text-align: center;
            padding: 60px 40px;
            border-radius: 15px;
            margin-bottom: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .cover h1 {
            font-size: 3em;
            margin: 0 0 20px 0;
            font-weight: 300;
        }
        
        .cover h2 {
            font-size: 1.5em;
            margin: 0 0 10px 0;
            opacity: 0.9;
        }
        
        .cover p {
            font-size: 1.1em;
            opacity: 0.8;
            margin: 20px 0;
        }
        
        .toc {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .toc h2 {
            color: #2962ff;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .toc ul {
            list-style: none;
            padding: 0;
        }
        
        .toc li {
            padding: 8px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .toc a {
            color: #2962ff;
            text-decoration: none;
            font-weight: 500;
        }
        
        .toc a:hover {
            text-decoration: underline;
        }
        
        .section {
            background: white;
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .section-header {
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            padding: 25px 30px;
            border-bottom: 3px solid #2962ff;
        }
        
        .section-header h3 {
            margin: 0;
            color: #2962ff;
            font-size: 1.5em;
            font-weight: 600;
        }
        
        .section-content {
            padding: 30px;
        }
        
        .subsection {
            margin: 25px 0;
            padding: 20px;
            background: #f8fafc;
            border-left: 4px solid #3b82f6;
            border-radius: 0 8px 8px 0;
        }
        
        .subsection h4 {
            color: #1e40af;
            margin: 0 0 15px 0;
            font-size: 1.2em;
        }
        
        .content-list {
            margin: 15px 0;
            padding-left: 0;
        }
        
        .content-list li {
            margin: 8px 0;
            padding: 8px 15px;
            background: white;
            border-radius: 5px;
            border-left: 3px solid #10b981;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .highlight {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            border: 1px solid #f59e0b;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        
        .highlight h4 {
            color: #92400e;
            margin: 0 0 10px 0;
        }
        
        .contact-info {
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
            border: 2px solid #3b82f6;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            margin: 30px 0;
        }
        
        .contact-info h4 {
            color: #1e40af;
            margin: 0 0 15px 0;
            font-size: 1.3em;
        }
        
        .footer {
            text-align: center;
            color: #64748b;
            font-size: 0.9em;
            margin-top: 40px;
            padding: 30px;
            background: white;
            border-radius: 10px;
            border-top: 3px solid #2962ff;
        }
        
        .print-button {
            background: #10b981;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            margin: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .print-button:hover {
            background: #059669;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        
        .version-info {
            background: #f0f9ff;
            border: 1px solid #0ea5e9;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }
        
        .step-number {
            background: #2962ff;
            color: white;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9em;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 30px;">
        <button class="print-button" onclick="window.print()">🖨️ Imprimer le manuel</button>
        <button class="print-button" onclick="window.close()">❌ Fermer</button>
    </div>

    <div class="cover">
        <h1>CACCompta V3.25</h1>
        <h2>Manuel d'Utilisation Complet</h2>
        <p>Logiciel de Gestion Comptable Conforme aux Normes OHADA</p>
        <div style="margin-top: 40px; font-size: 0.9em;">
            <p><strong>${CABINET_CONFIG.nom}</strong></p>
            <p>Expert-Comptable: ${CABINET_CONFIG.expertComptable}</p>
            <p>N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre}</p>
        </div>
    </div>

    <div class="version-info">
        <h4 style="margin: 0 0 10px 0; color: #0c4a6e;">ℹ️ Informations sur cette version</h4>
        <p style="margin: 0; color: #0c4a6e;">
            <strong>Version:</strong> 3.25 | 
            <strong>Date:</strong> ${this.formatDate()} | 
            <strong>Statut:</strong> Production
        </p>
    </div>

    <div class="toc">
        <h2>📋 Table des Matières</h2>
        <ul>
            ${sections.map((section, index) => `
                <li>
                    <a href="#section-${index}">${section.title}</a>
                    ${section.subsections ? `
                        <ul style="margin-left: 20px; margin-top: 5px;">
                            ${section.subsections.map((sub, subIndex) => `
                                <li style="border: none; padding: 3px 0;">
                                    <a href="#section-${index}-${subIndex}" style="font-weight: normal; font-size: 0.9em;">${sub.title}</a>
                                </li>
                            `).join('')}
                        </ul>
                    ` : ''}
                </li>
            `).join('')}
        </ul>
    </div>

    ${sections.map((section, index) => `
        <div class="section" id="section-${index}">
            <div class="section-header">
                <h3>${section.title}</h3>
            </div>
            <div class="section-content">
                ${section.content.map(paragraph => `<p>${paragraph}</p>`).join('')}
                
                ${section.subsections ? section.subsections.map((subsection, subIndex) => `
                    <div class="subsection" id="section-${index}-${subIndex}">
                        <h4>${subsection.title}</h4>
                        <ul class="content-list">
                            ${subsection.content.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>
                `).join('') : ''}
            </div>
        </div>
    `).join('')}

    <div class="contact-info">
        <h4>📞 Support Technique CAGESI</h4>
        <p><strong>Téléphones:</strong> +223 90 14 78 57 / +223 75 44 74 41</p>
        <p><strong>Email:</strong> info@cagesicabinet.com</p>
        <p><strong>WhatsApp:</strong> +223 90 14 78 57</p>
        <p><strong>Horaires:</strong> Lundi - Vendredi, 8h00 - 18h00</p>
    </div>

    <div class="footer">
        <p><strong>© 2024 ${CABINET_CONFIG.nom}</strong></p>
        <p>Expert-Comptable: ${CABINET_CONFIG.expertComptable} | N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre}</p>
        <p>Document confidentiel - Manuel d'utilisation CACCompta V3.25</p>
        <p style="margin-top: 15px; font-size: 0.8em; color: #94a3b8;">
            Ce manuel est régulièrement mis à jour. Consultez la dernière version sur votre logiciel.
        </p>
    </div>
</body>
</html>`;
  }

  static downloadManual(content: string, filename: string, type: 'html' | 'text'): void {
    const mimeTypes = {
      html: 'text/html',
      text: 'text/plain'
    };

    const blob = new Blob([content], { type: mimeTypes[type] + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  }

  static openPrintableManual(htmlContent: string): void {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.focus();
        }, 500);
      };
    }
  }
}