import React, { useState } from 'react';
import { X, DollarSign, Calendar, CreditCard, FileText, Save, AlertCircle, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import type { Client } from '../../types';

interface MouvementTresorerie {
  id: string;
  clientId: string;
  date: Date;
  libelle: string;
  type: 'recette' | 'depense';
  categorie: 'vente' | 'achat' | 'salaire' | 'charge' | 'impot' | 'emprunt' | 'remboursement' | 'autre';
  montant: number;
  modePaiement: 'especes' | 'cheque' | 'virement' | 'carte' | 'mobile';
  compteBancaire?: string;
  numeroPiece?: string;
  statut: 'realise' | 'previsionnel' | 'annule';
  tiers?: string;
}

interface CompteTresorerie {
  id: string;
  clientId: string;
  designation: string;
  type: 'banque' | 'caisse' | 'ccp';
  numeroCompte?: string;
  banque?: string;
  solde: number;
  dateOuverture: Date;
  statut: 'actif' | 'ferme' | 'suspendu';
}

interface NewMouvementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (mouvement: Omit<MouvementTresorerie, 'id'>) => void;
  comptes: CompteTresorerie[];
}

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif'
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'actif'
  }
];

const categoriesRecettes = [
  { value: 'vente', label: 'Vente de marchandises/services' },
  { value: 'emprunt', label: 'Emprunt bancaire' },
  { value: 'remboursement', label: 'Remboursement reçu' },
  { value: 'autre', label: 'Autre recette' }
];

const categoriesDepenses = [
  { value: 'achat', label: 'Achat de marchandises/matières' },
  { value: 'salaire', label: 'Salaires et charges sociales' },
  { value: 'charge', label: 'Charges d\'exploitation' },
  { value: 'impot', label: 'Impôts et taxes' },
  { value: 'remboursement', label: 'Remboursement effectué' },
  { value: 'autre', label: 'Autre dépense' }
];

const modePaiementOptions = [
  { value: 'especes', label: 'Espèces', icon: '💵' },
  { value: 'cheque', label: 'Chèque', icon: '📝' },
  { value: 'virement', label: 'Virement bancaire', icon: '🏦' },
  { value: 'carte', label: 'Carte bancaire', icon: '💳' },
  { value: 'mobile', label: 'Mobile Money', icon: '📱' }
];

const tiersFrequents = [
  'CLIENT DIVERS',
  'FOURNISSEUR DIVERS',
  'PERSONNEL',
  'DIRECTION GENERALE DES IMPOTS',
  'CNSS',
  'BANQUE',
  'CAISSE NATIONALE DE PREVOYANCE SOCIALE',
  'OFFICE NATIONAL DE LA FORMATION PROFESSIONNELLE'
];

export default function NewMouvementModal({ isOpen, onClose, onSave, comptes }: NewMouvementModalProps) {
  const [formData, setFormData] = useState({
    clientId: '',
    date: new Date().toISOString().split('T')[0],
    libelle: '',
    type: 'recette' as 'recette' | 'depense',
    categorie: 'vente' as any,
    montant: '',
    modePaiement: 'virement' as any,
    compteBancaire: '',
    numeroPiece: '',
    statut: 'realise' as any,
    tiers: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Réinitialiser la catégorie quand on change le type
    if (name === 'type') {
      setFormData(prev => ({
        ...prev,
        type: value as 'recette' | 'depense',
        categorie: value === 'recette' ? 'vente' : 'achat'
      }));
    }

    // Génération automatique du numéro de pièce selon le mode de paiement
    if (name === 'modePaiement' && value) {
      const prefixes = {
        'especes': 'ESP',
        'cheque': 'CHQ',
        'virement': 'VIR',
        'carte': 'CB',
        'mobile': 'MM'
      };
      const prefix = prefixes[value as keyof typeof prefixes];
      const nextNumber = String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0');
      const year = new Date().getFullYear();
      setFormData(prev => ({ 
        ...prev, 
        numeroPiece: `${prefix}-${year}-${nextNumber}` 
      }));
    }

    // Suggestion de libellé selon la catégorie
    if (name === 'categorie' && value) {
      const suggestions = {
        'vente': 'Encaissement client - ',
        'achat': 'Paiement fournisseur - ',
        'salaire': 'Paiement salaires - ',
        'charge': 'Paiement charges - ',
        'impot': 'Paiement impôts - ',
        'emprunt': 'Encaissement emprunt - ',
        'remboursement': 'Remboursement - ',
        'autre': ''
      };
      const suggestion = suggestions[value as keyof typeof suggestions];
      if (suggestion && !formData.libelle) {
        setFormData(prev => ({ ...prev, libelle: suggestion }));
      }
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Champs obligatoires
    if (!formData.clientId) newErrors.clientId = 'Le client est obligatoire';
    if (!formData.date) newErrors.date = 'La date est obligatoire';
    if (!formData.libelle.trim()) newErrors.libelle = 'Le libellé est obligatoire';
    if (!formData.montant || parseFloat(formData.montant) <= 0) {
      newErrors.montant = 'Le montant doit être supérieur à 0';
    }
    if (!formData.modePaiement) newErrors.modePaiement = 'Le mode de paiement est obligatoire';

    // Validation du compte bancaire pour certains modes de paiement
    if (['virement', 'cheque', 'carte'].includes(formData.modePaiement) && !formData.compteBancaire) {
      newErrors.compteBancaire = 'Le compte bancaire est obligatoire pour ce mode de paiement';
    }

    // Validation de la date
    const dateOperation = new Date(formData.date);
    const today = new Date();
    const unAnAvant = new Date();
    unAnAvant.setFullYear(today.getFullYear() - 1);
    
    if (dateOperation > today) {
      newErrors.date = 'La date ne peut pas être dans le futur';
    }
    if (dateOperation < unAnAvant) {
      newErrors.date = 'La date ne peut pas être antérieure à un an';
    }

    // Validation du montant
    if (formData.montant && parseFloat(formData.montant) > 1000000000) {
      newErrors.montant = 'Le montant semble trop élevé';
    }

    // Validation du tiers
    if (!formData.tiers.trim()) {
      newErrors.tiers = 'Le tiers est obligatoire';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const nouveauMouvement: Omit<MouvementTresorerie, 'id'> = {
        clientId: formData.clientId,
        date: new Date(formData.date),
        libelle: formData.libelle.trim(),
        type: formData.type,
        categorie: formData.categorie,
        montant: parseFloat(formData.montant),
        modePaiement: formData.modePaiement,
        compteBancaire: formData.compteBancaire || undefined,
        numeroPiece: formData.numeroPiece.trim() || undefined,
        statut: formData.statut,
        tiers: formData.tiers.trim()
      };

      onSave(nouveauMouvement);
      onClose();
      
      // Reset form
      setFormData({
        clientId: '',
        date: new Date().toISOString().split('T')[0],
        libelle: '',
        type: 'recette',
        categorie: 'vente',
        montant: '',
        modePaiement: 'virement',
        compteBancaire: '',
        numeroPiece: '',
        statut: 'realise',
        tiers: ''
      });
    } catch (error) {
      console.error('Erreur lors de la création du mouvement:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatMontant = (montant: string) => {
    if (!montant) return '';
    const num = parseFloat(montant);
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(num);
  };

  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : '';
  };

  const getComptesClient = () => {
    return comptes.filter(compte => compte.clientId === formData.clientId && compte.statut === 'actif');
  };

  const getCategoriesOptions = () => {
    return formData.type === 'recette' ? categoriesRecettes : categoriesDepenses;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouveau Mouvement de Trésorerie</h3>
                <p className="text-sm text-gray-600">Enregistrer une opération de trésorerie</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Informations générales */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-blue-600" />
              Informations générales
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.clientId ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un client</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.nom}</option>
                  ))}
                </select>
                {errors.clientId && <p className="text-red-500 text-xs mt-1">{errors.clientId}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date d'opération <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.date ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date}</p>}
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Libellé de l'opération <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="libelle"
                  value={formData.libelle}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.libelle ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Description de l'opération de trésorerie"
                />
                {errors.libelle && <p className="text-red-500 text-xs mt-1">{errors.libelle}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tiers <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="tiers"
                  value={formData.tiers}
                  onChange={handleInputChange}
                  list="tiers-frequents"
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.tiers ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Nom du tiers (client, fournisseur, etc.)"
                />
                <datalist id="tiers-frequents">
                  {tiersFrequents.map(tiers => (
                    <option key={tiers} value={tiers} />
                  ))}
                </datalist>
                {errors.tiers && <p className="text-red-500 text-xs mt-1">{errors.tiers}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Statut
                </label>
                <select
                  name="statut"
                  value={formData.statut}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="realise">Réalisé</option>
                  <option value="previsionnel">Prévisionnel</option>
                </select>
              </div>
            </div>
          </div>

          {/* Type et catégorie */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-600" />
              Type d'opération
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de mouvement <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'recette', categorie: 'vente' }))}
                    className={`p-4 border-2 rounded-lg flex items-center justify-center space-x-2 transition-colors ${
                      formData.type === 'recette'
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <ArrowUpRight className="h-5 w-5" />
                    <span className="font-medium">Recette</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, type: 'depense', categorie: 'achat' }))}
                    className={`p-4 border-2 rounded-lg flex items-center justify-center space-x-2 transition-colors ${
                      formData.type === 'depense'
                        ? 'border-red-500 bg-red-50 text-red-700'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <ArrowDownLeft className="h-5 w-5" />
                    <span className="font-medium">Dépense</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Catégorie <span className="text-red-500">*</span>
                </label>
                <select
                  name="categorie"
                  value={formData.categorie}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {getCategoriesOptions().map(cat => (
                    <option key={cat.value} value={cat.value}>{cat.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Montant et mode de paiement */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-purple-600" />
              Montant et paiement
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Montant (FCFA) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="montant"
                  value={formData.montant}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.montant ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="0"
                  min="0"
                  step="1"
                />
                {errors.montant && <p className="text-red-500 text-xs mt-1">{errors.montant}</p>}
                {formData.montant && (
                  <p className="text-sm text-gray-600 mt-1">
                    {formatMontant(formData.montant)}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mode de paiement <span className="text-red-500">*</span>
                </label>
                <select
                  name="modePaiement"
                  value={formData.modePaiement}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.modePaiement ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  {modePaiementOptions.map(mode => (
                    <option key={mode.value} value={mode.value}>
                      {mode.icon} {mode.label}
                    </option>
                  ))}
                </select>
                {errors.modePaiement && <p className="text-red-500 text-xs mt-1">{errors.modePaiement}</p>}
              </div>

              {['virement', 'cheque', 'carte'].includes(formData.modePaiement) && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Compte bancaire <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="compteBancaire"
                    value={formData.compteBancaire}
                    onChange={handleInputChange}
                    className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.compteBancaire ? 'border-red-300' : 'border-gray-300'
                    }`}
                  >
                    <option value="">Sélectionner un compte</option>
                    {getComptesClient().map(compte => (
                      <option key={compte.id} value={compte.id}>
                        {compte.designation} - {formatMontant(compte.solde.toString())}
                      </option>
                    ))}
                  </select>
                  {errors.compteBancaire && <p className="text-red-500 text-xs mt-1">{errors.compteBancaire}</p>}
                  {formData.clientId && getComptesClient().length === 0 && (
                    <p className="text-orange-600 text-xs mt-1">
                      Aucun compte actif trouvé pour ce client
                    </p>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro de pièce
                </label>
                <input
                  type="text"
                  name="numeroPiece"
                  value={formData.numeroPiece}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Généré automatiquement"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Numéro de chèque, référence virement, etc.
                </p>
              </div>
            </div>
          </div>

          {/* Résumé */}
          {formData.clientId && formData.montant && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Résumé de l'opération</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Client:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {getClientName(formData.clientId)}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Type:</span>
                  <span className={`ml-2 font-bold ${
                    formData.type === 'recette' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {formData.type === 'recette' ? '↗️ Recette' : '↙️ Dépense'}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Montant:</span>
                  <span className="ml-2 font-bold text-purple-600">
                    {formatMontant(formData.montant)}
                  </span>
                </div>
              </div>
              {formData.type === 'recette' && (
                <div className="mt-2 p-2 bg-green-100 border border-green-200 rounded flex items-center">
                  <ArrowUpRight className="h-4 w-4 text-green-600 mr-2" />
                  <span className="text-sm text-green-800">
                    Cette opération augmentera la trésorerie du client
                  </span>
                </div>
              )}
              {formData.type === 'depense' && (
                <div className="mt-2 p-2 bg-red-100 border border-red-200 rounded flex items-center">
                  <ArrowDownLeft className="h-4 w-4 text-red-600 mr-2" />
                  <span className="text-sm text-red-800">
                    Cette opération diminuera la trésorerie du client
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Enregistrement...' : 'Enregistrer le mouvement'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}