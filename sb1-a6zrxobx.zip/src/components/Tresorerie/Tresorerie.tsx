import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, ArrowUpRight, ArrowDownLeft, CreditCard, Banknote, TrendingUp, TrendingDown, Calendar, DollarSign } from 'lucide-react';
import NewMouvementModal from './NewMouvementModal';
import { CABINET_CONFIG } from '../Parametres/Parametres';
import { useCurrency } from '../../contexts/CurrencyContext';

interface MouvementTresorerie {
  id: string;
  clientId: string;
  date: Date;
  libelle: string;
  type: 'recette' | 'depense';
  categorie: 'vente' | 'achat' | 'salaire' | 'charge' | 'impot' | 'emprunt' | 'remboursement' | 'autre';
  montant: number;
  modePaiement: 'especes' | 'cheque' | 'virement' | 'carte' | 'mobile';
  compteBancaire?: string;
  numeroPiece?: string;
  statut: 'realise' | 'previsionnel' | 'annule';
  tiers?: string;
}

interface CompteTresorerie {
  id: string;
  clientId: string;
  designation: string;
  type: 'banque' | 'caisse' | 'ccp';
  numeroCompte?: string;
  banque?: string;
  solde: number;
  dateOuverture: Date;
  statut: 'actif' | 'ferme' | 'suspendu';
}

const mockClients = [
  { id: '1', nom: 'SARL TEKNO SERVICES' },
  { id: '2', nom: 'ETS MAMADOU COMMERCE' },
  { id: '3', nom: 'SARL AFRICAN TRADE' }
];

const mockComptesTresorerie: CompteTresorerie[] = [
  {
    id: '1',
    clientId: '1',
    designation: 'SGBCI - Compte Principal',
    type: 'banque',
    numeroCompte: '12345678901',
    banque: 'SGBCI',
    solde: 15500000,
    dateOuverture: new Date('2020-01-15'),
    statut: 'actif'
  },
  {
    id: '2',
    clientId: '1',
    designation: 'Caisse Principale',
    type: 'caisse',
    solde: 2500000,
    dateOuverture: new Date('2020-01-15'),
    statut: 'actif'
  },
  {
    id: '3',
    clientId: '2',
    designation: 'BACI - Compte Courant',
    type: 'banque',
    numeroCompte: '98765432109',
    banque: 'BACI',
    solde: 8750000,
    dateOuverture: new Date('2018-06-10'),
    statut: 'actif'
  },
  {
    id: '4',
    clientId: '3',
    designation: 'UBA - Compte Professionnel',
    type: 'banque',
    numeroCompte: '55667788990',
    banque: 'UBA',
    solde: 12300000,
    dateOuverture: new Date('2021-03-20'),
    statut: 'actif'
  }
];

const mockMouvements: MouvementTresorerie[] = [
  {
    id: '1',
    clientId: '1',
    date: new Date('2024-01-15'),
    libelle: 'Vente marchandises - Facture F2024-001',
    type: 'recette',
    categorie: 'vente',
    montant: 5900000,
    modePaiement: 'virement',
    compteBancaire: '1',
    numeroPiece: 'VIR-2024-001',
    statut: 'realise',
    tiers: 'CLIENT ABC SARL'
  },
  {
    id: '2',
    clientId: '1',
    date: new Date('2024-01-18'),
    libelle: 'Achat matières premières',
    type: 'depense',
    categorie: 'achat',
    montant: 2950000,
    modePaiement: 'cheque',
    compteBancaire: '1',
    numeroPiece: 'CHQ-001234',
    statut: 'realise',
    tiers: 'FOURNISSEUR XYZ'
  },
  {
    id: '3',
    clientId: '1',
    date: new Date('2024-01-20'),
    libelle: 'Salaires du personnel - Janvier 2024',
    type: 'depense',
    categorie: 'salaire',
    montant: 3200000,
    modePaiement: 'virement',
    compteBancaire: '1',
    numeroPiece: 'SAL-2024-01',
    statut: 'realise',
    tiers: 'PERSONNEL'
  },
  {
    id: '4',
    clientId: '2',
    date: new Date('2024-01-22'),
    libelle: 'Encaissement client - Espèces',
    type: 'recette',
    categorie: 'vente',
    montant: 1500000,
    modePaiement: 'especes',
    compteBancaire: '2',
    statut: 'realise',
    tiers: 'CLIENT DIVERS'
  },
  {
    id: '5',
    clientId: '1',
    date: new Date('2024-01-25'),
    libelle: 'Paiement TVA - Janvier 2024',
    type: 'depense',
    categorie: 'impot',
    montant: 3600000,
    modePaiement: 'virement',
    compteBancaire: '1',
    numeroPiece: 'TVA-2024-01',
    statut: 'realise',
    tiers: 'DIRECTION GENERALE DES IMPOTS'
  }
];

const categorieLabels = {
  'vente': 'Vente',
  'achat': 'Achat',
  'salaire': 'Salaire',
  'charge': 'Charge',
  'impot': 'Impôt',
  'emprunt': 'Emprunt',
  'remboursement': 'Remboursement',
  'autre': 'Autre'
};

const modePaiementLabels = {
  'especes': 'Espèces',
  'cheque': 'Chèque',
  'virement': 'Virement',
  'carte': 'Carte bancaire',
  'mobile': 'Mobile Money'
};

export default function Tresorerie() {
  const { formatAmount } = useCurrency();
  const [activeTab, setActiveTab] = useState('mouvements');
  const [mouvements, setMouvements] = useState<MouvementTresorerie[]>(mockMouvements);
  const [comptes, setComptes] = useState<CompteTresorerie[]>(mockComptesTresorerie);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('tous');
  const [filterCategorie, setFilterCategorie] = useState<string>('tous');
  const [selectedMouvement, setSelectedMouvement] = useState<MouvementTresorerie | null>(null);
  const [isNewMouvementModalOpen, setIsNewMouvementModalOpen] = useState(false);

  const filteredMouvements = mouvements.filter(mouvement => {
    const matchesSearch = mouvement.libelle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         mouvement.tiers?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'tous' || mouvement.type === filterType;
    const matchesCategorie = filterCategorie === 'tous' || mouvement.categorie === filterCategorie;
    return matchesSearch && matchesType && matchesCategorie;
  });

  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : 'Client inconnu';
  };

  const getTotalRecettes = () => {
    return mouvements
      .filter(m => m.type === 'recette' && m.statut === 'realise')
      .reduce((sum, m) => sum + m.montant, 0);
  };

  const getTotalDepenses = () => {
    return mouvements
      .filter(m => m.type === 'depense' && m.statut === 'realise')
      .reduce((sum, m) => sum + m.montant, 0);
  };

  const getSoldeTresorerie = () => {
    return comptes.reduce((sum, compte) => sum + compte.solde, 0);
  };

  const getFluxNet = () => {
    return getTotalRecettes() - getTotalDepenses();
  };

  const renderMouvements = () => (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par libellé ou tiers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous types</option>
              <option value="recette">Recettes</option>
              <option value="depense">Dépenses</option>
            </select>
            <select
              value={filterCategorie}
              onChange={(e) => setFilterCategorie(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Toutes catégories</option>
              {Object.entries(categorieLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Mouvements Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Libellé
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Catégorie
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Montant
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Mode paiement
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredMouvements.map((mouvement) => (
                <tr key={mouvement.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {mouvement.date.toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                    <div>
                      <div className="font-medium truncate">{mouvement.libelle}</div>
                      {mouvement.tiers && (
                        <div className="text-xs text-gray-500 truncate">{mouvement.tiers}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {mouvement.type === 'recette' ? (
                        <ArrowUpRight className="h-4 w-4 text-green-600 mr-2" />
                      ) : (
                        <ArrowDownLeft className="h-4 w-4 text-red-600 mr-2" />
                      )}
                      <span className={`text-sm font-medium ${
                        mouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {mouvement.type === 'recette' ? 'Recette' : 'Dépense'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                      {categorieLabels[mouvement.categorie]}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                    <span className={mouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'}>
                      {mouvement.type === 'recette' ? '+' : '-'}{formatAmount(mouvement.montant)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {modePaiementLabels[mouvement.modePaiement]}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => setSelectedMouvement(mouvement)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderComptes = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {comptes.map((compte) => (
          <div key={compte.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  {compte.type === 'banque' ? (
                    <CreditCard className="h-5 w-5 text-blue-600" />
                  ) : (
                    <Banknote className="h-5 w-5 text-green-600" />
                  )}
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">{compte.designation}</h4>
                  <p className="text-sm text-gray-600">{getClientName(compte.clientId)}</p>
                </div>
              </div>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                compte.statut === 'actif' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {compte.statut}
              </span>
            </div>

            <div className="space-y-2 mb-4">
              {compte.numeroCompte && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">N° compte:</span>
                  <span className="font-mono">{compte.numeroCompte}</span>
                </div>
              )}
              {compte.banque && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Banque:</span>
                  <span>{compte.banque}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Ouvert le:</span>
                <span>{compte.dateOuverture.toLocaleDateString('fr-FR')}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100">
              <div className="text-center">
                <div className={`text-2xl font-bold ${
                  compte.solde >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatAmount(compte.solde)}
                </div>
                <div className="text-sm text-gray-600">Solde actuel</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const handleSaveNewMouvement = (newMouvementData: Omit<MouvementTresorerie, 'id'>) => {
    const newMouvement: MouvementTresorerie = {
      ...newMouvementData,
      id: (mouvements.length + 1).toString()
    };
    setMouvements(prev => [...prev, newMouvement]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gestion de Trésorerie</h3>
          <p className="text-sm text-gray-600 mt-1">
            Suivi des flux de trésorerie et gestion des comptes bancaires
          </p>
        </div>
        <button
          onClick={() => setIsNewMouvementModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouveau mouvement</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Solde trésorerie</p>
              <p className="text-2xl font-bold text-gray-900">{formatAmount(getSoldeTresorerie())}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Recettes</p>
              <p className="text-2xl font-bold text-green-600">{formatAmount(getTotalRecettes())}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Dépenses</p>
              <p className="text-2xl font-bold text-red-600">{formatAmount(getTotalDepenses())}</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <TrendingDown className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Flux net</p>
              <p className={`text-2xl font-bold ${getFluxNet() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatAmount(getFluxNet())}
              </p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Calendar className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('mouvements')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'mouvements'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Mouvements de trésorerie
            </button>
            <button
              onClick={() => setActiveTab('comptes')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'comptes'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Comptes de trésorerie
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'mouvements' && renderMouvements()}
          {activeTab === 'comptes' && renderComptes()}
        </div>
      </div>

      {/* Detail Modal */}
      {selectedMouvement && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Détail du mouvement
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedMouvement.date.toLocaleDateString('fr-FR')}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedMouvement(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Libellé
                    </label>
                    <p className="text-sm text-gray-900">{selectedMouvement.libelle}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tiers
                    </label>
                    <p className="text-sm text-gray-900">{selectedMouvement.tiers || '-'}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Type
                    </label>
                    <p className={`text-sm font-medium ${
                      selectedMouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {selectedMouvement.type === 'recette' ? 'Recette' : 'Dépense'}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Catégorie
                    </label>
                    <p className="text-sm text-gray-900">{categorieLabels[selectedMouvement.categorie]}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Montant
                    </label>
                    <p className={`text-lg font-bold ${
                      selectedMouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatAmount(selectedMouvement.montant)}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Mode de paiement
                    </label>
                    <p className="text-sm text-gray-900">{modePaiementLabels[selectedMouvement.modePaiement]}</p>
                  </div>
                </div>

                {selectedMouvement.numeroPiece && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Numéro de pièce
                    </label>
                    <p className="text-sm text-gray-900 font-mono">{selectedMouvement.numeroPiece}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Mouvement Modal */}
      <NewMouvementModal
        isOpen={isNewMouvementModalOpen}
        onClose={() => setIsNewMouvementModalOpen(false)}
        onSave={handleSaveNewMouvement}
        comptes={comptes}
      />

      {filteredMouvements.length === 0 && activeTab === 'mouvements' && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun mouvement trouvé</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Commencez par ajouter votre premier mouvement de trésorerie'}
          </p>
        </div>
      )}
    </div>
  );
}