import React from 'react';
import jsPDF from 'jspdf';
import type { Facture, Client } from '../../types';
import { CABINET_CONFIG } from '../Parametres/Parametres';

export default class InvoicePDFGenerator {
  private static formatMontant(montant: number): string {
    // Formatage français avec espaces comme séparateurs
    const montantStr = montant.toString();
    const reversed = montantStr.split('').reverse().join('');
    const withSpaces = reversed.replace(/(\d{3})/g, '$1 ').trim();
    const formatted = withSpaces.split('').reverse().join('');
    return formatted + ' FCFA';
  }

  private static formatDate(date: Date): string {
    return date.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  private static convertirMontantEnLettres(montant: number): string {
    const unites = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'];
    const dizaines = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingt', 'quatre-vingt-dix'];
    const centaines = ['', 'cent', 'deux cents', 'trois cents', 'quatre cents', 'cinq cents', 'six cents', 'sept cents', 'huit cents', 'neuf cents'];

    if (montant === 0) return 'zéro';
    if (montant < 1000000) {
      return 'moins d\'un million';
    }

    const millions = Math.floor(montant / 1000000);
    const reste = montant % 1000000;

    let resultat = '';
    if (millions === 1) {
      resultat = 'un million';
    } else if (millions < 10) {
      resultat = unites[millions] + ' millions';
    } else {
      resultat = millions.toString() + ' millions';
    }

    if (reste > 0) {
      if (reste < 1000) {
        resultat += ' ' + reste.toString();
      } else {
        const milliers = Math.floor(reste / 1000);
        const centaines = reste % 1000;
        if (milliers > 0) {
          resultat += ' ' + milliers.toString() + ' mille';
        }
        if (centaines > 0) {
          resultat += ' ' + centaines.toString();
        }
      }
    }

    return resultat + ' francs CFA';
  }

  private static async addLogoToInvoice(pdf: jsPDF, x: number, y: number, width: number, height: number): Promise<void> {
    try {
      // Vérifier si un logo est configuré dans les paramètres
      if (CABINET_CONFIG.logo && CABINET_CONFIG.logo.trim() !== '') {
        // Créer une image temporaire pour tester le logo
        const img = new Image();
        img.crossOrigin = 'anonymous';
        
        return new Promise((resolve, reject) => {
          img.onload = () => {
            try {
              // Créer un canvas pour convertir l'image
              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              
              canvas.width = width * 4; // Haute résolution
              canvas.height = height * 4;
              
              if (ctx) {
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                const dataURL = canvas.toDataURL('image/jpeg', 0.8);
                
                // Ajouter l'image au PDF
                pdf.addImage(dataURL, 'JPEG', x, y, width, height);
              }
              resolve();
            } catch (error) {
              console.warn('Erreur lors de l\'ajout du logo:', error);
              this.addDefaultLogo(pdf, x, y, width, height);
              resolve();
            }
          };
          
          img.onerror = () => {
            console.warn('Impossible de charger le logo depuis les paramètres');
            this.addDefaultLogo(pdf, x, y, width, height);
            resolve();
          };
          
          img.src = CABINET_CONFIG.logo;
        });
      } else {
        // Utiliser le logo par défaut
        this.addDefaultLogo(pdf, x, y, width, height);
      }
    } catch (error) {
      console.warn('Erreur lors du traitement du logo:', error);
      this.addDefaultLogo(pdf, x, y, width, height);
    }
  }

  private static addDefaultLogo(pdf: jsPDF, x: number, y: number, width: number, height: number): void {
    // Logo par défaut - Icône calculatrice stylisée
    pdf.setFillColor(59, 130, 246);
    pdf.roundedRect(x, y, width, height, 3, 3, 'F');
    
    // Grille de boutons de calculatrice
    pdf.setFillColor(255, 255, 255);
    const buttonSize = 2;
    const spacing = 3;
    
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 4; col++) {
        const btnX = x + 2 + (col * spacing);
        const btnY = y + 2 + (row * spacing);
        pdf.roundedRect(btnX, btnY, buttonSize, buttonSize, 0.5, 0.5, 'F');
      }
    }
    
    // Texte "CALC" en bas du logo
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(6);
    pdf.setFont('helvetica', 'bold');
    pdf.text('CALC', x + width/2, y + height - 1, { align: 'center' });
  }

  static async generateInvoicePDF(facture: Facture, client: Client): Promise<void> {
    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;
      let yPosition = 20;

      // En-tête avec logo et informations cabinet
      pdf.setFillColor(59, 130, 246);
      pdf.rect(0, 0, pageWidth, 50, 'F');

      // Ajouter le logo (depuis paramètres ou par défaut)
      await this.addLogoToInvoice(pdf, 15, 10, 25, 25);

      // Informations cabinet
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(18);
      pdf.setFont('helvetica', 'bold');
      pdf.text(CABINET_CONFIG.nom, 50, 20);
      
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      pdf.text(CABINET_CONFIG.expertComptable, 50, 28);
      pdf.text(`N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre}`, 50, 34);
      pdf.text(`${CABINET_CONFIG.adresse}`, 50, 40);
      pdf.text(`Tél: ${CABINET_CONFIG.telephone} | Email: ${CABINET_CONFIG.email}`, 50, 46);

      yPosition = 65;

      // Titre FACTURE
      pdf.setTextColor(59, 130, 246);
      pdf.setFontSize(24);
      pdf.setFont('helvetica', 'bold');
      pdf.text('FACTURE', pageWidth / 2, yPosition, { align: 'center' });
      
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`N° ${facture.numeroFacture}`, pageWidth / 2, yPosition + 10, { align: 'center' });

      yPosition += 25;

      // Informations client et facture en deux colonnes
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(11);
      pdf.setFont('helvetica', 'bold');
      
      // Colonne gauche - Client
      pdf.text('FACTURÉ À:', margin, yPosition);
      yPosition += 8;
      
      pdf.setFont('helvetica', 'normal');
      pdf.text(client.nom, margin, yPosition);
      yPosition += 6;
      pdf.text(client.raisonSociale, margin, yPosition);
      yPosition += 6;
      
      // Gérer les adresses longues
      const adresseLines = pdf.splitTextToSize(client.adresse, 80);
      pdf.text(adresseLines, margin, yPosition);
      yPosition += adresseLines.length * 6;
      
      pdf.text(`Tél: ${client.telephone}`, margin, yPosition);
      yPosition += 6;
      pdf.text(`Email: ${client.email}`, margin, yPosition);
      yPosition += 6;
      pdf.text(`N° Contribuable: ${client.numeroContribuable}`, margin, yPosition);

      // Colonne droite - Informations facture
      let rightColumnY = 98;
      pdf.setFont('helvetica', 'bold');
      pdf.text('INFORMATIONS FACTURE:', 110, rightColumnY);
      rightColumnY += 8;
      
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Date d'émission: ${this.formatDate(facture.dateEmission)}`, 110, rightColumnY);
      rightColumnY += 6;
      pdf.text(`Date d'échéance: ${this.formatDate(facture.dateEcheance)}`, 110, rightColumnY);
      rightColumnY += 6;
      
      const delaiPaiement = Math.ceil((facture.dateEcheance.getTime() - facture.dateEmission.getTime()) / (1000 * 60 * 60 * 24));
      pdf.text(`Délai de paiement: ${delaiPaiement} jours`, 110, rightColumnY);
      rightColumnY += 6;
      
      const tauxTVA = Math.round((facture.tva / facture.montantHT) * 100);
      pdf.text(`Taux TVA: ${tauxTVA}%`, 110, rightColumnY);
      rightColumnY += 6;
      pdf.text(`Statut: ${facture.statut.toUpperCase()}`, 110, rightColumnY);

      yPosition = Math.max(yPosition, rightColumnY) + 15;

      // Tableau des services
      const tableStartY = yPosition;
      const tableWidth = pageWidth - (margin * 2);
      const colWidths = [90, 20, 35, 35]; // Description, Qté, Prix Unit, Total
      
      // En-tête du tableau
      pdf.setFillColor(248, 250, 252);
      pdf.rect(margin, yPosition, tableWidth, 12, 'F');
      pdf.setDrawColor(203, 213, 225);
      pdf.rect(margin, yPosition, tableWidth, 12, 'S');
      
      pdf.setTextColor(51, 65, 85);
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'bold');
      
      let xPos = margin + 5;
      pdf.text('DESCRIPTION DES SERVICES', xPos, yPosition + 8);
      xPos += colWidths[0];
      pdf.text('QTÉ', xPos, yPosition + 8);
      xPos += colWidths[1];
      pdf.text('PRIX UNIT.', xPos, yPosition + 8);
      xPos += colWidths[2];
      pdf.text('TOTAL HT', xPos, yPosition + 8);

      yPosition += 12;

      // Lignes des services
      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(0, 0, 0);
      
      facture.services.forEach((service, index) => {
        // Ligne alternée
        if (index % 2 === 0) {
          pdf.setFillColor(252, 252, 252);
          pdf.rect(margin, yPosition, tableWidth, 10, 'F');
        }
        
        xPos = margin + 5;
        
        // Description (avec gestion du texte long)
        const descLines = pdf.splitTextToSize(service.description, colWidths[0] - 10);
        pdf.text(descLines, xPos, yPosition + 7);
        
        xPos += colWidths[0];
        pdf.text(service.quantite.toString(), xPos + 5, yPosition + 7);
        
        xPos += colWidths[1];
        pdf.text(this.formatMontant(service.prixUnitaire), xPos + 5, yPosition + 7);
        
        xPos += colWidths[2];
        pdf.text(this.formatMontant(service.montantHT), xPos + 5, yPosition + 7);
        
        yPosition += Math.max(10, descLines.length * 5);
      });

      // Ligne de séparation avant totaux
      pdf.setDrawColor(203, 213, 225);
      pdf.line(margin, yPosition + 5, pageWidth - margin, yPosition + 5);
      yPosition += 15;

      // Section totaux
      const totalsX = pageWidth - 80;
      
      pdf.setFont('helvetica', 'normal');
      pdf.text('Total HT:', totalsX - 30, yPosition);
      pdf.text(this.formatMontant(facture.montantHT), totalsX, yPosition);
      yPosition += 8;

      pdf.text(`TVA (${tauxTVA}%):`, totalsX - 30, yPosition);
      pdf.text(this.formatMontant(facture.tva), totalsX, yPosition);
      yPosition += 8;

      // Total TTC en surbrillance
      pdf.setFillColor(59, 130, 246);
      pdf.rect(totalsX - 35, yPosition - 5, 70, 12, 'F');
      
      pdf.setTextColor(255, 255, 255);
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(12);
      pdf.text('TOTAL TTC:', totalsX - 30, yPosition + 3);
      pdf.text(this.formatMontant(facture.montantTTC), totalsX, yPosition + 3);

      yPosition += 20;

      // Montant en lettres
      pdf.setTextColor(0, 0, 0);
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Arrêté la présente facture à la somme de:', margin, yPosition);
      yPosition += 8;
      
      pdf.setFont('helvetica', 'italic');
      const montantEnLettres = this.convertirMontantEnLettres(facture.montantTTC);
      const lettresLines = pdf.splitTextToSize(montantEnLettres.toUpperCase(), pageWidth - (margin * 2));
      pdf.text(lettresLines, margin, yPosition);
      yPosition += lettresLines.length * 6 + 10;

      // Conditions de paiement
      pdf.setFont('helvetica', 'bold');
      pdf.text('CONDITIONS DE PAIEMENT:', margin, yPosition);
      yPosition += 8;
      
      pdf.setFont('helvetica', 'normal');
      const conditions = [
        `• Échéance: ${this.formatDate(facture.dateEcheance)}`,
        '• Paiement par virement bancaire ou chèque',
        '• Pénalités de retard: 1,5% par mois de retard',
        '• Escompte pour paiement anticipé: nous consulter'
      ];
      
      conditions.forEach(condition => {
        pdf.text(condition, margin, yPosition);
        yPosition += 6;
      });

      yPosition += 10;

      // Coordonnées bancaires
      if (CABINET_CONFIG.coordonneesBancaires) {
        pdf.setFont('helvetica', 'bold');
        pdf.text('COORDONNÉES BANCAIRES:', margin, yPosition);
        yPosition += 8;
        
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(9);
        const coordonnees = CABINET_CONFIG.coordonneesBancaires.split('\n');
        coordonnees.forEach(ligne => {
          pdf.text(ligne, margin, yPosition);
          yPosition += 5;
        });
      }

      // Zone signature
      yPosition = Math.max(yPosition + 20, pageHeight - 60);
      
      pdf.setDrawColor(203, 213, 225);
      pdf.rect(pageWidth - 80, yPosition, 60, 30, 'S');
      
      pdf.setFontSize(9);
      pdf.setFont('helvetica', 'normal');
      pdf.text('Signature et cachet', pageWidth - 50, yPosition - 3, { align: 'center' });

      // Pied de page
      pdf.setFontSize(8);
      pdf.setTextColor(100, 116, 139);
      const footerText = `${CABINET_CONFIG.nom} - ${CABINET_CONFIG.expertComptable} - N° Ordre: ${CABINET_CONFIG.numeroOrdre}`;
      pdf.text(footerText, pageWidth / 2, pageHeight - 10, { align: 'center' });

      // Télécharger le PDF
      const timestamp = new Date().toISOString().split('T')[0];
      pdf.save(`facture-${facture.numeroFacture}-${timestamp}.pdf`);
      
    } catch (error) {
      console.error('Erreur lors de la génération de la facture PDF:', error);
      alert('❌ Erreur lors de la génération de la facture PDF. Veuillez réessayer.');
    }
  }

  static generateHTMLInvoice(facture: Facture, client: Client): string {
    const tauxTVA = Math.round((facture.tva / facture.montantHT) * 100);
    const delaiPaiement = Math.ceil((facture.dateEcheance.getTime() - facture.dateEmission.getTime()) / (1000 * 60 * 60 * 24));
    
    return `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture ${facture.numeroFacture}</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .page-break { page-break-before: always; }
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.5;
            color: #333;
            margin: 0;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            padding: 30px;
            display: flex;
            align-items: center;
        }
        
        .logo-section {
            margin-right: 30px;
        }
        
        .logo {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.2);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
        }
        
        .cabinet-info h1 {
            margin: 0 0 5px 0;
            font-size: 1.8em;
            font-weight: 300;
        }
        
        .cabinet-info p {
            margin: 2px 0;
            opacity: 0.9;
            font-size: 0.9em;
        }
        
        .invoice-title {
            text-align: center;
            padding: 20px;
            background: #f8fafc;
            border-bottom: 3px solid #3b82f6;
        }
        
        .invoice-title h2 {
            margin: 0;
            color: #3b82f6;
            font-size: 2em;
        }
        
        .invoice-title p {
            margin: 5px 0 0 0;
            color: #64748b;
            font-size: 1.1em;
        }
        
        .invoice-details {
            padding: 30px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
        }
        
        .client-section h3,
        .invoice-section h3 {
            color: #1e40af;
            margin: 0 0 15px 0;
            font-size: 1.1em;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 5px;
        }
        
        .client-section p,
        .invoice-section p {
            margin: 5px 0;
            font-size: 0.95em;
        }
        
        .services-section {
            padding: 0 30px 30px 30px;
        }
        
        .services-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .services-table th {
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            color: #334155;
            padding: 15px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 0.9em;
            border-bottom: 2px solid #cbd5e1;
        }
        
        .services-table td {
            padding: 12px 10px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.9em;
        }
        
        .services-table tr:nth-child(even) {
            background: #f8fafc;
        }
        
        .services-table tr:hover {
            background: #f1f5f9;
        }
        
        .amount-cell {
            text-align: right;
            font-family: 'Courier New', monospace;
            font-weight: 500;
        }
        
        .totals-section {
            background: #f8fafc;
            padding: 20px 30px;
            border-top: 2px solid #e2e8f0;
        }
        
        .totals-table {
            width: 100%;
            max-width: 300px;
            margin-left: auto;
        }
        
        .totals-table td {
            padding: 8px 15px;
            font-size: 1em;
        }
        
        .total-ht {
            border-bottom: 1px solid #cbd5e1;
        }
        
        .total-ttc {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            font-weight: bold;
            font-size: 1.2em;
        }
        
        .amount-words {
            background: #fef3c7;
            border: 1px solid #f59e0b;
            padding: 15px;
            margin: 20px 30px;
            border-radius: 6px;
        }
        
        .amount-words p {
            margin: 0;
            font-style: italic;
            color: #92400e;
        }
        
        .payment-terms {
            padding: 20px 30px;
            background: #f0f9ff;
            border-top: 1px solid #e2e8f0;
        }
        
        .payment-terms h4 {
            color: #0c4a6e;
            margin: 0 0 10px 0;
        }
        
        .payment-terms ul {
            margin: 0;
            padding-left: 20px;
        }
        
        .payment-terms li {
            margin: 5px 0;
            color: #0c4a6e;
        }
        
        .signature-section {
            padding: 20px 30px;
            text-align: right;
        }
        
        .signature-box {
            border: 2px dashed #cbd5e1;
            width: 200px;
            height: 80px;
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            font-style: italic;
        }
        
        .footer {
            background: #1e293b;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 0.8em;
        }
        
        .print-button {
            background: #10b981;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1em;
            margin: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .print-button:hover {
            background: #059669;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button class="print-button" onclick="window.print()">🖨️ Imprimer la facture</button>
        <button class="print-button" onclick="window.close()">❌ Fermer</button>
    </div>

    <div class="invoice-container">
        <div class="header">
            <div class="logo-section">
                ${CABINET_CONFIG.logo ? `
                    <img src="${CABINET_CONFIG.logo}" alt="Logo" style="width: 60px; height: 60px; object-fit: contain; border-radius: 8px; background: rgba(255,255,255,0.1); padding: 5px;">
                ` : `
                    <div class="logo">
                        <div style="text-align: center;">
                            <div style="font-size: 16px;">📊</div>
                            <div style="font-size: 8px; margin-top: 2px;">CALC</div>
                        </div>
                    </div>
                `}
            </div>
            <div class="cabinet-info">
                <h1>${CABINET_CONFIG.nom}</h1>
                <p>${CABINET_CONFIG.expertComptable}</p>
                <p>N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre}</p>
                <p>${CABINET_CONFIG.adresse}</p>
                <p>Tél: ${CABINET_CONFIG.telephone} | Email: ${CABINET_CONFIG.email}</p>
            </div>
        </div>

        <div class="invoice-title">
            <h2>FACTURE</h2>
            <p>N° ${facture.numeroFacture}</p>
        </div>

        <div class="invoice-details">
            <div class="client-section">
                <h3>FACTURÉ À</h3>
                <p><strong>${client.nom}</strong></p>
                <p>${client.raisonSociale}</p>
                <p>${client.adresse}</p>
                <p>Tél: ${client.telephone}</p>
                <p>Email: ${client.email}</p>
                <p>N° Contribuable: ${client.numeroContribuable}</p>
            </div>
            
            <div class="invoice-section">
                <h3>INFORMATIONS FACTURE</h3>
                <p><strong>Date d'émission:</strong> ${this.formatDate(facture.dateEmission)}</p>
                <p><strong>Date d'échéance:</strong> ${this.formatDate(facture.dateEcheance)}</p>
                <p><strong>Délai de paiement:</strong> ${delaiPaiement} jours</p>
                <p><strong>Taux TVA:</strong> ${tauxTVA}%</p>
                <p><strong>Statut:</strong> ${facture.statut.toUpperCase()}</p>
            </div>
        </div>

        <div class="services-section">
            <h3 style="color: #1e40af; margin-bottom: 15px;">DÉTAIL DES PRESTATIONS</h3>
            
            <table class="services-table">
                <thead>
                    <tr>
                        <th style="width: 50%;">Description des services</th>
                        <th style="width: 10%; text-align: center;">Qté</th>
                        <th style="width: 20%; text-align: right;">Prix unitaire</th>
                        <th style="width: 20%; text-align: right;">Total HT</th>
                    </tr>
                </thead>
                <tbody>
                    ${facture.services.map(service => `
                        <tr>
                            <td>${service.description}</td>
                            <td style="text-align: center;">${service.quantite}</td>
                            <td class="amount-cell">${this.formatMontant(service.prixUnitaire)}</td>
                            <td class="amount-cell">${this.formatMontant(service.montantHT)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>

        <div class="totals-section">
            <table class="totals-table">
                <tr class="total-ht">
                    <td><strong>Total HT:</strong></td>
                    <td class="amount-cell"><strong>${this.formatMontant(facture.montantHT)}</strong></td>
                </tr>
                <tr class="total-ht">
                    <td><strong>TVA (${tauxTVA}%):</strong></td>
                    <td class="amount-cell"><strong>${this.formatMontant(facture.tva)}</strong></td>
                </tr>
                <tr class="total-ttc">
                    <td><strong>TOTAL TTC:</strong></td>
                    <td class="amount-cell"><strong>${this.formatMontant(facture.montantTTC)}</strong></td>
                </tr>
            </table>
        </div>

        <div class="amount-words">
            <p><strong>Arrêté la présente facture à la somme de:</strong></p>
            <p><strong>${this.convertirMontantEnLettres(facture.montantTTC).toUpperCase()}</strong></p>
        </div>

        <div class="payment-terms">
            <h4>CONDITIONS DE PAIEMENT</h4>
            <ul>
                <li>Échéance: ${this.formatDate(facture.dateEcheance)}</li>
                <li>Paiement par virement bancaire ou chèque</li>
                <li>Pénalités de retard: 1,5% par mois de retard</li>
                <li>Escompte pour paiement anticipé: nous consulter</li>
            </ul>
            
            ${CABINET_CONFIG.coordonneesBancaires ? `
                <h4 style="margin-top: 20px;">COORDONNÉES BANCAIRES</h4>
                <div style="font-family: monospace; font-size: 0.9em; background: white; padding: 10px; border-radius: 4px;">
                    ${CABINET_CONFIG.coordonneesBancaires.split('\n').map(ligne => `<div>${ligne}</div>`).join('')}
                </div>
            ` : ''}
        </div>

        <div class="signature-section">
            <p style="margin-bottom: 10px;"><strong>Signature et cachet</strong></p>
            <div class="signature-box">
                Zone de signature
            </div>
        </div>

        <div class="footer">
            <p>${CABINET_CONFIG.nom} - ${CABINET_CONFIG.expertComptable}</p>
            <p>N° Ordre OEC: ${CABINET_CONFIG.numeroOrdre} | ${CABINET_CONFIG.adresse}</p>
            <p>Tél: ${CABINET_CONFIG.telephone} | Email: ${CABINET_CONFIG.email}</p>
        </div>
    </div>
</body>
</html>`;
  }

  static openPrintableInvoice(htmlContent: string): void {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.focus();
        }, 500);
      };
    }
  }
}