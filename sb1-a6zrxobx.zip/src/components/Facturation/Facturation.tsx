import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, Send, DollarSign, Calendar, Clock, CheckCircle, AlertCircle, Printer, Download } from 'lucide-react';
import type { Facture, Client } from '../../types';
import NewFactureModal from './NewFactureModal';
import InvoicePDFGenerator from './InvoicePDFGenerator';
import EditFactureModal from './EditFactureModal';
import { CreditCard as Edit } from 'lucide-react';
import { useCurrency } from '../../contexts/CurrencyContext';

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  }
];

const mockFactures: Facture[] = [
  {
    id: '1',
    clientId: '1',
    numeroFacture: 'FACT-2024-001',
    dateEmission: new Date('2024-01-15'),
    dateEcheance: new Date('2024-02-15'),
    montantHT: 2500000,
    tva: 450000,
    montantTTC: 2950000,
    statut: 'payee',
    services: [
      {
        id: '1',
        description: 'Tenue de comptabilité - Janvier 2024',
        quantite: 1,
        prixUnitaire: 1500000,
        montantHT: 1500000
      },
      {
        id: '2',
        description: 'Déclaration TVA - Janvier 2024',
        quantite: 1,
        prixUnitaire: 500000,
        montantHT: 500000
      },
      {
        id: '3',
        description: 'Conseil fiscal',
        quantite: 2,
        prixUnitaire: 250000,
        montantHT: 500000
      }
    ]
  },
  {
    id: '2',
    clientId: '1',
    numeroFacture: 'FACT-2024-002',
    dateEmission: new Date('2024-01-20'),
    dateEcheance: new Date('2024-02-20'),
    montantHT: 1800000,
    tva: 324000,
    montantTTC: 2124000,
    statut: 'envoyee',
    services: [
      {
        id: '4',
        description: 'Révision comptable - Décembre 2023',
        quantite: 1,
        prixUnitaire: 1200000,
        montantHT: 1200000
      },
      {
        id: '5',
        description: 'États financiers annuels',
        quantite: 1,
        prixUnitaire: 600000,
        montantHT: 600000
      }
    ]
  }
];

function Facturation() {
  const { formatAmount } = useCurrency();
  const [factures, setFactures] = useState<Facture[]>(mockFactures);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('tous');
  const [selectedFacture, setSelectedFacture] = useState<Facture | null>(null);
  const [isNewFactureModalOpen, setIsNewFactureModalOpen] = useState(false);
  const [isEditFactureModalOpen, setIsEditFactureModalOpen] = useState(false);
  const [factureToEdit, setFactureToEdit] = useState<Facture | null>(null);

  const filteredFactures = factures.filter(facture => {
    const matchesSearch = facture.numeroFacture.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'tous' || facture.statut === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (statut: Facture['statut']) => {
    switch (statut) {
      case 'brouillon':
        return { class: 'bg-gray-100 text-gray-800', icon: Clock };
      case 'envoyee':
        return { class: 'bg-blue-100 text-blue-800', icon: Send };
      case 'payee':
        return { class: 'bg-green-100 text-green-800', icon: CheckCircle };
      case 'impayee':
        return { class: 'bg-red-100 text-red-800', icon: AlertCircle };
      default:
        return { class: 'bg-gray-100 text-gray-800', icon: Clock };
    }
  };

  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : 'Client inconnu';
  };

  const getTotalCA = () => {
    return factures.reduce((sum, facture) => sum + facture.montantTTC, 0);
  };

  const getFacturesPayees = () => {
    return factures.filter(f => f.statut === 'payee').length;
  };

  const getFacturesEnRetard = () => {
    const today = new Date();
    return factures.filter(f => f.statut === 'envoyee' && f.dateEcheance < today).length;
  };

  const handleSaveNewFacture = (newFactureData: Omit<Facture, 'id'>) => {
    const newFacture: Facture = {
      ...newFactureData,
      id: (factures.length + 1).toString()
    };
    setFactures(prev => [...prev, newFacture]);
  };

  const handleEditFacture = (facture: Facture) => {
    setFactureToEdit(facture);
    setIsEditFactureModalOpen(true);
  };

  const handleSaveEditedFacture = (editedFactureData: Omit<Facture, 'id'>) => {
    if (!factureToEdit) return;
    
    const updatedFacture: Facture = {
      ...editedFactureData,
      id: factureToEdit.id
    };
    
    setFactures(prev => prev.map(f => f.id === factureToEdit.id ? updatedFacture : f));
    setIsEditFactureModalOpen(false);
    setFactureToEdit(null);
  };

  const handlePrintInvoice = (facture: Facture) => {
    const client = mockClients.find(c => c.id === facture.clientId);
    if (!client) {
      alert('❌ Client introuvable pour cette facture');
      return;
    }

    const format = prompt(
      'Choisissez le format d\'impression:\n\n' +
      '1 - Facture PDF (.pdf)\n' +
      '2 - Aperçu et impression directe\n\n' +
      'Tapez le numéro de votre choix (1-2):'
    );

    if (!format || !['1', '2'].includes(format)) {
      return;
    }

    try {
      switch (format) {
        case '1':
          InvoicePDFGenerator.generateInvoicePDF(facture, client);
          alert('📄 Facture PDF générée et téléchargée avec succès !');
          break;

        case '2':
          const htmlInvoice = InvoicePDFGenerator.generateHTMLInvoice(facture, client);
          InvoicePDFGenerator.openPrintableInvoice(htmlInvoice);
          break;
      }
    } catch (error) {
      console.error('Erreur lors de la génération de la facture:', error);
      alert('❌ Erreur lors de la génération de la facture. Veuillez réessayer.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Facturation et Honoraires</h3>
          <p className="text-sm text-gray-600 mt-1">
            Gestion des factures et suivi des honoraires
          </p>
        </div>
        <button
          onClick={() => setIsNewFactureModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouvelle facture</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">CA Total</p>
              <p className="text-2xl font-bold text-gray-900">{formatAmount(getTotalCA())}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Factures payées</p>
              <p className="text-2xl font-bold text-gray-900">{getFacturesPayees()}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total factures</p>
              <p className="text-2xl font-bold text-gray-900">{factures.length}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">En retard</p>
              <p className="text-2xl font-bold text-gray-900">{getFacturesEnRetard()}</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro de facture..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les statuts</option>
              <option value="brouillon">Brouillon</option>
              <option value="envoyee">Envoyées</option>
              <option value="payee">Payées</option>
              <option value="impayee">Impayées</option>
            </select>
          </div>
        </div>
      </div>

      {/* Factures Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Numéro
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date émission
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Échéance
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Montant TTC
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredFactures.map((facture) => {
                const statusInfo = getStatusBadge(facture.statut);
                const StatusIcon = statusInfo.icon;
                
                return (
                  <tr key={facture.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {facture.numeroFacture}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {getClientName(facture.clientId)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {facture.dateEmission.toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {facture.dateEcheance.toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                      {formatAmount(facture.montantTTC)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full ${statusInfo.class}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {facture.statut}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedFacture(facture)}
                          className="text-blue-600 hover:text-blue-800"
                          title="Voir les détails"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                       <button
                         onClick={() => handleEditFacture(facture)}
                         className="text-orange-600 hover:text-orange-800"
                         title="Modifier la facture"
                       >
                         <Edit className="h-4 w-4" />
                       </button>
                        <button
                          onClick={() => handlePrintInvoice(facture)}
                          className="text-green-600 hover:text-green-800"
                          title="Imprimer la facture"
                        >
                          <Printer className="h-4 w-4" />
                        </button>
                        {facture.statut === 'brouillon' && (
                          <button 
                            className="text-purple-600 hover:text-purple-800"
                            title="Envoyer la facture"
                          >
                            <Send className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Facture Detail Modal */}
      {selectedFacture && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Facture {selectedFacture.numeroFacture}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {getClientName(selectedFacture.clientId)}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedFacture(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Informations facture</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date d'émission:</span>
                      <span>{selectedFacture.dateEmission.toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date d'échéance:</span>
                      <span>{selectedFacture.dateEcheance.toLocaleDateString('fr-FR')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Statut:</span>
                      <span className="capitalize">{selectedFacture.statut}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Montants</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Montant HT:</span>
                      <span className="font-mono">{formatAmount(selectedFacture.montantHT)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">TVA (18%):</span>
                      <span className="font-mono">{formatAmount(selectedFacture.tva)}</span>
                    </div>
                    <div className="flex justify-between font-medium border-t pt-2">
                      <span>Montant TTC:</span>
                      <span className="font-mono">{formatAmount(selectedFacture.montantTTC)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-4">Services facturés</h4>
                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Description
                        </th>
                        <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">
                          Quantité
                        </th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                          Prix unitaire
                        </th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                          Montant HT
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {selectedFacture.services.map((service) => (
                        <tr key={service.id}>
                          <td className="px-4 py-2 text-sm text-gray-900">
                            {service.description}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900 text-center">
                            {service.quantite}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                            {formatAmount(service.prixUnitaire)}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                            {formatAmount(service.montantHT)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Actions de la facture */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <div className="text-sm text-gray-500">
                  Facture créée le {selectedFacture.dateEmission.toLocaleDateString('fr-FR')}
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handlePrintInvoice(selectedFacture)}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                  >
                    <Printer className="h-4 w-4" />
                    <span>Imprimer</span>
                  </button>
                  <button
                    onClick={() => setSelectedFacture(null)}
                    className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Facture Modal */}
      <NewFactureModal
        isOpen={isNewFactureModalOpen}
        onClose={() => setIsNewFactureModalOpen(false)}
        onSave={handleSaveNewFacture}
      />

      {/* Edit Facture Modal */}
      <EditFactureModal
        isOpen={isEditFactureModalOpen}
        onClose={() => {
          setIsEditFactureModalOpen(false);
          setFactureToEdit(null);
        }}
        onSave={handleSaveEditedFacture}
        facture={factureToEdit}
      />

      {filteredFactures.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune facture trouvée</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Commencez par créer votre première facture'}
          </p>
        </div>
      )}
    </div>
  );
}

export default Facturation;