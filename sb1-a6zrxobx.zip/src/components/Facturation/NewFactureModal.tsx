import React, { useState } from 'react';
import { X, Plus, Trash2, Calculator, Save, AlertCircle, FileText, Calendar, DollarSign } from 'lucide-react';
import type { Facture, ServiceFacture, Client } from '../../types';

interface NewFactureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (facture: Omit<Facture, 'id'>) => void;
}

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif'
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'actif'
  }
];

const servicesComptables = [
  {
    code: 'TENUE_COMPTA',
    description: 'Tenue de comptabilité mensuelle',
    prixUnitaire: 150000,
    unite: 'mois'
  },
  {
    code: 'DECL_TVA',
    description: 'Déclaration TVA mensuelle',
    prixUnitaire: 50000,
    unite: 'déclaration'
  },
  {
    code: 'DECL_IS',
    description: 'Déclaration Impôt sur les Sociétés',
    prixUnitaire: 200000,
    unite: 'déclaration'
  },
  {
    code: 'ETATS_FINANCIERS',
    description: 'États financiers annuels (Bilan, Compte de résultat, TAFIRE)',
    prixUnitaire: 300000,
    unite: 'exercice'
  },
  {
    code: 'REVISION_COMPTA',
    description: 'Révision comptable',
    prixUnitaire: 100000,
    unite: 'heure'
  },
  {
    code: 'CONSEIL_FISCAL',
    description: 'Conseil fiscal et juridique',
    prixUnitaire: 75000,
    unite: 'heure'
  },
  {
    code: 'AUDIT_INTERNE',
    description: 'Mission d\'audit interne',
    prixUnitaire: 125000,
    unite: 'jour'
  },
  {
    code: 'FORMATION',
    description: 'Formation comptable et fiscale',
    prixUnitaire: 50000,
    unite: 'heure'
  },
  {
    code: 'ACCOMPAGNEMENT',
    description: 'Accompagnement création d\'entreprise',
    prixUnitaire: 250000,
    unite: 'forfait'
  },
  {
    code: 'AUTRE',
    description: 'Autre prestation',
    prixUnitaire: 0,
    unite: 'forfait'
  }
];

const tauxTVA = [
  { value: 0, label: '0% (Exonéré)' },
  { value: 9, label: '9% (Taux réduit)' },
  { value: 18, label: '18% (Taux normal)' }
];

const delaisPaiement = [
  { value: 0, label: 'Comptant' },
  { value: 15, label: '15 jours' },
  { value: 30, label: '30 jours' },
  { value: 45, label: '45 jours' },
  { value: 60, label: '60 jours' }
];

export default function NewFactureModal({ isOpen, onClose, onSave }: NewFactureModalProps) {
  const [formData, setFormData] = useState({
    clientId: '',
    dateEmission: new Date().toISOString().split('T')[0],
    delaiPaiement: 30,
    numeroFacture: '',
    exercice: new Date().getFullYear().toString(),
    tauxTVA: 18,
    observations: ''
  });

  const [services, setServices] = useState<Omit<ServiceFacture, 'id'>[]>([
    {
      description: '',
      quantite: 1,
      prixUnitaire: 0,
      montantHT: 0
    }
  ]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Génération automatique du numéro de facture
    if (name === 'clientId' && value) {
      const client = mockClients.find(c => c.id === value);
      if (client) {
        const prefix = 'FACT';
        const year = new Date().getFullYear();
        const nextNumber = String(Math.floor(Math.random() * 999) + 1).padStart(3, '0');
        setFormData(prev => ({ 
          ...prev, 
          numeroFacture: `${prefix}-${year}-${nextNumber}` 
        }));
      }
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleServiceChange = (index: number, field: keyof Omit<ServiceFacture, 'id'>, value: string | number) => {
    const newServices = [...services];
    
    if (field === 'description' && typeof value === 'string') {
      // Auto-remplissage selon le service sélectionné
      const serviceTemplate = servicesComptables.find(s => s.code === value || s.description === value);
      if (serviceTemplate) {
        newServices[index] = {
          ...newServices[index],
          description: serviceTemplate.description,
          prixUnitaire: serviceTemplate.prixUnitaire,
          montantHT: serviceTemplate.prixUnitaire * newServices[index].quantite
        };
      } else {
        newServices[index] = { ...newServices[index], [field]: value };
      }
    } else {
      newServices[index] = { ...newServices[index], [field]: value };
    }

    // Recalcul du montant HT
    if (field === 'quantite' || field === 'prixUnitaire') {
      const quantite = field === 'quantite' ? Number(value) : newServices[index].quantite;
      const prixUnitaire = field === 'prixUnitaire' ? Number(value) : newServices[index].prixUnitaire;
      newServices[index].montantHT = quantite * prixUnitaire;
    }
    
    setServices(newServices);
  };

  const addService = () => {
    setServices(prev => [...prev, {
      description: '',
      quantite: 1,
      prixUnitaire: 0,
      montantHT: 0
    }]);
  };

  const removeService = (index: number) => {
    if (services.length > 1) {
      setServices(prev => prev.filter((_, i) => i !== index));
    }
  };

  const getTotalHT = () => {
    return services.reduce((sum, service) => sum + (service.montantHT || 0), 0);
  };

  const getTVA = () => {
    return (getTotalHT() * formData.tauxTVA) / 100;
  };

  const getTotalTTC = () => {
    return getTotalHT() + getTVA();
  };

  const getDateEcheance = () => {
    const dateEmission = new Date(formData.dateEmission);
    const dateEcheance = new Date(dateEmission);
    dateEcheance.setDate(dateEcheance.getDate() + formData.delaiPaiement);
    return dateEcheance;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Champs obligatoires
    if (!formData.clientId) newErrors.clientId = 'Le client est obligatoire';
    if (!formData.dateEmission) newErrors.dateEmission = 'La date d\'émission est obligatoire';
    if (!formData.numeroFacture.trim()) newErrors.numeroFacture = 'Le numéro de facture est obligatoire';

    // Validation des services
    const servicesValides = services.filter(service => 
      service.description.trim() && service.quantite > 0 && service.prixUnitaire >= 0
    );

    if (servicesValides.length === 0) {
      newErrors.services = 'Au moins un service avec description, quantité et prix est requis';
    }

    // Validation du montant total
    if (getTotalHT() <= 0) {
      newErrors.montant = 'Le montant total HT doit être supérieur à 0';
    }

    // Validation de la date
    const dateEmission = new Date(formData.dateEmission);
    const today = new Date();
    const unAnAvant = new Date();
    unAnAvant.setFullYear(today.getFullYear() - 1);
    
    if (dateEmission > today) {
      newErrors.dateEmission = 'La date d\'émission ne peut pas être dans le futur';
    }
    if (dateEmission < unAnAvant) {
      newErrors.dateEmission = 'La date d\'émission ne peut pas être antérieure à un an';
    }

    // Validation des services individuels
    services.forEach((service, index) => {
      if (service.description.trim() && service.quantite <= 0) {
        newErrors[`service_${index}_quantite`] = 'La quantité doit être supérieure à 0';
      }
      if (service.description.trim() && service.prixUnitaire < 0) {
        newErrors[`service_${index}_prix`] = 'Le prix unitaire ne peut pas être négatif';
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const servicesValides = services
        .filter(service => service.description.trim() && service.quantite > 0)
        .map((service, index) => ({
          id: `temp_${index}`,
          ...service
        }));

      const nouvelleFacture: Omit<Facture, 'id'> = {
        clientId: formData.clientId,
        numeroFacture: formData.numeroFacture.trim(),
        dateEmission: new Date(formData.dateEmission),
        dateEcheance: getDateEcheance(),
        montantHT: getTotalHT(),
        tva: getTVA(),
        montantTTC: getTotalTTC(),
        statut: 'brouillon',
        services: servicesValides
      };

      onSave(nouvelleFacture);
      onClose();
      
      // Reset form
      setFormData({
        clientId: '',
        dateEmission: new Date().toISOString().split('T')[0],
        delaiPaiement: 30,
        numeroFacture: '',
        exercice: new Date().getFullYear().toString(),
        tauxTVA: 18,
        observations: ''
      });
      setServices([
        { description: '', quantite: 1, prixUnitaire: 0, montantHT: 0 }
      ]);
    } catch (error) {
      console.error('Erreur lors de la création de la facture:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatMontant = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(montant);
  };

  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : '';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-6xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouvelle Facture d'Honoraires</h3>
                <p className="text-sm text-gray-600">Facturation des prestations comptables</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* En-tête de la facture */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-blue-600" />
              En-tête de la facture
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.clientId ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un client</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.nom}</option>
                  ))}
                </select>
                {errors.clientId && <p className="text-red-500 text-xs mt-1">{errors.clientId}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date d'émission <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="dateEmission"
                  value={formData.dateEmission}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.dateEmission ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.dateEmission && <p className="text-red-500 text-xs mt-1">{errors.dateEmission}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Délai de paiement
                </label>
                <select
                  name="delaiPaiement"
                  value={formData.delaiPaiement}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {delaisPaiement.map(delai => (
                    <option key={delai.value} value={delai.value}>{delai.label}</option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  Échéance: {getDateEcheance().toLocaleDateString('fr-FR')}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  N° Facture <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="numeroFacture"
                  value={formData.numeroFacture}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.numeroFacture ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: FACT-2024-001"
                />
                {errors.numeroFacture && <p className="text-red-500 text-xs mt-1">{errors.numeroFacture}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Exercice
                </label>
                <input
                  type="text"
                  name="exercice"
                  value={formData.exercice}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="2024"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Taux TVA
                </label>
                <select
                  name="tauxTVA"
                  value={formData.tauxTVA}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {tauxTVA.map(taux => (
                    <option key={taux.value} value={taux.value}>{taux.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Services facturés */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900 flex items-center">
                <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                Services facturés
              </h4>
              <button
                type="button"
                onClick={addService}
                className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 text-sm"
              >
                <Plus className="h-4 w-4" />
                <span>Ajouter un service</span>
              </button>
            </div>

            {errors.services && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm">{errors.services}</p>
              </div>
            )}

            <div className="overflow-x-auto">
              <table className="w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Description du service
                    </th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                      Quantité
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                      Prix unitaire
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                      Montant HT
                    </th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {services.map((service, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <select
                          value={service.description}
                          onChange={(e) => handleServiceChange(index, 'description', e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        >
                          <option value="">Sélectionner un service</option>
                          {servicesComptables.map(serviceTemplate => (
                            <option key={serviceTemplate.code} value={serviceTemplate.description}>
                              {serviceTemplate.description}
                            </option>
                          ))}
                        </select>
                        {service.description && !servicesComptables.find(s => s.description === service.description) && (
                          <input
                            type="text"
                            value={service.description}
                            onChange={(e) => handleServiceChange(index, 'description', e.target.value)}
                            className="w-full mt-1 border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                            placeholder="Description personnalisée"
                          />
                        )}
                        {errors[`service_${index}_description`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`service_${index}_description`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          value={service.quantite || ''}
                          onChange={(e) => handleServiceChange(index, 'quantite', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="1"
                          min="0"
                          step="0.5"
                        />
                        {errors[`service_${index}_quantite`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`service_${index}_quantite`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          value={service.prixUnitaire || ''}
                          onChange={(e) => handleServiceChange(index, 'prixUnitaire', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm text-right focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="0"
                          min="0"
                          step="1000"
                        />
                        {errors[`service_${index}_prix`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`service_${index}_prix`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-sm font-mono text-right font-medium">
                          {formatMontant(service.montantHT)}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {services.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeService(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50">
                  <tr>
                    <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                      Total HT
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-right font-mono">
                      {formatMontant(getTotalHT())}
                    </td>
                    <td></td>
                  </tr>
                  <tr>
                    <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                      TVA ({formData.tauxTVA}%)
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-right font-mono">
                      {formatMontant(getTVA())}
                    </td>
                    <td></td>
                  </tr>
                  <tr className="border-t-2 border-gray-300">
                    <td colSpan={3} className="px-4 py-3 text-sm font-bold text-gray-900 text-right">
                      Total TTC
                    </td>
                    <td className="px-4 py-3 text-lg font-bold text-right font-mono text-blue-600">
                      {formatMontant(getTotalTTC())}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {errors.montant && (
              <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm flex items-center">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  {errors.montant}
                </p>
              </div>
            )}
          </div>

          {/* Observations */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4">Observations</h4>
            <textarea
              name="observations"
              value={formData.observations}
              onChange={handleInputChange}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Notes particulières, conditions de paiement, etc."
            />
          </div>

          {/* Résumé */}
          {formData.clientId && getTotalHT() > 0 && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Résumé de la facture</h4>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Client:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {getClientName(formData.clientId)}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Montant HT:</span>
                  <span className="ml-2 font-bold text-green-600">{formatMontant(getTotalHT())}</span>
                </div>
                <div>
                  <span className="text-gray-600">TVA:</span>
                  <span className="ml-2 font-bold text-orange-600">{formatMontant(getTVA())}</span>
                </div>
                <div>
                  <span className="text-gray-600">Total TTC:</span>
                  <span className="ml-2 font-bold text-purple-600">{formatMontant(getTotalTTC())}</span>
                </div>
              </div>
              <div className="mt-2 text-sm text-gray-600">
                <span>Échéance de paiement: </span>
                <span className="font-medium">{getDateEcheance().toLocaleDateString('fr-FR')}</span>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting || getTotalHT() <= 0}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Création...' : 'Créer la facture'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}