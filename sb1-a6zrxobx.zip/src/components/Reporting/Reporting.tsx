import React, { useState } from 'react';
import { BarChart3, PieChart, TrendingUp, Download, Calendar, Filter, DollarSign, Users, FileText } from 'lucide-react';
import { ReportGenerator } from './ReportGenerator';
import { CABINET_CONFIG } from '../Parametres/Parametres';
import { useCurrency } from '../../contexts/CurrencyContext';

const mockData = {
  caParMois: [
    { mois: 'Jan', montant: 12500000 },
    { mois: 'Fév', montant: 15200000 },
    { mois: 'Mar', montant: 18700000 },
    { mois: 'Avr', montant: 16800000 },
    { mois: 'Mai', montant: 21300000 },
    { mois: 'Jun', montant: 19500000 }
  ],
  clientsParSecteur: [
    { secteur: 'Commerce', nombre: 15, pourcentage: 31.25 },
    { secteur: 'Services', nombre: 12, pourcentage: 25 },
    { secteur: 'Industrie', nombre: 8, pourcentage: 16.67 },
    { secteur: 'BTP', nombre: 7, pourcentage: 14.58 },
    { secteur: 'Transport', nombre: 6, pourcentage: 12.5 }
  ],
  evolutionClients: [
    { periode: 'Q1 2023', actifs: 35, nouveaux: 8, perdus: 2 },
    { periode: 'Q2 2023', actifs: 41, nouveaux: 9, perdus: 3 },
    { periode: 'Q3 2023', actifs: 45, nouveaux: 7, perdus: 3 },
    { periode: 'Q4 2023', actifs: 48, nouveaux: 6, perdus: 3 }
  ]
};

export default function Reporting() {
  const { formatAmount } = useCurrency();
  const [selectedPeriod, setSelectedPeriod] = useState('6-mois');
  const [selectedReport, setSelectedReport] = useState('ca-evolution');

  const handleExportRapportComplet = () => {
    // Afficher le menu de sélection du format
    const format = prompt(
      'Choisissez le format du rapport:\n\n' +
      '1 - Rapport PDF (.pdf)\n' +
      '2 - Rapport HTML imprimable (.html)\n' +
      '3 - Données CSV (.csv)\n' +
      '4 - Aperçu et impression directe\n\n' +
      'Tapez le numéro de votre choix (1-4):'
    );

    if (!format || !['1', '2', '3', '4'].includes(format)) {
      return;
    }
    try {
      // Préparation des données pour le rapport
      const reportData = {
        caParMois: mockData.caParMois,
        clientsParSecteur: mockData.clientsParSecteur,
        evolutionClients: mockData.evolutionClients,
        kpis: {
          caTotal: mockData.caParMois.reduce((sum, item) => sum + item.montant, 0),
          clientsActifs: 48,
          tauxRetention: 94,
          facturesEmises: 156
        }
      };

      const timestamp = new Date().toISOString().split('T')[0];

      switch (format) {
        case '1':
          // Rapport PDF
          ReportGenerator.generatePDFReport(reportData, CABINET_CONFIG);
          alert('📄 Rapport PDF généré et téléchargé avec succès !');
          break;

        case '2':
          // Rapport HTML
          const htmlReport = ReportGenerator.generateHTMLReport(reportData, CABINET_CONFIG);
          ReportGenerator.downloadReport(htmlReport, `rapport-complet-${timestamp}.html`, 'html');
          alert('🌐 Rapport HTML généré et téléchargé avec succès !\n\nOuvrez le fichier dans votre navigateur pour l\'imprimer.');
          break;

        case '3':
          // Données CSV
          const csvReport = ReportGenerator.generateCSVReport(reportData);
          ReportGenerator.downloadReport(csvReport, `donnees-rapport-${timestamp}.csv`, 'csv');
          alert('📊 Données CSV générées et téléchargées avec succès !\n\nOuvrez le fichier dans Excel ou LibreOffice.');
          break;

        case '4':
          // Aperçu et impression directe
          const printableReport = ReportGenerator.generateHTMLReport(reportData, CABINET_CONFIG);
          ReportGenerator.openPrintableReport(printableReport);
          break;
      }
    } catch (error) {
      console.error('Erreur lors de la génération du rapport:', error);
      alert('❌ Erreur lors de la génération du rapport. Veuillez réessayer.');
    }
  };


  const renderCAEvolution = () => (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-lg font-semibold text-gray-900 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
          Évolution du Chiffre d'Affaires
        </h4>
        <button className="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
          <Download className="h-4 w-4" />
          <span>Exporter</span>
        </button>
      </div>
      
      <div className="h-80 flex items-end justify-between space-x-2 mb-4">
        {mockData.caParMois.map((item, index) => {
          const maxValue = Math.max(...mockData.caParMois.map(d => d.montant));
          const height = (item.montant / maxValue) * 100;
          
          return (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="w-full bg-gray-200 rounded-t-lg relative" style={{ height: '240px' }}>
                <div
                  className="bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-lg absolute bottom-0 w-full transition-all duration-500 hover:from-blue-600 hover:to-blue-500"
                  style={{ height: `${height}%` }}
                ></div>
              </div>
              <div className="mt-2 text-center">
                <div className="text-xs font-medium text-gray-900">{item.mois}</div>
                <div className="text-xs text-gray-600">{formatAmount(item.montant)}</div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">
            {formatAmount(mockData.caParMois.reduce((sum, item) => sum + item.montant, 0))}
          </div>
          <div className="text-sm text-gray-600">CA Total</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">
            {formatAmount(mockData.caParMois.reduce((sum, item) => sum + item.montant, 0) / mockData.caParMois.length)}
          </div>
          <div className="text-sm text-gray-600">CA Moyen</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">+18.5%</div>
          <div className="text-sm text-gray-600">Croissance</div>
        </div>
      </div>
    </div>
  );

  const renderClientsParSecteur = () => (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-lg font-semibold text-gray-900 flex items-center">
          <PieChart className="h-5 w-5 mr-2 text-green-600" />
          Répartition des Clients par Secteur
        </h4>
        <button className="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
          <Download className="h-4 w-4" />
          <span>Exporter</span>
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          {mockData.clientsParSecteur.map((item, index) => {
            const colors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500', 'bg-red-500'];
            return (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full ${colors[index]}`}></div>
                  <span className="font-medium text-gray-900">{item.secteur}</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-gray-900">{item.nombre}</div>
                  <div className="text-sm text-gray-600">{item.pourcentage}%</div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="flex items-center justify-center">
          <div className="relative w-48 h-48">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              {mockData.clientsParSecteur.map((item, index) => {
                const colors = ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444'];
                const startAngle = mockData.clientsParSecteur.slice(0, index).reduce((sum, prev) => sum + (prev.pourcentage * 3.6), 0);
                const endAngle = startAngle + (item.pourcentage * 3.6);
                
                const x1 = 50 + 40 * Math.cos((startAngle * Math.PI) / 180);
                const y1 = 50 + 40 * Math.sin((startAngle * Math.PI) / 180);
                const x2 = 50 + 40 * Math.cos((endAngle * Math.PI) / 180);
                const y2 = 50 + 40 * Math.sin((endAngle * Math.PI) / 180);
                
                const largeArcFlag = item.pourcentage > 50 ? 1 : 0;
                
                return (
                  <path
                    key={index}
                    d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                    fill={colors[index]}
                    className="hover:opacity-80 transition-opacity"
                  />
                );
              })}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );

  const renderEvolutionClients = () => (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h4 className="text-lg font-semibold text-gray-900 flex items-center">
          <Users className="h-5 w-5 mr-2 text-purple-600" />
          Évolution du Portefeuille Clients
        </h4>
        <button className="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
          <Download className="h-4 w-4" />
          <span>Exporter</span>
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Période</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Clients Actifs</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Nouveaux</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Perdus</th>
              <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Évolution</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {mockData.evolutionClients.map((item, index) => {
              const evolution = index > 0 ? item.actifs - mockData.evolutionClients[index - 1].actifs : 0;
              return (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{item.periode}</td>
                  <td className="px-4 py-3 text-sm text-gray-900 text-center font-bold">{item.actifs}</td>
                  <td className="px-4 py-3 text-sm text-center">
                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                      +{item.nouveaux}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-center">
                    <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                      -{item.perdus}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-center">
                    {evolution !== 0 && (
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        evolution > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {evolution > 0 ? '+' : ''}{evolution}
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Reporting et Analyses</h3>
          <p className="text-sm text-gray-600 mt-1">
            Tableaux de bord et analyses de performance
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={handleExportRapportComplet}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span onClick={handleExportRapportComplet}>Rapport complet</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">CA Total</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatAmount(mockData.caParMois.reduce((sum, item) => sum + item.montant, 0))}
              </p>
              <p className="text-sm text-green-600 mt-1">+18.5% vs période précédente</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Clients Actifs</p>
              <p className="text-2xl font-bold text-gray-900">48</p>
              <p className="text-sm text-blue-600 mt-1">+6 nouveaux ce trimestre</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Taux de Rétention</p>
              <p className="text-2xl font-bold text-gray-900">94%</p>
              <p className="text-sm text-green-600 mt-1">+2% vs année précédente</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Factures Émises</p>
              <p className="text-2xl font-bold text-gray-900">156</p>
              <p className="text-sm text-orange-600 mt-1">Ce semestre</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg">
              <FileText className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={selectedReport}
              onChange={(e) => setSelectedReport(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="ca-evolution">Évolution CA</option>
              <option value="clients-secteur">Clients par secteur</option>
              <option value="evolution-clients">Évolution clients</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-gray-400" />
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="6-mois">6 derniers mois</option>
              <option value="12-mois">12 derniers mois</option>
              <option value="annee">Cette année</option>
            </select>
          </div>
        </div>
      </div>

      {/* Reports */}
      <div>
        {selectedReport === 'ca-evolution' && renderCAEvolution()}
        {selectedReport === 'clients-secteur' && renderClientsParSecteur()}
        {selectedReport === 'evolution-clients' && renderEvolutionClients()}
      </div>
    </div>
  );
}