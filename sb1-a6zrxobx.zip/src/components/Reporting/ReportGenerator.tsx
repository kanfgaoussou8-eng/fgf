import React from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import type { Client } from '../../types';

interface ReportData {
  caParMois: Array<{ mois: string; montant: number }>;
  clientsParSecteur: Array<{ secteur: string; nombre: number; pourcentage: number }>;
  evolutionClients: Array<{ periode: string; actifs: number; nouveaux: number; perdus: number }>;
  kpis: {
    caTotal: number;
    clientsActifs: number;
    tauxRetention: number;
    facturesEmises: number;
  };
}

interface CabinetConfig {
  nom: string;
  adresse: string;
  telephone: string;
  email: string;
  numeroOrdre: string;
  expertComptable: string;
  siteWeb: string;
  numeroRCCM: string;
  numeroContribuable: string;
}

export class ReportGenerator {
  private static formatMontant(montant: number): string {
    // Formatage manuel pour éviter les problèmes d'affichage dans le PDF
    const montantStr = montant.toString();
    const reversed = montantStr.split('').reverse().join('');
    const withSpaces = reversed.replace(/(\d{3})/g, '$1 ').trim();
    const formatted = withSpaces.split('').reverse().join('');
    return formatted + ' FCFA';
  }

  private static formatDate(): string {
    return new Date().toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  static generateTextReport(data: ReportData): string {
    // Cette méthode n'est plus utilisée, remplacée par generatePDFReport
    return '';
  }

  static generateHTMLReport(data: ReportData, cabinetConfig: CabinetConfig): string {
    return `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport d'Analyse Complet - Cabinet OHADA</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .page-break { page-break-before: always; }
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .header {
            text-align: center;
            background: linear-gradient(135deg, #1e40af, #3b82f6);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }
        
        .header h2 {
            margin: 10px 0 0 0;
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .meta-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .section {
            background: white;
            margin-bottom: 30px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .section-header {
            background: #f1f5f9;
            padding: 20px;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .section-header h3 {
            margin: 0;
            color: #1e40af;
            font-size: 1.4em;
        }
        
        .section-content {
            padding: 20px;
        }
        
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .kpi-card {
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid #3b82f6;
        }
        
        .kpi-value {
            font-size: 2em;
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 5px;
        }
        
        .kpi-label {
            color: #64748b;
            font-size: 0.9em;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .data-table th,
        .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .data-table th {
            background: #f1f5f9;
            font-weight: 600;
            color: #1e40af;
        }
        
        .data-table tr:hover {
            background: #f8fafc;
        }
        
        .chart-placeholder {
            height: 300px;
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #64748b;
            font-size: 1.1em;
            margin: 20px 0;
        }
        
        .recommendations {
            background: #f0f9ff;
            border-left: 4px solid #0ea5e9;
            padding: 20px;
            margin-top: 20px;
        }
        
        .recommendations ul {
            margin: 0;
            padding-left: 20px;
        }
        
        .recommendations li {
            margin-bottom: 10px;
            color: #0c4a6e;
        }
        
        .footer {
            text-align: center;
            color: #64748b;
            font-size: 0.9em;
            margin-top: 40px;
            padding: 20px;
            border-top: 1px solid #e2e8f0;
        }
        
        .print-button {
            background: #10b981;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1em;
            margin: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .print-button:hover {
            background: #059669;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button class="print-button" onclick="window.print()">🖨️ Imprimer le rapport</button>
        <button class="print-button" onclick="window.close()">❌ Fermer</button>
    </div>

    <div class="header">
        <h1>${cabinetConfig.nom}</h1>
        <h2>Rapport d'Analyse Complet</h2>
        <p style="font-size: 0.9em; margin-top: 10px;">
            ${cabinetConfig.adresse}<br>
            Tél: ${cabinetConfig.telephone} | Email: ${cabinetConfig.email}<br>
            Expert-Comptable: ${cabinetConfig.expertComptable} | N° Ordre: ${cabinetConfig.numeroOrdre}
        </p>
    </div>

    <div class="meta-info">
        <strong>Date de génération :</strong> ${this.formatDate()}<br>
        <strong>Période d'analyse :</strong> ${new Date().getFullYear()}<br>
        <strong>Type de rapport :</strong> Analyse complète des performances
    </div>

    <div class="section">
        <div class="section-header">
            <h3>📊 Indicateurs Clés de Performance</h3>
        </div>
        <div class="section-content">
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-value">${this.formatMontant(data.kpis.caTotal)}</div>
                    <div class="kpi-label">Chiffre d'Affaires Total</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">${data.kpis.clientsActifs}</div>
                    <div class="kpi-label">Clients Actifs</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">${data.kpis.tauxRetention}%</div>
                    <div class="kpi-label">Taux de Rétention</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-value">${data.kpis.facturesEmises}</div>
                    <div class="kpi-label">Factures Émises</div>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-header">
            <h3>📈 Évolution du Chiffre d'Affaires</h3>
        </div>
        <div class="section-content">
            <div class="chart-placeholder">
                📊 Graphique d'évolution mensuelle du CA
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Mois</th>
                        <th>Montant</th>
                        <th>Évolution</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.caParMois.map((item, index) => {
                        const evolution = index > 0 
                            ? ((item.montant - data.caParMois[index - 1].montant) / data.caParMois[index - 1].montant * 100).toFixed(1)
                            : '0.0';
                        return `
                        <tr>
                            <td>${item.mois}</td>
                            <td><strong>${this.formatMontant(item.montant)}</strong></td>
                            <td style="color: ${parseFloat(evolution) >= 0 ? '#10b981' : '#ef4444'}">${evolution}%</td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        </div>
    </div>

    <div class="section page-break">
        <div class="section-header">
            <h3>🏢 Répartition des Clients par Secteur</h3>
        </div>
        <div class="section-content">
            <div class="chart-placeholder">
                🥧 Graphique en secteurs de la répartition clientèle
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Secteur d'Activité</th>
                        <th>Nombre de Clients</th>
                        <th>Pourcentage</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.clientsParSecteur.map(item => `
                    <tr>
                        <td>${item.secteur}</td>
                        <td><strong>${item.nombre}</strong></td>
                        <td>${item.pourcentage.toFixed(1)}%</td>
                    </tr>`).join('')}
                </tbody>
            </table>
        </div>
    </div>

    <div class="section">
        <div class="section-header">
            <h3>👥 Évolution du Portefeuille Client</h3>
        </div>
        <div class="section-content">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Période</th>
                        <th>Clients Actifs</th>
                        <th>Nouveaux</th>
                        <th>Perdus</th>
                        <th>Évolution Nette</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.evolutionClients.map((item, index) => {
                        const evolution = index > 0 
                            ? item.actifs - data.evolutionClients[index - 1].actifs 
                            : 0;
                        return `
                        <tr>
                            <td>${item.periode}</td>
                            <td><strong>${item.actifs}</strong></td>
                            <td style="color: #10b981">+${item.nouveaux}</td>
                            <td style="color: #ef4444">-${item.perdus}</td>
                            <td style="color: ${evolution >= 0 ? '#10b981' : '#ef4444'}">${evolution >= 0 ? '+' : ''}${evolution}</td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        </div>
    </div>

    <div class="recommendations">
        <h3 style="margin-top: 0; color: #0c4a6e;">💡 Recommandations Stratégiques</h3>
        <ul>
            <li><strong>Croissance :</strong> Maintenir la dynamique positive du chiffre d'affaires (+18.5%)</li>
            <li><strong>Fidélisation :</strong> Continuer les efforts de rétention client (${data.kpis.tauxRetention}% de rétention)</li>
            <li><strong>Diversification :</strong> Développer les secteurs à fort potentiel de croissance</li>
            <li><strong>Optimisation :</strong> Améliorer les processus de facturation et de recouvrement</li>
            <li><strong>Innovation :</strong> Proposer de nouveaux services à valeur ajoutée</li>
        </ul>
    </div>

    <div class="footer">
        <p><strong>Rapport généré par ${cabinetConfig.nom}</strong></p>
        <p>© ${new Date().getFullYear()} ${cabinetConfig.nom} - Tous droits réservés</p>
        <p>Expert-Comptable: ${cabinetConfig.expertComptable} | N° Ordre OEC: ${cabinetConfig.numeroOrdre}</p>
        <p>Document confidentiel - Usage interne uniquement</p>
    </div>
</body>
</html>`;
  }

  static generateCSVReport(data: ReportData): string {
    let csv = 'Type,Période,Valeur,Détail\n';
    
    // KPIs
    csv += `KPI,CA Total,${data.kpis.caTotal},Chiffre d'affaires total\n`;
    csv += `KPI,Clients Actifs,${data.kpis.clientsActifs},Nombre de clients actifs\n`;
    csv += `KPI,Taux Rétention,${data.kpis.tauxRetention},Pourcentage de rétention\n`;
    csv += `KPI,Factures Émises,${data.kpis.facturesEmises},Nombre de factures\n`;
    
    // CA par mois
    data.caParMois.forEach(item => {
      csv += `CA Mensuel,${item.mois},${item.montant},Chiffre d'affaires\n`;
    });
    
    // Clients par secteur
    data.clientsParSecteur.forEach(item => {
      csv += `Secteur,${item.secteur},${item.nombre},${item.pourcentage}% du total\n`;
    });
    
    // Évolution clients
    data.evolutionClients.forEach(item => {
      csv += `Évolution,${item.periode},${item.actifs},${item.nouveaux} nouveaux - ${item.perdus} perdus\n`;
    });
    
    return csv;
  }

  static async generatePDFReport(data: ReportData, cabinetConfig: CabinetConfig): Promise<void> {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    let yPosition = 20;

    // En-tête du rapport
    pdf.setFillColor(30, 64, 175);
    pdf.rect(0, 0, pageWidth, 40, 'F');
    
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(18);
    pdf.setFont('helvetica', 'bold');
    pdf.text(cabinetConfig.nom, pageWidth / 2, 15, { align: 'center' });
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    pdf.text('Rapport d\'Analyse Complet', pageWidth / 2, 25, { align: 'center' });
    
    pdf.setFontSize(10);
    pdf.text(`${cabinetConfig.expertComptable} | N° Ordre: ${cabinetConfig.numeroOrdre}`, pageWidth / 2, 32, { align: 'center' });
    pdf.text(`Généré le ${this.formatDate()}`, pageWidth / 2, 37, { align: 'center' });

    yPosition = 55;

    // Fonction pour ajouter une nouvelle page si nécessaire
    const checkPageBreak = (requiredSpace: number) => {
      if (yPosition + requiredSpace > pageHeight - 30) {
        pdf.addPage();
        yPosition = 25;
      }
    };

    // Section KPIs
    checkPageBreak(70);
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('INDICATEURS CLES DE PERFORMANCE', 20, yPosition);
    yPosition += 12;

    // Ligne de séparation
    pdf.setDrawColor(200, 200, 200);
    pdf.line(20, yPosition, pageWidth - 20, yPosition);
    yPosition += 8;

    // KPIs en grille 2x2
    const kpis = [
      { label: 'Chiffre d\'Affaires Total', value: this.formatMontant(data.kpis.caTotal) },
      { label: 'Clients Actifs', value: data.kpis.clientsActifs.toString() },
      { label: 'Taux de Rétention', value: `${data.kpis.tauxRetention}%` },
      { label: 'Factures Émises', value: data.kpis.facturesEmises.toString() }
    ];

    pdf.setTextColor(100, 116, 139);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    
    kpis.forEach((kpi, index) => {
      const x = 20 + (index % 2) * 90;
      const y = yPosition + Math.floor(index / 2) * 20;
      
      // Encadré pour chaque KPI
      pdf.setFillColor(248, 250, 252);
      pdf.rect(x - 2, y - 8, 85, 16, 'F');
      pdf.setDrawColor(220, 220, 220);
      pdf.rect(x - 2, y - 8, 85, 16, 'S');
      
      pdf.text(kpi.label + ':', x, y);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(30, 64, 175);
      pdf.text(kpi.value, x, y + 6);
      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(100, 116, 139);
    });

    yPosition += 45;

    // Section Évolution CA
    checkPageBreak(90);
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('EVOLUTION DU CHIFFRE D\'AFFAIRES', 20, yPosition);
    yPosition += 12;

    // Ligne de séparation
    pdf.setDrawColor(200, 200, 200);
    pdf.line(20, yPosition, pageWidth - 20, yPosition);
    yPosition += 8;

    // Tableau CA
    // En-tête du tableau
    pdf.setFillColor(241, 245, 249);
    pdf.rect(20, yPosition - 3, pageWidth - 40, 10, 'F');
    pdf.setDrawColor(200, 200, 200);
    pdf.rect(20, yPosition - 3, pageWidth - 40, 10, 'S');
    
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Mois', 25, yPosition + 3);
    pdf.text('Montant', 70, yPosition + 3);
    pdf.text('Evolution', 130, yPosition + 3);
    yPosition += 15;

    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100, 116, 139);
    
    data.caParMois.forEach((item, index) => {
      const evolution = index > 0 
        ? ((item.montant - data.caParMois[index - 1].montant) / data.caParMois[index - 1].montant * 100).toFixed(1)
        : '0.0';
      // Ligne alternée
      if (index % 2 === 0) {
        pdf.setFillColor(250, 250, 250);
        pdf.rect(20, yPosition - 3, pageWidth - 40, 8, 'F');
      }
      
      pdf.setTextColor(100, 116, 139);
      pdf.text(item.mois, 25, yPosition);
      pdf.text(this.formatMontant(item.montant), 70, yPosition);
      
      // Couleur pour l'évolution
      if (parseFloat(evolution) >= 0) {
        pdf.setTextColor(16, 185, 129); // Vert
      } else {
        pdf.setTextColor(239, 68, 68); // Rouge
      }
      pdf.text(`${evolution}%`, 130, yPosition);
      
      yPosition += 10;
    });

    yPosition += 15;

    // Section Répartition Clients
    checkPageBreak(70);
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('REPARTITION DES CLIENTS PAR SECTEUR', 20, yPosition);
    yPosition += 12;

    // Ligne de séparation
    pdf.setDrawColor(200, 200, 200);
    pdf.line(20, yPosition, pageWidth - 20, yPosition);
    yPosition += 8;

    // Tableau secteurs
    // En-tête du tableau
    pdf.setFillColor(241, 245, 249);
    pdf.rect(20, yPosition - 3, pageWidth - 40, 10, 'F');
    pdf.setDrawColor(200, 200, 200);
    pdf.rect(20, yPosition - 3, pageWidth - 40, 10, 'S');
    
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Secteur', 25, yPosition + 3);
    pdf.text('Clients', 100, yPosition + 3);
    pdf.text('Pourcentage', 130, yPosition + 3);
    yPosition += 15;

    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(100, 116, 139);
    
    data.clientsParSecteur.forEach((item, index) => {
      // Ligne alternée
      if (index % 2 === 0) {
        pdf.setFillColor(250, 250, 250);
        pdf.rect(20, yPosition - 3, pageWidth - 40, 8, 'F');
      }
      
      pdf.text(item.secteur, 25, yPosition);
      pdf.text(item.nombre.toString(), 100, yPosition);
      pdf.text(`${item.pourcentage.toFixed(1)}%`, 130, yPosition);
      yPosition += 10;
    });

    yPosition += 20;

    // Section Recommandations
    checkPageBreak(60);
    pdf.setTextColor(30, 64, 175);
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.text('RECOMMANDATIONS STRATEGIQUES', 20, yPosition);
    yPosition += 12;

    // Ligne de séparation
    pdf.setDrawColor(200, 200, 200);
    pdf.line(20, yPosition, pageWidth - 20, yPosition);
    yPosition += 8;

    const recommandations = [
      'Maintenir la dynamique positive du chiffre d\'affaires (+18.5%)',
      `Continuer les efforts de rétention client (${data.kpis.tauxRetention}% de rétention)`,
      'Développer les secteurs à fort potentiel de croissance',
      'Améliorer les processus de facturation et de recouvrement',
      'Proposer de nouveaux services à valeur ajoutée'
    ];

    // Encadré pour les recommandations
    pdf.setFillColor(240, 249, 255);
    pdf.rect(20, yPosition - 3, pageWidth - 40, recommandations.length * 10 + 10, 'F');
    pdf.setDrawColor(59, 130, 246);
    pdf.rect(20, yPosition - 3, pageWidth - 40, recommandations.length * 10 + 10, 'S');
    
    pdf.setTextColor(100, 116, 139);
    pdf.setFontSize(10);
    pdf.setFont('helvetica', 'normal');
    
    recommandations.forEach((rec, index) => {
      pdf.text(`${index + 1}. ${rec}`, 25, yPosition + 5);
      yPosition += 10;
    });

    yPosition += 10;

    // Pied de page
    pdf.setTextColor(100, 116, 139);
    pdf.setFontSize(8);
    pdf.setFont('helvetica', 'normal');
    const footerText = `© ${new Date().getFullYear()} ${cabinetConfig.nom} - ${cabinetConfig.expertComptable}`;
    pdf.text(footerText, pageWidth / 2, pageHeight - 15, { align: 'center' });

    // Télécharger le PDF
    const timestamp = new Date().toISOString().split('T')[0];
    pdf.save(`rapport-complet-${timestamp}.pdf`);
  }

  static downloadReport(content: string, filename: string, type: 'text' | 'html' | 'csv'): void {
    const mimeTypes = {
      text: 'text/plain',
      html: 'text/html',
      csv: 'text/csv'
    };

    const blob = new Blob([content], { type: mimeTypes[type] + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  }

  static openPrintableReport(htmlContent: string): void {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      // Attendre que le contenu soit chargé avant d'ouvrir la boîte de dialogue d'impression
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.focus();
        }, 500);
      };
    }
  }
}