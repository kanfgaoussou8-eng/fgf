import React, { useState } from 'react';
import { X, Building, User, Phone, Mail, MapPin, Calendar, FileText, Save, DollarSign } from 'lucide-react';
import type { Client } from '../../types';
import CurrencySelector from '../Currency/CurrencySelector';
import { type Currency } from '../../utils/currency';

interface NewClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Omit<Client, 'id'>) => void;
}

const secteursActivite = [
  'Agriculture et élevage',
  'Mines et carrières',
  'Industries manufacturières',
  'Électricité, gaz et eau',
  'Bâtiments et travaux publics',
  'Commerce général',
  'Commerce de gros',
  'Commerce de détail',
  'Hôtels et restaurants',
  'Transports et communications',
  'Activités financières',
  'Immobilier et services aux entreprises',
  'Administration publique',
  'Éducation',
  'Santé et action sociale',
  'Services collectifs et personnels',
  'Informatique et Services',
  'Import/Export',
  'Conseil et expertise',
  'Autres services'
];

const formesSociales = [
  'SARL (Société à Responsabilité Limitée)',
  'SA (Société Anonyme)',
  'SAS (Société par Actions Simplifiée)',
  'ETS (Établissement)',
  'GIE (Groupement d\'Intérêt Économique)',
  'SNC (Société en Nom Collectif)',
  'SCS (Société en Commandite Simple)',
  'SUARL (Société Unipersonnelle à Responsabilité Limitée)',
  'Entreprise individuelle',
  'Association',
  'Coopérative',
  'Autre'
];

export default function NewClientModal({ isOpen, onClose, onSave }: NewClientModalProps) {
  const [formData, setFormData] = useState({
    nom: '',
    raisonSociale: '',
    formeSociale: '',
    secteurActivite: '',
    numeroContribuable: '',
    numeroRCCM: '',
    adresse: '',
    ville: '',
    codePostal: '',
    pays: 'Côte d\'Ivoire',
    telephone: '',
    mobile: '',
    fax: '',
    email: '',
    siteWeb: '',
    dateCreation: '',
    dateDebutExercice: '',
    dateFinExercice: '',
    responsableComptable: '',
    directeurGeneral: '',
    contactPrincipal: '',
    regimeFiscal: 'Réel Normal',
    assujettTVA: true,
    tauxTVA: '18',
    observations: '',
    devise: 'XOF' as Currency,
    tauxChange: 1
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleCurrencyChange = (currency: Currency) => {
    setFormData(prev => ({
      ...prev,
      devise: currency,
      tauxChange: currency === 'XOF' ? 1 : undefined
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Champs obligatoires
    if (!formData.nom.trim()) newErrors.nom = 'Le nom est obligatoire';
    if (!formData.raisonSociale.trim()) newErrors.raisonSociale = 'La raison sociale est obligatoire';
    if (!formData.secteurActivite) newErrors.secteurActivite = 'Le secteur d\'activité est obligatoire';
    if (!formData.numeroContribuable.trim()) newErrors.numeroContribuable = 'Le numéro de contribuable est obligatoire';
    if (!formData.adresse.trim()) newErrors.adresse = 'L\'adresse est obligatoire';
    if (!formData.telephone.trim()) newErrors.telephone = 'Le téléphone est obligatoire';
    if (!formData.email.trim()) newErrors.email = 'L\'email est obligatoire';
    if (!formData.dateCreation) newErrors.dateCreation = 'La date de création est obligatoire';
    if (!formData.responsableComptable.trim()) newErrors.responsableComptable = 'Le responsable comptable est obligatoire';

    // Validation format email
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Format d\'email invalide';
    }

    // Validation numéro de contribuable (14 chiffres pour la Côte d'Ivoire)
    if (formData.numeroContribuable && !/^\d{14}$/.test(formData.numeroContribuable.replace(/\s/g, ''))) {
      newErrors.numeroContribuable = 'Le numéro de contribuable doit contenir 14 chiffres';
    }

    // Validation téléphone
    if (formData.telephone && !/^(\+225\s?)?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}$/.test(formData.telephone)) {
      newErrors.telephone = 'Format de téléphone invalide (ex: +225 27 20 12 34 56)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const newClient: Omit<Client, 'id'> = {
        nom: formData.nom.trim(),
        raisonSociale: formData.raisonSociale.trim(),
        secteurActivite: formData.secteurActivite,
        numeroContribuable: formData.numeroContribuable.replace(/\s/g, ''),
        adresse: `${formData.adresse.trim()}${formData.ville ? ', ' + formData.ville : ''}`,
        telephone: formData.telephone.trim(),
        email: formData.email.trim().toLowerCase(),
        dateCreation: new Date(formData.dateCreation),
        responsableComptable: formData.responsableComptable.trim(),
        statut: 'actif',
        devise: formData.devise,
        tauxChange: formData.tauxChange
      };

      onSave(newClient);
      onClose();
      
      // Reset form
      setFormData({
        nom: '',
        raisonSociale: '',
        formeSociale: '',
        secteurActivite: '',
        numeroContribuable: '',
        numeroRCCM: '',
        adresse: '',
        ville: '',
        codePostal: '',
        pays: 'Côte d\'Ivoire',
        telephone: '',
        mobile: '',
        fax: '',
        email: '',
        siteWeb: '',
        dateCreation: '',
        dateDebutExercice: '',
        dateFinExercice: '',
        responsableComptable: '',
        directeurGeneral: '',
        contactPrincipal: '',
        regimeFiscal: 'Réel Normal',
        assujettTVA: true,
        tauxTVA: '18',
        observations: '',
        devise: 'XOF',
        tauxChange: 1
      });
    } catch (error) {
      console.error('Erreur lors de la création du client:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Building className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouveau Client</h3>
                <p className="text-sm text-gray-600">Créer un nouveau dossier client</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Informations générales */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Building className="h-5 w-5 mr-2 text-blue-600" />
              Informations générales
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom commercial <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="nom"
                  value={formData.nom}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.nom ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: SARL TEKNO SERVICES"
                />
                {errors.nom && <p className="text-red-500 text-xs mt-1">{errors.nom}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Raison sociale <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="raisonSociale"
                  value={formData.raisonSociale}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.raisonSociale ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Raison sociale officielle"
                />
                {errors.raisonSociale && <p className="text-red-500 text-xs mt-1">{errors.raisonSociale}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Forme sociale
                </label>
                <select
                  name="formeSociale"
                  value={formData.formeSociale}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Sélectionner une forme sociale</option>
                  {formesSociales.map(forme => (
                    <option key={forme} value={forme}>{forme}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Secteur d'activité <span className="text-red-500">*</span>
                </label>
                <select
                  name="secteurActivite"
                  value={formData.secteurActivite}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.secteurActivite ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un secteur</option>
                  {secteursActivite.map(secteur => (
                    <option key={secteur} value={secteur}>{secteur}</option>
                  ))}
                </select>
                {errors.secteurActivite && <p className="text-red-500 text-xs mt-1">{errors.secteurActivite}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro de contribuable <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="numeroContribuable"
                  value={formData.numeroContribuable}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.numeroContribuable ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="14 chiffres"
                  maxLength={17}
                />
                {errors.numeroContribuable && <p className="text-red-500 text-xs mt-1">{errors.numeroContribuable}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Numéro RCCM
                </label>
                <input
                  type="text"
                  name="numeroRCCM"
                  value={formData.numeroRCCM}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Numéro RCCM"
                />
              </div>
            </div>
          </div>

          {/* Devise et paramètres financiers */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-green-600" />
              Devise et paramètres financiers
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <CurrencySelector
                selectedCurrency={formData.devise}
                onCurrencyChange={handleCurrencyChange}
              />
              
              {formData.devise !== 'XOF' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Taux de change personnalisé
                  </label>
                  <input
                    type="number"
                    name="tauxChange"
                    value={formData.tauxChange || ''}
                    onChange={handleInputChange}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Taux par rapport au XOF"
                    step="0.0001"
                    min="0"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Laissez vide pour utiliser le taux automatique
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Adresse */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-green-600" />
              Adresse
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Adresse <span className="text-red-500">*</span>
                </label>
                <textarea
                  name="adresse"
                  value={formData.adresse}
                  onChange={handleInputChange}
                  rows={3}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.adresse ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Adresse complète"
                />
                {errors.adresse && <p className="text-red-500 text-xs mt-1">{errors.adresse}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ville
                </label>
                <input
                  type="text"
                  name="ville"
                  value={formData.ville}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ville"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pays
                </label>
                <input
                  type="text"
                  name="pays"
                  value={formData.pays}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Phone className="h-5 w-5 mr-2 text-purple-600" />
              Informations de contact
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Téléphone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="telephone"
                  value={formData.telephone}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.telephone ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="+225 27 20 12 34 56"
                />
                {errors.telephone && <p className="text-red-500 text-xs mt-1">{errors.telephone}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mobile
                </label>
                <input
                  type="tel"
                  name="mobile"
                  value={formData.mobile}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="+225 07 12 34 56 78"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.email ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="contact@entreprise.ci"
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Site web
                </label>
                <input
                  type="url"
                  name="siteWeb"
                  value={formData.siteWeb}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="https://www.entreprise.ci"
                />
              </div>
            </div>
          </div>

          {/* Informations comptables */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-orange-600" />
              Informations comptables
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date de création <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="dateCreation"
                  value={formData.dateCreation}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.dateCreation ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.dateCreation && <p className="text-red-500 text-xs mt-1">{errors.dateCreation}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Régime fiscal
                </label>
                <select
                  name="regimeFiscal"
                  value={formData.regimeFiscal}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Réel Normal">Réel Normal</option>
                  <option value="Réel Simplifié">Réel Simplifié</option>
                  <option value="Synthèse">Synthèse</option>
                  <option value="Micro-entreprise">Micro-entreprise</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Début d'exercice
                </label>
                <input
                  type="date"
                  name="dateDebutExercice"
                  value={formData.dateDebutExercice}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fin d'exercice
                </label>
                <input
                  type="date"
                  name="dateFinExercice"
                  value={formData.dateFinExercice}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  name="assujettTVA"
                  checked={formData.assujettTVA}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="text-sm font-medium text-gray-700">
                  Assujetti à la TVA
                </label>
              </div>

              {formData.assujettTVA && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Taux de TVA (%)
                  </label>
                  <select
                    name="tauxTVA"
                    value={formData.tauxTVA}
                    onChange={handleInputChange}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="18">18% (Taux normal)</option>
                    <option value="9">9% (Taux réduit)</option>
                    <option value="0">0% (Exonéré)</option>
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Responsables */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <User className="h-5 w-5 mr-2 text-indigo-600" />
              Responsables
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Responsable comptable <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="responsableComptable"
                  value={formData.responsableComptable}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.responsableComptable ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Nom du responsable comptable"
                />
                {errors.responsableComptable && <p className="text-red-500 text-xs mt-1">{errors.responsableComptable}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Directeur général
                </label>
                <input
                  type="text"
                  name="directeurGeneral"
                  value={formData.directeurGeneral}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Nom du directeur général"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Contact principal
                </label>
                <input
                  type="text"
                  name="contactPrincipal"
                  value={formData.contactPrincipal}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Nom du contact principal"
                />
              </div>
            </div>
          </div>

          {/* Observations */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-gray-600" />
              Observations
            </h4>
            <textarea
              name="observations"
              value={formData.observations}
              onChange={handleInputChange}
              rows={4}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Notes et observations particulières..."
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Création...' : 'Créer le client'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}