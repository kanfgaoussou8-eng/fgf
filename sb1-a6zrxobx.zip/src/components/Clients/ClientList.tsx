import React, { useState } from 'react';
import { Plus, Search, Filter, MoreVertical, CreditCard as Edit, FileText, Phone, Mail, Building, Calendar, DollarSign } from 'lucide-react';
import type { Client } from '../../types';
import NewClientModal from './NewClientModal';
import { CurrencyFormatter, CURRENCIES } from '../../utils/currency';

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif',
    devise: 'XOF',
    tauxChange: 1
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif',
    devise: 'USD',
    tauxChange: 0.0016
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif',
    devise: 'EUR',
    tauxChange: 0.0015
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'inactif',
    devise: 'CDF',
    tauxChange: 1.35
  }
];

export default function ClientList() {
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('tous');
  const [filterCurrency, setFilterCurrency] = useState<string>('tous');
  const [isNewClientModalOpen, setIsNewClientModalOpen] = useState(false);

  const filteredClients = clients.filter(client => {
    const matchesSearch = client.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         client.secteurActivite.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'tous' || client.statut === filterStatus;
    const matchesCurrency = filterCurrency === 'tous' || client.devise === filterCurrency;
    return matchesSearch && matchesFilter && matchesCurrency;
  });

  const getStatusBadge = (statut: Client['statut']) => {
    switch (statut) {
      case 'actif':
        return 'bg-green-100 text-green-800';
      case 'inactif':
        return 'bg-gray-100 text-gray-800';
      case 'suspendu':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getCurrencyBadge = (devise: string) => {
    const currencyInfo = CURRENCIES[devise as keyof typeof CURRENCIES];
    return {
      class: 'bg-blue-100 text-blue-800',
      display: `${currencyInfo.flag} ${currencyInfo.symbol}`
    };
  };

  const handleSaveNewClient = (newClientData: Omit<Client, 'id'>) => {
    const newClient: Client = {
      ...newClientData,
      id: (clients.length + 1).toString()
    };
    setClients(prev => [...prev, newClient]);
  };

  return (
    <div className="space-y-6">
      {/* Header and Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gestion des clients</h3>
          <p className="text-sm text-gray-600 mt-1">
            Gérez vos clients et leurs dossiers comptables
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsNewClientModalOpen(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Plus className="h-4 w-4" />
            <span>Nouveau client</span>
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par nom ou secteur..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les statuts</option>
              <option value="actif">Actifs</option>
              <option value="inactif">Inactifs</option>
              <option value="suspendu">Suspendus</option>
            </select>
            <select
              value={filterCurrency}
              onChange={(e) => setFilterCurrency(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Toutes devises</option>
              {Object.values(CURRENCIES).map(currency => (
                <option key={currency.code} value={currency.code}>
                  {currency.flag} {currency.symbol} - {currency.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Client Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClients.map((client) => (
          <div
            key={client.id}
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Building className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 truncate">{client.nom}</h4>
                  <p className="text-sm text-gray-600">{client.secteurActivite}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(client.statut)}`}>
                  {client.statut}
                </span>
                <button className="p-1 text-gray-400 hover:text-gray-600">
                  <MoreVertical className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <Phone className="h-4 w-4 mr-2" />
                <span>{client.telephone}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Mail className="h-4 w-4 mr-2" />
                <span className="truncate">{client.email}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Client depuis {client.dateCreation.getFullYear()}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <DollarSign className="h-4 w-4 mr-2" />
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getCurrencyBadge(client.devise).class}`}>
                  {getCurrencyBadge(client.devise).display}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-4 border-t border-gray-100">
              <button className="flex-1 bg-blue-50 text-blue-600 py-2 px-3 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center space-x-2 text-sm">
                <FileText className="h-4 w-4" />
                <span>Dossier</span>
              </button>
              <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-3 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2 text-sm">
                <Edit className="h-4 w-4" />
                <span>Modifier</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* New Client Modal */}
      <NewClientModal
        isOpen={isNewClientModalOpen}
        onClose={() => setIsNewClientModalOpen(false)}
        onSave={handleSaveNewClient}
      />

      {filteredClients.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun client trouvé</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Commencez par ajouter votre premier client'}
          </p>
        </div>
      )}
    </div>
  );
}