import React, { useState } from 'react';
import { useClientData } from '../../hooks/useClientData';
import ClientSelector from '../ClientSelector/ClientSelector';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  FileText, 
  Building, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  Database
} from 'lucide-react';
import type { Client } from '../../types';

interface ClientDashboardProps {
  clients: Client[];
}

export default function ClientDashboard({ clients }: ClientDashboardProps) {
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const {
    loading,
    error,
    comptes,
    ecritures,
    immobilisations,
    factures,
    declarations,
    mouvementsTresorerie,
    getStatistics
  } = useClientData(selectedClientId || '');

  const selectedClient = clients.find(c => c.id === selectedClientId);
  const stats = getStatistics();

  const formatMontant = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(montant);
  };

  const getDeclarationsUrgentes = () => {
    const today = new Date();
    const dans7Jours = new Date();
    dans7Jours.setDate(today.getDate() + 7);
    
    return declarations.filter(decl => 
      decl.dateEcheance <= dans7Jours && 
      decl.statut !== 'deposee'
    );
  };

  const getFacturesImpayees = () => {
    return factures.filter(f => f.statut === 'envoyee' || f.statut === 'impayee');
  };

  if (!selectedClientId) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Database className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">Sélectionnez un Client</h3>
          <p className="text-gray-600 mb-6">
            Choisissez un client pour accéder à ses données comptables
          </p>
          <div className="max-w-md mx-auto">
            <ClientSelector
              clients={clients}
              selectedClientId={selectedClientId}
              onClientSelect={setSelectedClientId}
              showDatabaseStatus={true}
            />
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="max-w-md">
            <ClientSelector
              clients={clients}
              selectedClientId={selectedClientId}
              onClientSelect={setSelectedClientId}
              showDatabaseStatus={true}
            />
          </div>
        </div>
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-gray-600">Chargement des données de {selectedClient?.nom}...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <div className="max-w-md">
          <ClientSelector
            clients={clients}
            selectedClientId={selectedClientId}
            onClientSelect={setSelectedClientId}
            showDatabaseStatus={true}
          />
        </div>
        <div className="text-center py-12 bg-red-50 rounded-lg border border-red-200">
          <AlertTriangle className="h-12 w-12 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-red-900 mb-2">Erreur de chargement</h3>
          <p className="text-red-700">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Client Selector */}
      <div className="flex items-center justify-between">
        <div className="max-w-md">
          <ClientSelector
            clients={clients}
            selectedClientId={selectedClientId}
            onClientSelect={setSelectedClientId}
            showDatabaseStatus={true}
          />
        </div>
        <div className="text-sm text-gray-500">
          Base de données: <span className="font-mono">client_{selectedClientId}</span>
        </div>
      </div>

      {/* Client Info Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-center space-x-4">
          <div className="h-12 w-12 rounded-full bg-blue-500 flex items-center justify-center text-white text-lg font-bold">
            {selectedClient && getClientInitials(selectedClient.nom)}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{selectedClient?.nom}</h3>
            <p className="text-sm text-gray-600">{selectedClient?.secteurActivite}</p>
            <p className="text-xs text-gray-500">
              Client depuis {selectedClient?.dateCreation.getFullYear()} • 
              Responsable: {selectedClient?.responsableComptable}
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2 mb-2">
              <Database className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-600 font-medium">Base dédiée active</span>
            </div>
            <div className="text-xs text-gray-500">
              Dernière sync: {new Date().toLocaleTimeString('fr-FR')}
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Comptes comptables</p>
              <p className="text-2xl font-bold text-gray-900">{stats.nombreComptes}</p>
              <p className="text-sm text-blue-600 mt-1">Plan comptable</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Écritures comptables</p>
              <p className="text-2xl font-bold text-gray-900">{stats.nombreEcritures}</p>
              <p className="text-sm text-green-600 mt-1">Saisies validées</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <BarChart3 className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Immobilisations</p>
              <p className="text-2xl font-bold text-gray-900">{formatMontant(stats.totalImmobilisations)}</p>
              <p className="text-sm text-purple-600 mt-1">Valeur nette</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <Building className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Solde trésorerie</p>
              <p className={`text-2xl font-bold ${stats.soldeTresorerie >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatMontant(stats.soldeTresorerie)}
              </p>
              <p className="text-sm text-orange-600 mt-1">Position nette</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg">
              <DollarSign className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Alerts and Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Déclarations urgentes */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-semibold text-gray-900 flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2 text-orange-600" />
              Déclarations urgentes
            </h4>
            <span className="text-sm text-gray-500">{getDeclarationsUrgentes().length} à traiter</span>
          </div>
          
          {getDeclarationsUrgentes().length > 0 ? (
            <div className="space-y-3">
              {getDeclarationsUrgentes().slice(0, 3).map((declaration) => (
                <div key={declaration.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">{declaration.type.toUpperCase()}</div>
                    <div className="text-sm text-gray-600">{declaration.periode}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-orange-600">
                      {declaration.dateEcheance.toLocaleDateString('fr-FR')}
                    </div>
                    <div className="text-xs text-gray-500">
                      {Math.ceil((declaration.dateEcheance.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} jours
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">
              <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <p className="text-sm">Aucune déclaration urgente</p>
            </div>
          )}
        </div>

        {/* Factures en attente */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-semibold text-gray-900 flex items-center">
              <Clock className="h-5 w-5 mr-2 text-blue-600" />
              Factures en attente
            </h4>
            <span className="text-sm text-gray-500">{getFacturesImpayees().length} impayées</span>
          </div>
          
          {getFacturesImpayees().length > 0 ? (
            <div className="space-y-3">
              {getFacturesImpayees().slice(0, 3).map((facture) => (
                <div key={facture.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">{facture.numeroFacture}</div>
                    <div className="text-sm text-gray-600">
                      Émise le {facture.dateEmission.toLocaleDateString('fr-FR')}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-blue-600">
                      {formatMontant(facture.montantTTC)}
                    </div>
                    <div className="text-xs text-gray-500">
                      Échéance: {facture.dateEcheance.toLocaleDateString('fr-FR')}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">
              <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <p className="text-sm">Toutes les factures sont payées</p>
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Calendar className="h-5 w-5 mr-2 text-purple-600" />
          Activité récente
        </h4>
        
        <div className="space-y-4">
          {/* Dernières écritures */}
          {ecritures.slice(0, 3).map((ecriture) => (
            <div key={ecriture.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="p-2 bg-green-50 rounded-lg">
                <FileText className="h-4 w-4 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">Écriture {ecriture.numeroJournal}</div>
                <div className="text-sm text-gray-600">{ecriture.libelle}</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-900">
                  {ecriture.dateEcriture.toLocaleDateString('fr-FR')}
                </div>
                <div className={`text-xs px-2 py-1 rounded-full ${
                  ecriture.statut === 'validee' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {ecriture.statut}
                </div>
              </div>
            </div>
          ))}

          {/* Derniers mouvements de trésorerie */}
          {mouvementsTresorerie.slice(0, 2).map((mouvement) => (
            <div key={mouvement.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className={`p-2 rounded-lg ${
                mouvement.type === 'recette' ? 'bg-green-50' : 'bg-red-50'
              }`}>
                <DollarSign className={`h-4 w-4 ${
                  mouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'
                }`} />
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">{mouvement.libelle}</div>
                <div className="text-sm text-gray-600">{mouvement.tiers}</div>
              </div>
              <div className="text-right">
                <div className={`text-sm font-medium ${
                  mouvement.type === 'recette' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {mouvement.type === 'recette' ? '+' : '-'}{formatMontant(mouvement.montant)}
                </div>
                <div className="text-xs text-gray-500">
                  {mouvement.date.toLocaleDateString('fr-FR')}
                </div>
              </div>
            </div>
          ))}
        </div>

        {ecritures.length === 0 && mouvementsTresorerie.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Calendar className="h-8 w-8 mx-auto mb-2 text-gray-300" />
            <p className="text-sm">Aucune activité récente</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Actions rapides</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-center">
            <FileText className="h-6 w-6 mx-auto mb-2 text-blue-600" />
            <span className="text-sm font-medium text-gray-900">Nouvelle écriture</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-center">
            <DollarSign className="h-6 w-6 mx-auto mb-2 text-green-600" />
            <span className="text-sm font-medium text-gray-900">Nouvelle facture</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-center">
            <Building className="h-6 w-6 mx-auto mb-2 text-purple-600" />
            <span className="text-sm font-medium text-gray-900">Immobilisation</span>
          </button>
          <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-center">
            <Calendar className="h-6 w-6 mx-auto mb-2 text-orange-600" />
            <span className="text-sm font-medium text-gray-900">Déclaration</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function getClientInitials(nom: string): string {
  return nom.split(' ').map(word => word.charAt(0)).join('').substring(0, 2);
}