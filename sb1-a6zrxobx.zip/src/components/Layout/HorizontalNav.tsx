import React, { useState } from 'react';
import { 
  Home, 
  Users, 
  BookOpen, 
  PenTool, 
  Calculator, 
  DollarSign,
  Calendar,
  Settings,
  BarChart3,
  Building,
  Banknote,
  Menu,
  X,
  Bell,
  User,
  LogOut,
  HelpCircle,
  FileText,
  AlertTriangle,
  Clock,
  CheckCircle,
  Database
} from 'lucide-react';
import { CABINET_CONFIG } from '../Parametres/Parametres';
import { useAuth } from '../../contexts/AuthContext';

interface HorizontalNavProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const menuItems = [
  { 
    id: 'dashboard', 
    label: 'Tableau de bord', 
    icon: Home, 
    color: 'blue',
    description: 'Vue d\'ensemble et statistiques'
  },
  { 
    id: 'clients', 
    label: 'Clients', 
    icon: Users, 
    color: 'green',
    description: 'Gestion du portefeuille clients'
  },
  { 
    id: 'plan-comptable', 
    label: 'Plan comptable', 
    icon: BookOpen, 
    color: 'purple',
    description: 'Plan comptable OHADA'
  },
  { 
    id: 'ecritures', 
    label: 'Écritures', 
    icon: PenTool, 
    color: 'indigo',
    description: 'Saisie des écritures comptables'
  },
  { 
    id: 'immobilisations', 
    label: 'Immobilisations', 
    icon: Building, 
    color: 'orange',
    description: 'Gestion du patrimoine'
  },
  { 
    id: 'tresorerie', 
    label: 'Trésorerie', 
    icon: Banknote, 
    color: 'emerald',
    description: 'Flux de trésorerie'
  },
  { 
    id: 'facturation', 
    label: 'Facturation', 
    icon: DollarSign, 
    color: 'yellow',
    description: 'Facturation et honoraires'
  },
  { 
    id: 'declarations', 
    label: 'Déclarations', 
    icon: Calendar, 
    color: 'red',
    description: 'Obligations fiscales'
  },
  { 
    id: 'reporting', 
    label: 'Reporting', 
    icon: BarChart3, 
    color: 'pink',
    description: 'Analyses et rapports'
  },
  { 
    id: 'parametres', 
    label: 'Paramètres', 
    icon: Settings, 
    color: 'gray',
    description: 'Configuration du cabinet'
  },
  { 
    id: 'installation', 
    label: 'Installations', 
    icon: Database, 
    color: 'indigo',
    description: 'Gestion multi-cabinets'
  },
  { 
    id: 'setup', 
    label: 'Nouveau Cabinet', 
    icon: Building, 
    color: 'emerald',
    description: 'Installation nouveau cabinet'
  }
];

const colorClasses = {
  blue: {
    active: 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-200',
    hover: 'hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300 hover:shadow-md',
    icon: 'text-blue-600',
    gradient: 'from-blue-500 to-blue-600'
  },
  green: {
    active: 'bg-green-600 text-white border-green-600 shadow-lg shadow-green-200',
    hover: 'hover:bg-green-50 hover:text-green-700 hover:border-green-300 hover:shadow-md',
    icon: 'text-green-600',
    gradient: 'from-green-500 to-green-600'
  },
  purple: {
    active: 'bg-purple-600 text-white border-purple-600 shadow-lg shadow-purple-200',
    hover: 'hover:bg-purple-50 hover:text-purple-700 hover:border-purple-300 hover:shadow-md',
    icon: 'text-purple-600',
    gradient: 'from-purple-500 to-purple-600'
  },
  indigo: {
    active: 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-200',
    hover: 'hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-300 hover:shadow-md',
    icon: 'text-indigo-600',
    gradient: 'from-indigo-500 to-indigo-600'
  },
  orange: {
    active: 'bg-orange-600 text-white border-orange-600 shadow-lg shadow-orange-200',
    hover: 'hover:bg-orange-50 hover:text-orange-700 hover:border-orange-300 hover:shadow-md',
    icon: 'text-orange-600',
    gradient: 'from-orange-500 to-orange-600'
  },
  emerald: {
    active: 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-200',
    hover: 'hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 hover:shadow-md',
    icon: 'text-emerald-600',
    gradient: 'from-emerald-500 to-emerald-600'
  },
  yellow: {
    active: 'bg-yellow-600 text-white border-yellow-600 shadow-lg shadow-yellow-200',
    hover: 'hover:bg-yellow-50 hover:text-yellow-700 hover:border-yellow-300 hover:shadow-md',
    icon: 'text-yellow-600',
    gradient: 'from-yellow-500 to-yellow-600'
  },
  red: {
    active: 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-200',
    hover: 'hover:bg-red-50 hover:text-red-700 hover:border-red-300 hover:shadow-md',
    icon: 'text-red-600',
    gradient: 'from-red-500 to-red-600'
  },
  pink: {
    active: 'bg-pink-600 text-white border-pink-600 shadow-lg shadow-pink-200',
    hover: 'hover:bg-pink-50 hover:text-pink-700 hover:border-pink-300 hover:shadow-md',
    icon: 'text-pink-600',
    gradient: 'from-pink-500 to-pink-600'
  },
  gray: {
    active: 'bg-gray-600 text-white border-gray-600 shadow-lg shadow-gray-200',
    hover: 'hover:bg-gray-50 hover:text-gray-700 hover:border-gray-300 hover:shadow-md',
    icon: 'text-gray-600',
    gradient: 'from-gray-500 to-gray-600'
  }
};

export default function HorizontalNav({ activeSection, onSectionChange }: HorizontalNavProps) {
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const notifications = [
    { id: 1, type: 'urgent', message: 'Déclaration TVA en retard - ETS MAMADOU', time: 'Il y a 2h', color: 'red' },
    { id: 2, type: 'warning', message: 'Échéance facture dans 2 jours - SARL TEKNO', time: 'Il y a 4h', color: 'orange' },
    { id: 3, type: 'info', message: 'Nouvelle facture créée - AFRICAN TRADE', time: 'Il y a 6h', color: 'blue' },
    { id: 4, type: 'success', message: 'Paiement reçu - GIE TRANSPORT', time: 'Il y a 1j', color: 'green' },
    { id: 5, type: 'info', message: 'Nouveau client ajouté au portefeuille', time: 'Il y a 2j', color: 'purple' },
    { id: 6, type: 'warning', message: 'Sauvegarde programmée dans 1h', time: 'Il y a 3j', color: 'orange' },
    { id: 7, type: 'info', message: 'Mise à jour système disponible', time: 'Il y a 5j', color: 'blue' }
  ];

  return (
    <>
      {/* Navigation principale */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo et titre */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg shadow-lg">
                  <Calculator className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
                    CACCompta V3.25
                  </h1>
                  <p className="text-xs text-gray-500 font-medium">Logiciel de Gestion Comptable</p>
                </div>
              </div>
            </div>

            {/* Menu horizontal - Desktop */}
            <div className="hidden xl:flex items-center space-x-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                const colors = colorClasses[item.color as keyof typeof colorClasses];
                
                return (
                  <div key={item.id} className="relative group">
                    <button
                      onClick={() => onSectionChange(item.id)}
                      className={`
                        relative flex items-center space-x-2 px-4 py-3 rounded-xl text-sm font-medium
                        border-2 transition-all duration-300 transform hover:scale-105
                        ${isActive 
                          ? colors.active 
                          : 'border-transparent text-gray-600 ' + colors.hover
                        }
                      `}
                    >
                      <Icon className={`h-5 w-5 ${isActive ? 'text-white' : colors.icon}`} />
                      <span className="hidden lg:block">{item.label}</span>
                      
                      {/* Indicateur actif */}
                      {isActive && (
                        <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-white rounded-full shadow-sm"></div>
                      )}
                    </button>
                    
                    {/* Tooltip pour les écrans XL */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50 2xl:hidden">
                      <div className="text-center">
                        <div className="font-medium">{item.label}</div>
                        <div className="text-gray-300 text-xs">{item.description}</div>
                      </div>
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-gray-900 rotate-45"></div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Profil utilisateur et actions - Desktop */}
            <div className="hidden lg:flex items-center space-x-4">
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-3 px-4 py-2 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div className="h-9 w-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                    {user ? `${user.prenom[0]}${user.nom[0]}` : 'U'}
                  </div>
                  <div className="hidden xl:block">
                    <p className="text-sm font-semibold text-gray-900">{user ? `${user.prenom} ${user.nom}` : 'Utilisateur'}</p>
                    <p className="text-xs text-gray-500">{user ? roleLabels[user.role] : 'Utilisateur'}</p>
                  </div>
                </button>

                {/* User Dropdown Menu */}
                {isUserMenuOpen && (
                  <div className="absolute top-full right-0 mt-2 w-64 bg-white border border-gray-200 rounded-xl shadow-lg z-50">
                    <div className="p-4 border-b border-gray-200">
                      <div className="flex items-center space-x-3">
                        <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-lg font-bold">
                          {user ? `${user.prenom[0]}${user.nom[0]}` : 'U'}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900">{user ? `${user.prenom} ${user.nom}` : 'Utilisateur'}</p>
                          <p className="text-xs text-gray-500">{user ? roleLabels[user.role] : 'Utilisateur'}</p>
                          <p className="text-xs text-blue-600 font-medium">{user?.cabinet || CABINET_CONFIG.nom}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-2">
                      <button className="w-full flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
                        <User className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">Mon profil</span>
                      </button>
                      
                      <div className="border-t border-gray-200 my-2"></div>
                      
                      <button 
                        onClick={() => {
                          logout();
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full flex items-center space-x-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <LogOut className="h-4 w-4" />
                        <span className="text-sm font-medium">Se déconnecter</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Menu hamburger - Mobile */}
            <div className="xl:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Notifications Modal */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <Bell className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
                    <p className="text-sm text-gray-600">{notifications.length} notifications</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div key={notification.id} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className={`p-2 rounded-lg ${
                      notification.color === 'red' ? 'bg-red-50' :
                      notification.color === 'orange' ? 'bg-orange-50' :
                      notification.color === 'green' ? 'bg-green-50' :
                      notification.color === 'blue' ? 'bg-blue-50' :
                      'bg-purple-50'
                    }`}>
                      {notification.type === 'urgent' ? (
                        <AlertTriangle className={`h-4 w-4 ${
                          notification.color === 'red' ? 'text-red-600' :
                          notification.color === 'orange' ? 'text-orange-600' :
                          notification.color === 'green' ? 'text-green-600' :
                          notification.color === 'blue' ? 'text-blue-600' :
                          'text-purple-600'
                        }`} />
                      ) : notification.type === 'warning' ? (
                        <Clock className={`h-4 w-4 ${
                          notification.color === 'red' ? 'text-red-600' :
                          notification.color === 'orange' ? 'text-orange-600' :
                          notification.color === 'green' ? 'text-green-600' :
                          notification.color === 'blue' ? 'text-blue-600' :
                          'text-purple-600'
                        }`} />
                      ) : notification.type === 'success' ? (
                        <CheckCircle className={`h-4 w-4 ${
                          notification.color === 'red' ? 'text-red-600' :
                          notification.color === 'orange' ? 'text-orange-600' :
                          notification.color === 'green' ? 'text-green-600' :
                          notification.color === 'blue' ? 'text-blue-600' :
                          'text-purple-600'
                        }`} />
                      ) : (
                        <FileText className={`h-4 w-4 ${
                          notification.color === 'red' ? 'text-red-600' :
                          notification.color === 'orange' ? 'text-orange-600' :
                          notification.color === 'green' ? 'text-green-600' :
                          notification.color === 'blue' ? 'text-blue-600' :
                          'text-purple-600'
                        }`} />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{notification.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                    </div>
                    <button className="text-gray-400 hover:text-gray-600">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 pt-4 border-t border-gray-200 flex justify-between">
                <button className="text-sm text-gray-600 hover:text-gray-800">
                  Marquer tout comme lu
                </button>
                <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                  Voir toutes les notifications
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Overlay pour fermer le menu utilisateur */}
      {isUserMenuOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsUserMenuOpen(false)}
        ></div>
      )}

      {/* Menu mobile overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 xl:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsMobileMenuOpen(false)}></div>
          
          <div className="fixed top-0 right-0 h-full w-80 bg-white shadow-xl transform transition-transform duration-300">
            <div className="p-6">
              {/* Header mobile menu */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg">
                    <Calculator className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-gray-900">ComptaOHADA</h2>
                    <p className="text-xs text-gray-500">Menu principal</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Profil utilisateur mobile */}
              <div className="mb-8 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                <div className="flex items-center space-x-3">
                  <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-lg font-bold">
                    {user ? `${user.prenom[0]}${user.nom[0]}` : 'U'}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{user ? `${user.prenom} ${user.nom}` : 'Utilisateur'}</p>
                    <p className="text-xs text-gray-600">{user ? roleLabels[user.role] : 'Utilisateur'}</p>
                    <p className="text-xs text-blue-600 font-medium">{user?.cabinet || CABINET_CONFIG.nom}</p>
                  </div>
                </div>
              </div>

              {/* Menu items mobile */}
              <div className="space-y-2 mb-8">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeSection === item.id;
                  const colors = colorClasses[item.color as keyof typeof colorClasses];
                  
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSectionChange(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`
                        w-full flex items-center space-x-4 px-4 py-4 rounded-xl text-left
                        transition-all duration-200 group
                        ${isActive 
                          ? colors.active 
                          : 'text-gray-700 hover:bg-gray-50 hover:shadow-sm'
                        }
                      `}
                    >
                      <div className={`p-2 rounded-lg ${
                        isActive 
                          ? 'bg-white bg-opacity-20' 
                          : 'bg-gray-100 group-hover:bg-gray-200'
                      }`}>
                        <Icon className={`h-5 w-5 ${
                          isActive ? 'text-white' : colors.icon
                        }`} />
                      </div>
                      <div className="flex-1">
                        <div className={`font-semibold ${isActive ? 'text-white' : 'text-gray-900'}`}>
                          {item.label}
                        </div>
                        <div className={`text-xs ${isActive ? 'text-white text-opacity-80' : 'text-gray-500'}`}>
                          {item.description}
                        </div>
                      </div>
                      {isActive && (
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Actions utilisateur mobile */}
              <div className="space-y-2 pt-6 border-t border-gray-200">
                <button className="w-full flex items-center space-x-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-xl transition-colors" onClick={logout}>
                  <LogOut className="h-5 w-5" />
                  <span className="font-medium">Déconnexion</span>
                </button>
              </div>

              {/* Footer mobile */}
              <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                <p className="text-xs text-gray-400">Version 1.0.0</p>
                <p className="text-xs text-gray-400 mt-1">© 2024 ComptaOHADA</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Barre de navigation secondaire pour les raccourcis */}
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200 py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2 text-gray-600">
                <Calendar className="h-4 w-4" />
                <span className="font-medium">
                  {new Date().toLocaleDateString('fr-FR', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </span>
              </div>
              <div className="hidden md:flex items-center space-x-2 text-gray-600">
                <Users className="h-4 w-4" />
                <span>Clients actifs: 48</span>
              </div>
              <div className="hidden lg:flex items-center space-x-2 text-gray-600">
                <FileText className="h-4 w-4" />
                <span>Déclarations: 7 en attente</span>
              </div>
              <button 
                onClick={() => setShowNotifications(true)}
                className="hidden lg:flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors relative"
              >
                <Bell className="h-4 w-4" />
                <span>Notifications</span>
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center font-bold">
                  {notifications.length}
                </span>
              </button>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-gray-600">Système opérationnel</span>
              </div>
              <div className="text-xs text-gray-500">
                {new Date().toLocaleTimeString('fr-FR', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

const roleLabels = {
  'expert-comptable': 'Expert-Comptable',
  'assistant': 'Assistant Comptable', 
  'stagiaire': 'Stagiaire',
  'admin': 'Administrateur'
};