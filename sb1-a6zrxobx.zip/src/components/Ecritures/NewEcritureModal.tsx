import React, { useState } from 'react';
import { X, Plus, Trash2, Calculator, Save, AlertCircle } from 'lucide-react';
import type { EcritureComptable, LigneEcriture, Client, CompteComptable } from '../../types';

interface NewEcritureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (ecriture: Omit<EcritureComptable, 'id'>) => void;
}

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  }
];

const comptesComptables: CompteComptable[] = [
  // Classe 1 - Ressources durables
  { numero: '101', intitule: 'Capital social', classe: 1, type: 'credit', solde: 0 },
  { numero: '106', intitule: 'Réserves', classe: 1, type: 'credit', solde: 0 },
  { numero: '16', intitule: 'Emprunts et dettes assimilées', classe: 1, type: 'credit', solde: 0 },
  
  // Classe 2 - Actif immobilisé
  { numero: '22', intitule: 'Terrains', classe: 2, type: 'debit', solde: 0 },
  { numero: '23', intitule: 'Bâtiments', classe: 2, type: 'debit', solde: 0 },
  { numero: '24', intitule: 'Matériel', classe: 2, type: 'debit', solde: 0 },
  { numero: '245', intitule: 'Matériel de transport', classe: 2, type: 'debit', solde: 0 },
  
  // Classe 3 - Stocks
  { numero: '31', intitule: 'Matières premières', classe: 3, type: 'debit', solde: 0 },
  { numero: '35', intitule: 'Stocks de produits', classe: 3, type: 'debit', solde: 0 },
  { numero: '37', intitule: 'Stocks de marchandises', classe: 3, type: 'debit', solde: 0 },
  
  // Classe 4 - Tiers
  { numero: '401', intitule: 'Fournisseurs', classe: 4, type: 'credit', solde: 0 },
  { numero: '411', intitule: 'Clients', classe: 4, type: 'debit', solde: 0 },
  { numero: '421', intitule: 'Personnel - Avances', classe: 4, type: 'debit', solde: 0 },
  { numero: '422', intitule: 'Personnel - Rémunérations dues', classe: 4, type: 'credit', solde: 0 },
  { numero: '431', intitule: 'Sécurité Sociale', classe: 4, type: 'credit', solde: 0 },
  { numero: '441', intitule: 'État - Impôts sur bénéfices', classe: 4, type: 'credit', solde: 0 },
  { numero: '443', intitule: 'État - TVA facturée', classe: 4, type: 'credit', solde: 0 },
  { numero: '445', intitule: 'État - TVA récupérable', classe: 4, type: 'debit', solde: 0 },
  
  // Classe 5 - Trésorerie
  { numero: '52', intitule: 'Banques', classe: 5, type: 'debit', solde: 0 },
  { numero: '521', intitule: 'Banques locales', classe: 5, type: 'debit', solde: 0 },
  { numero: '57', intitule: 'Caisse', classe: 5, type: 'debit', solde: 0 },
  
  // Classe 6 - Charges
  { numero: '601', intitule: 'Achats de marchandises', classe: 6, type: 'debit', solde: 0 },
  { numero: '602', intitule: 'Achats de matières premières', classe: 6, type: 'debit', solde: 0 },
  { numero: '61', intitule: 'Transports', classe: 6, type: 'debit', solde: 0 },
  { numero: '62', intitule: 'Services extérieurs A', classe: 6, type: 'debit', solde: 0 },
  { numero: '63', intitule: 'Services extérieurs B', classe: 6, type: 'debit', solde: 0 },
  { numero: '64', intitule: 'Impôts et taxes', classe: 6, type: 'debit', solde: 0 },
  { numero: '66', intitule: 'Charges de personnel', classe: 6, type: 'debit', solde: 0 },
  { numero: '68', intitule: 'Dotations aux amortissements', classe: 6, type: 'debit', solde: 0 },
  
  // Classe 7 - Produits
  { numero: '701', intitule: 'Ventes de marchandises', classe: 7, type: 'credit', solde: 0 },
  { numero: '702', intitule: 'Ventes de produits finis', classe: 7, type: 'credit', solde: 0 },
  { numero: '706', intitule: 'Services vendus', classe: 7, type: 'credit', solde: 0 },
  { numero: '75', intitule: 'Autres produits', classe: 7, type: 'credit', solde: 0 },
  { numero: '77', intitule: 'Revenus financiers', classe: 7, type: 'credit', solde: 0 }
];

const journauxTypes = [
  { code: 'VT', libelle: 'Ventes' },
  { code: 'AC', libelle: 'Achats' },
  { code: 'BQ', libelle: 'Banque' },
  { code: 'CA', libelle: 'Caisse' },
  { code: 'OD', libelle: 'Opérations diverses' },
  { code: 'AN', libelle: 'À nouveau' },
  { code: 'EX', libelle: 'Extourne' }
];

export default function NewEcritureModal({ isOpen, onClose, onSave }: NewEcritureModalProps) {
  const [formData, setFormData] = useState({
    clientId: '',
    dateEcriture: new Date().toISOString().split('T')[0],
    numeroJournal: '',
    typeJournal: '',
    libelle: '',
    reference: '',
    pieceJustificative: ''
  });

  const [lignes, setLignes] = useState<Omit<LigneEcriture, 'id'>[]>([
    {
      compteNumero: '',
      compteIntitule: '',
      debit: 0,
      credit: 0,
      libelle: ''
    },
    {
      compteNumero: '',
      compteIntitule: '',
      debit: 0,
      credit: 0,
      libelle: ''
    }
  ]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Générer automatiquement le numéro de journal
    if (name === 'typeJournal' && value) {
      const nextNumber = String(Math.floor(Math.random() * 999) + 1).padStart(3, '0');
      setFormData(prev => ({ ...prev, numeroJournal: `${value}${nextNumber}` }));
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleLigneChange = (index: number, field: keyof Omit<LigneEcriture, 'id'>, value: string | number) => {
    const newLignes = [...lignes];
    
    if (field === 'compteNumero') {
      const compte = comptesComptables.find(c => c.numero === value);
      newLignes[index] = {
        ...newLignes[index],
        compteNumero: value as string,
        compteIntitule: compte ? compte.intitule : ''
      };
    } else {
      newLignes[index] = { ...newLignes[index], [field]: value };
    }
    
    setLignes(newLignes);
  };

  const addLigne = () => {
    setLignes(prev => [...prev, {
      compteNumero: '',
      compteIntitule: '',
      debit: 0,
      credit: 0,
      libelle: ''
    }]);
  };

  const removeLigne = (index: number) => {
    if (lignes.length > 2) {
      setLignes(prev => prev.filter((_, i) => i !== index));
    }
  };

  const getTotalDebit = () => {
    return lignes.reduce((sum, ligne) => sum + (ligne.debit || 0), 0);
  };

  const getTotalCredit = () => {
    return lignes.reduce((sum, ligne) => sum + (ligne.credit || 0), 0);
  };

  const isEquilibree = () => {
    const totalDebit = getTotalDebit();
    const totalCredit = getTotalCredit();
    return totalDebit === totalCredit && totalDebit > 0;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Validation des champs obligatoires
    if (!formData.clientId) newErrors.clientId = 'Le client est obligatoire';
    if (!formData.dateEcriture) newErrors.dateEcriture = 'La date est obligatoire';
    if (!formData.numeroJournal) newErrors.numeroJournal = 'Le numéro de journal est obligatoire';
    if (!formData.libelle.trim()) newErrors.libelle = 'Le libellé est obligatoire';

    // Validation des lignes
    const lignesValides = lignes.filter(ligne => 
      ligne.compteNumero && (ligne.debit > 0 || ligne.credit > 0)
    );

    if (lignesValides.length < 2) {
      newErrors.lignes = 'Au moins 2 lignes avec comptes et montants sont requises';
    }

    // Validation équilibre
    if (!isEquilibree()) {
      newErrors.equilibre = 'L\'écriture doit être équilibrée (Total Débit = Total Crédit)';
    }

    // Validation des lignes individuelles
    lignes.forEach((ligne, index) => {
      if (ligne.compteNumero && !ligne.libelle.trim()) {
        newErrors[`ligne_${index}_libelle`] = 'Le libellé de la ligne est obligatoire';
      }
      if (ligne.compteNumero && ligne.debit > 0 && ligne.credit > 0) {
        newErrors[`ligne_${index}_montant`] = 'Une ligne ne peut pas avoir débit ET crédit';
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const lignesValides = lignes
        .filter(ligne => ligne.compteNumero && (ligne.debit > 0 || ligne.credit > 0))
        .map((ligne, index) => ({
          id: `temp_${index}`,
          ...ligne
        }));

      const nouvelleEcriture: Omit<EcritureComptable, 'id'> = {
        clientId: formData.clientId,
        dateEcriture: new Date(formData.dateEcriture),
        numeroJournal: formData.numeroJournal,
        libelle: formData.libelle.trim(),
        reference: formData.reference.trim() || formData.numeroJournal,
        lignes: lignesValides,
        statut: 'brouillon',
        createdBy: 'Expert Comptable',
        createdAt: new Date()
      };

      onSave(nouvelleEcriture);
      onClose();
      
      // Reset form
      setFormData({
        clientId: '',
        dateEcriture: new Date().toISOString().split('T')[0],
        numeroJournal: '',
        typeJournal: '',
        libelle: '',
        reference: '',
        pieceJustificative: ''
      });
      setLignes([
        { compteNumero: '', compteIntitule: '', debit: 0, credit: 0, libelle: '' },
        { compteNumero: '', compteIntitule: '', debit: 0, credit: 0, libelle: '' }
      ]);
    } catch (error) {
      console.error('Erreur lors de la création de l\'écriture:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatMontant = (montant: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(montant);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-6xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Calculator className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouvelle Écriture Comptable</h3>
                <p className="text-sm text-gray-600">Saisie d'une nouvelle écriture au journal</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* En-tête de l'écriture */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-lg font-medium text-gray-900 mb-4">En-tête de l'écriture</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.clientId ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un client</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.nom}</option>
                  ))}
                </select>
                {errors.clientId && <p className="text-red-500 text-xs mt-1">{errors.clientId}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Date d'écriture <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="dateEcriture"
                  value={formData.dateEcriture}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.dateEcriture ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.dateEcriture && <p className="text-red-500 text-xs mt-1">{errors.dateEcriture}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de journal
                </label>
                <select
                  name="typeJournal"
                  value={formData.typeJournal}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Sélectionner un type</option>
                  {journauxTypes.map(journal => (
                    <option key={journal.code} value={journal.code}>
                      {journal.code} - {journal.libelle}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  N° Journal <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="numeroJournal"
                  value={formData.numeroJournal}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.numeroJournal ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Ex: VT001"
                />
                {errors.numeroJournal && <p className="text-red-500 text-xs mt-1">{errors.numeroJournal}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Référence
                </label>
                <input
                  type="text"
                  name="reference"
                  value={formData.reference}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ex: Facture F2024-001"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pièce justificative
                </label>
                <input
                  type="text"
                  name="pieceJustificative"
                  value={formData.pieceJustificative}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="N° de pièce"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Libellé de l'écriture <span className="text-red-500">*</span>
              </label>
              <textarea
                name="libelle"
                value={formData.libelle}
                onChange={handleInputChange}
                rows={2}
                className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.libelle ? 'border-red-300' : 'border-gray-300'
                }`}
                placeholder="Description de l'opération comptable"
              />
              {errors.libelle && <p className="text-red-500 text-xs mt-1">{errors.libelle}</p>}
            </div>
          </div>

          {/* Lignes d'écriture */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Lignes d'écriture</h4>
              <button
                type="button"
                onClick={addLigne}
                className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 text-sm"
              >
                <Plus className="h-4 w-4" />
                <span>Ajouter une ligne</span>
              </button>
            </div>

            {errors.lignes && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm">{errors.lignes}</p>
              </div>
            )}

            <div className="overflow-x-auto">
              <table className="w-full border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Compte
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Intitulé
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Libellé
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                      Débit
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                      Crédit
                    </th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {lignes.map((ligne, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <select
                          value={ligne.compteNumero}
                          onChange={(e) => handleLigneChange(index, 'compteNumero', e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        >
                          <option value="">Sélectionner</option>
                          {comptesComptables.map(compte => (
                            <option key={compte.numero} value={compte.numero}>
                              {compte.numero} - {compte.intitule}
                            </option>
                          ))}
                        </select>
                        {errors[`ligne_${index}_compte`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`ligne_${index}_compte`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="text"
                          value={ligne.compteIntitule}
                          readOnly
                          className="w-full bg-gray-50 border border-gray-200 rounded px-2 py-1 text-sm"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="text"
                          value={ligne.libelle}
                          onChange={(e) => handleLigneChange(index, 'libelle', e.target.value)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="Libellé de la ligne"
                        />
                        {errors[`ligne_${index}_libelle`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`ligne_${index}_libelle`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          value={ligne.debit || ''}
                          onChange={(e) => handleLigneChange(index, 'debit', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm text-right focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="0"
                          min="0"
                          step="1"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          value={ligne.credit || ''}
                          onChange={(e) => handleLigneChange(index, 'credit', parseFloat(e.target.value) || 0)}
                          className="w-full border border-gray-300 rounded px-2 py-1 text-sm text-right focus:outline-none focus:ring-1 focus:ring-blue-500"
                          placeholder="0"
                          min="0"
                          step="1"
                        />
                        {errors[`ligne_${index}_montant`] && (
                          <p className="text-red-500 text-xs mt-1">{errors[`ligne_${index}_montant`]}</p>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {lignes.length > 2 && (
                          <button
                            type="button"
                            onClick={() => removeLigne(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50">
                  <tr>
                    <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900">
                      Total
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-right">
                      {formatMontant(getTotalDebit())}
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-right">
                      {formatMontant(getTotalCredit())}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {isEquilibree() ? (
                        <div className="flex items-center justify-center text-green-600">
                          <Calculator className="h-4 w-4" />
                        </div>
                      ) : (
                        <div className="flex items-center justify-center text-red-600">
                          <AlertCircle className="h-4 w-4" />
                        </div>
                      )}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {errors.equilibre && (
              <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600 text-sm flex items-center">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  {errors.equilibre}
                </p>
              </div>
            )}
          </div>

          {/* Résumé */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="text-lg font-medium text-gray-900 mb-2">Résumé de l'écriture</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Total Débit:</span>
                <span className="ml-2 font-bold text-blue-600">{formatMontant(getTotalDebit())}</span>
              </div>
              <div>
                <span className="text-gray-600">Total Crédit:</span>
                <span className="ml-2 font-bold text-blue-600">{formatMontant(getTotalCredit())}</span>
              </div>
              <div>
                <span className="text-gray-600">Équilibre:</span>
                <span className={`ml-2 font-bold ${isEquilibree() ? 'text-green-600' : 'text-red-600'}`}>
                  {isEquilibree() ? 'Équilibrée' : 'Non équilibrée'}
                </span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !isEquilibree()}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Enregistrement...' : 'Enregistrer l\'écriture'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}