import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, CreditCard as Edit, Check, X } from 'lucide-react';
import type { EcritureComptable } from '../../types';
import NewEcritureModal from './NewEcritureModal';
import { useCurrency } from '../../contexts/CurrencyContext';

const mockEcritures: EcritureComptable[] = [
  {
    id: '1',
    clientId: '1',
    dateEcriture: new Date('2024-01-15'),
    numeroJournal: 'VT001',
    libelle: 'Vente de marchandises - Facture F2024-001',
    reference: 'F2024-001',
    statut: 'validee',
    createdBy: 'Expert Comptable',
    createdAt: new Date('2024-01-15'),
    lignes: [
      {
        id: '1-1',
        compteNumero: '411',
        compteIntitule: 'Clients',
        debit: 5900000,
        credit: 0,
        libelle: 'Client SARL TEKNO'
      },
      {
        id: '1-2',
        compteNumero: '701',
        compteIntitule: 'Ventes de marchandises',
        debit: 0,
        credit: 5000000,
        libelle: 'Vente marchandises'
      },
      {
        id: '1-3',
        compteNumero: '443',
        compteIntitule: 'État - TVA facturée',
        debit: 0,
        credit: 900000,
        libelle: 'TVA 18%'
      }
    ]
  },
  {
    id: '2',
    clientId: '2',
    dateEcriture: new Date('2024-01-20'),
    numeroJournal: 'AC002',
    libelle: 'Achat matières premières - Facture FRN-2024-045',
    reference: 'FRN-2024-045',
    statut: 'brouillon',
    createdBy: 'Assistant Comptable',
    createdAt: new Date('2024-01-20'),
    lignes: [
      {
        id: '2-1',
        compteNumero: '602',
        compteIntitule: 'Achats de matières premières',
        debit: 2500000,
        credit: 0,
        libelle: 'Achat matières premières'
      },
      {
        id: '2-2',
        compteNumero: '445',
        compteIntitule: 'État - TVA récupérable',
        debit: 450000,
        credit: 0,
        libelle: 'TVA récupérable 18%'
      },
      {
        id: '2-3',
        compteNumero: '401',
        compteIntitule: 'Fournisseurs',
        debit: 0,
        credit: 2950000,
        libelle: 'Fournisseur ABC SARL'
      }
    ]
  }
];

export default function EcritureList() {
  const { formatAmount } = useCurrency();
  const [ecritures, setEcritures] = useState<EcritureComptable[]>(mockEcritures);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('tous');
  const [selectedEcriture, setSelectedEcriture] = useState<EcritureComptable | null>(null);
  const [isNewEcritureModalOpen, setIsNewEcritureModalOpen] = useState(false);

  const filteredEcritures = ecritures.filter(ecriture => {
    const matchesSearch = ecriture.numeroJournal.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ecriture.libelle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ecriture.reference.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'tous' || ecriture.statut === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (statut: EcritureComptable['statut']) => {
    switch (statut) {
      case 'brouillon':
        return 'bg-yellow-100 text-yellow-800';
      case 'validee':
        return 'bg-green-100 text-green-800';
      case 'cloturee':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTotalDebit = (lignes: any[]) => {
    return lignes.reduce((sum, ligne) => sum + ligne.debit, 0);
  };

  const getTotalCredit = (lignes: any[]) => {
    return lignes.reduce((sum, ligne) => sum + ligne.credit, 0);
  };

  const handleSaveNewEcriture = (newEcritureData: Omit<EcritureComptable, 'id'>) => {
    const newEcriture: EcritureComptable = {
      ...newEcritureData,
      id: (ecritures.length + 1).toString()
    };
    setEcritures(prev => [...prev, newEcriture]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Écritures comptables</h3>
          <p className="text-sm text-gray-600 mt-1">
            Gestion des écritures et journaux comptables
          </p>
        </div>
        <button
          onClick={() => setIsNewEcritureModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouvelle écriture</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro, libellé ou référence..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les statuts</option>
              <option value="brouillon">Brouillon</option>
              <option value="validee">Validées</option>
              <option value="cloturee">Clôturées</option>
            </select>
          </div>
        </div>
      </div>

      {/* Écritures Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Journal
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Libellé
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Référence
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Débit
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Crédit
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredEcritures.map((ecriture) => (
                <tr key={ecriture.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {ecriture.numeroJournal}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {ecriture.dateEcriture.toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">
                    {ecriture.libelle}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {ecriture.reference}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                    {formatAmount(getTotalDebit(ecriture.lignes))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                    {formatAmount(getTotalCredit(ecriture.lignes))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(ecriture.statut)}`}>
                      {ecriture.statut}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedEcriture(ecriture)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-800">
                        <Edit className="h-4 w-4" />
                      </button>
                      {ecriture.statut === 'brouillon' && (
                        <button className="text-green-600 hover:text-green-800">
                          <Check className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Écriture Detail Modal */}
      {selectedEcriture && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Écriture {selectedEcriture.numeroJournal}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedEcriture.dateEcriture.toLocaleDateString('fr-FR')} - {selectedEcriture.reference}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedEcriture(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-2">Libellé</h4>
                <p className="text-gray-700">{selectedEcriture.libelle}</p>
              </div>

              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-4">Lignes d'écriture</h4>
                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Compte
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Intitulé
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                          Libellé
                        </th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                          Débit
                        </th>
                        <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">
                          Crédit
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {selectedEcriture.lignes.map((ligne) => (
                        <tr key={ligne.id}>
                          <td className="px-4 py-2 text-sm font-mono text-gray-900">
                            {ligne.compteNumero}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900">
                            {ligne.compteIntitule}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900">
                            {ligne.libelle}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                            {ligne.debit > 0 ? formatAmount(ligne.debit) : '-'}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                            {ligne.credit > 0 ? formatAmount(ligne.credit) : '-'}
                          </td>
                        </tr>
                      ))}
                      <tr className="bg-gray-50 font-medium">
                        <td colSpan={3} className="px-4 py-2 text-sm text-gray-900">
                          Total
                        </td>
                        <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                          {formatAmount(getTotalDebit(selectedEcriture.lignes))}
                        </td>
                        <td className="px-4 py-2 text-sm text-gray-900 text-right font-mono">
                          {formatAmount(getTotalCredit(selectedEcriture.lignes))}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-500">
                <span>Créé par {selectedEcriture.createdBy}</span>
                <span>Le {selectedEcriture.createdAt.toLocaleDateString('fr-FR')} à {selectedEcriture.createdAt.toLocaleTimeString('fr-FR')}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Ecriture Modal */}
      <NewEcritureModal
        isOpen={isNewEcritureModalOpen}
        onClose={() => setIsNewEcritureModalOpen(false)}
        onSave={handleSaveNewEcriture}
      />

      {filteredEcritures.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune écriture trouvée</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Commencez par créer votre première écriture comptable'}
          </p>
        </div>
      )}
    </div>
  );
}