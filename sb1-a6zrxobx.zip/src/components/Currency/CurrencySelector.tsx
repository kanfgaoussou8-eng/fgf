import React from 'react';
import { DollarSign, ChevronDown } from 'lucide-react';
import { CURRENCIES, type Currency } from '../../utils/currency';

interface CurrencySelectorProps {
  selectedCurrency: Currency;
  onCurrencyChange: (currency: Currency) => void;
  className?: string;
  showLabel?: boolean;
}

export default function CurrencySelector({ 
  selectedCurrency, 
  onCurrencyChange, 
  className = '',
  showLabel = true 
}: CurrencySelectorProps) {
  const selectedCurrencyInfo = CURRENCIES[selectedCurrency];

  return (
    <div className={`relative ${className}`}>
      {showLabel && (
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Devise
        </label>
      )}
      <div className="relative">
        <select
          value={selectedCurrency}
          onChange={(e) => onCurrencyChange(e.target.value as Currency)}
          className="w-full appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          {Object.values(CURRENCIES).map((currency) => (
            <option key={currency.code} value={currency.code}>
              {currency.flag} {currency.symbol} - {currency.name}
            </option>
          ))}
        </select>
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
          <ChevronDown className="h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      {/* Currency Info */}
      <div className="mt-2 flex items-center space-x-2 text-xs text-gray-500">
        <DollarSign className="h-3 w-3" />
        <span>{selectedCurrencyInfo.flag} {selectedCurrencyInfo.country}</span>
        <span>•</span>
        <span>{selectedCurrencyInfo.decimals} décimales</span>
      </div>
    </div>
  );
}