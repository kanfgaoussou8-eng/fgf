import React, { useState } from 'react';
import { ArrowRightLeft, Calculator, TrendingUp } from 'lucide-react';
import { CurrencyFormatter, CURRENCIES, EXCHANGE_RATES, type Currency } from '../../utils/currency';

interface CurrencyConverterProps {
  className?: string;
}

export default function CurrencyConverter({ className = '' }: CurrencyConverterProps) {
  const [amount, setAmount] = useState<string>('1000000');
  const [fromCurrency, setFromCurrency] = useState<Currency>('XOF');
  const [toCurrency, setToCurrency] = useState<Currency>('USD');

  const convertedAmount = amount ? 
    CurrencyFormatter.convertCurrency(parseFloat(amount), fromCurrency, toCurrency) : 0;

  const exchangeRate = EXCHANGE_RATES[toCurrency] / EXCHANGE_RATES[fromCurrency];

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-6 ${className}`}>
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-blue-50 rounded-lg">
          <Calculator className="h-5 w-5 text-blue-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Convertisseur de Devises</h3>
          <p className="text-sm text-gray-600">Conversion en temps réel</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Montant à convertir */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Montant à convertir
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Entrez le montant"
            min="0"
            step="0.01"
          />
        </div>

        {/* Devises */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              De
            </label>
            <select
              value={fromCurrency}
              onChange={(e) => setFromCurrency(e.target.value as Currency)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {Object.values(CURRENCIES).map((currency) => (
                <option key={currency.code} value={currency.code}>
                  {currency.flag} {currency.symbol} - {currency.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-center">
            <button
              onClick={swapCurrencies}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Inverser les devises"
            >
              <ArrowRightLeft className="h-5 w-5" />
            </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Vers
            </label>
            <select
              value={toCurrency}
              onChange={(e) => setToCurrency(e.target.value as Currency)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {Object.values(CURRENCIES).map((currency) => (
                <option key={currency.code} value={currency.code}>
                  {currency.flag} {currency.symbol} - {currency.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Résultat */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-600">Montant converti</div>
              <div className="text-2xl font-bold text-blue-600">
                {CurrencyFormatter.formatAmountWithSymbol(convertedAmount, toCurrency)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600">Taux de change</div>
              <div className="text-sm font-medium text-gray-900">
                {CurrencyFormatter.formatExchangeRate(fromCurrency, toCurrency)}
              </div>
            </div>
          </div>
        </div>

        {/* Taux de change actuels */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
            <TrendingUp className="h-4 w-4 mr-2 text-green-600" />
            Taux de change (base XOF)
          </h4>
          <div className="grid grid-cols-2 gap-3 text-xs">
            {Object.entries(EXCHANGE_RATES).map(([currency, rate]) => {
              if (currency === 'XOF') return null;
              const currencyInfo = CURRENCIES[currency as Currency];
              return (
                <div key={currency} className="flex items-center justify-between">
                  <span className="flex items-center space-x-1">
                    <span>{currencyInfo.flag}</span>
                    <span>{currencyInfo.symbol}</span>
                  </span>
                  <span className="font-mono">{rate.toFixed(4)}</span>
                </div>
              );
            })}
          </div>
          <div className="mt-2 text-xs text-gray-500">
            * Taux indicatifs - Consultez votre banque pour les taux officiels
          </div>
        </div>
      </div>
    </div>
  );
}