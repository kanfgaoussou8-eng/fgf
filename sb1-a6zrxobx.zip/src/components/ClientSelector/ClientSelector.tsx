import React, { useState } from 'react';
import { Building, ChevronDown, Check, Database, Users, Calendar } from 'lucide-react';
import type { Client } from '../../types';

interface ClientSelectorProps {
  clients: Client[];
  selectedClientId: string | null;
  onClientSelect: (clientId: string) => void;
  showDatabaseStatus?: boolean;
}

export default function ClientSelector({ 
  clients, 
  selectedClientId, 
  onClientSelect, 
  showDatabaseStatus = false 
}: ClientSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);

  const selectedClient = clients.find(c => c.id === selectedClientId);

  const getClientInitials = (nom: string) => {
    return nom.split(' ').map(word => word.charAt(0)).join('').substring(0, 2);
  };

  const getStatusColor = (statut: Client['statut']) => {
    switch (statut) {
      case 'actif': return 'bg-green-100 text-green-800';
      case 'inactif': return 'bg-gray-100 text-gray-800';
      case 'suspendu': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-left focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center justify-between">
          {selectedClient ? (
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-medium">
                {getClientInitials(selectedClient.nom)}
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900">{selectedClient.nom}</div>
                <div className="text-xs text-gray-500">{selectedClient.secteurActivite}</div>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-3">
              <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                <Building className="h-4 w-4 text-gray-400" />
              </div>
              <span className="text-gray-500">Sélectionner un client</span>
            </div>
          )}
          <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-80 overflow-y-auto">
          <div className="p-2">
            {clients.map((client) => (
              <button
                key={client.id}
                onClick={() => {
                  onClientSelect(client.id);
                  setIsOpen(false);
                }}
                className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm font-medium">
                    {getClientInitials(client.nom)}
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium text-gray-900">{client.nom}</div>
                    <div className="text-xs text-gray-500">{client.secteurActivite}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {showDatabaseStatus && (
                    <div className="flex items-center space-x-1">
                      <Database className="h-3 w-3 text-green-600" />
                      <span className="text-xs text-green-600">DB</span>
                    </div>
                  )}
                  <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(client.statut)}`}>
                    {client.statut}
                  </span>
                  {selectedClientId === client.id && (
                    <Check className="h-4 w-4 text-blue-600" />
                  )}
                </div>
              </button>
            ))}
          </div>
          
          {clients.length === 0 && (
            <div className="p-4 text-center text-gray-500">
              <Building className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">Aucun client disponible</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}