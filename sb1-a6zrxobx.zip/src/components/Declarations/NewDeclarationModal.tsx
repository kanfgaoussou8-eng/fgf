import React, { useState } from 'react';
import { X, Calendar, FileText, AlertTriangle, Save, Calculator, DollarSign } from 'lucide-react';
import type { DeclarationFiscale, Client } from '../../types';

interface NewDeclarationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (declaration: Omit<DeclarationFiscale, 'id'>) => void;
}

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  },
  {
    id: '3',
    nom: 'SARL AFRICAN TRADE',
    raisonSociale: 'SARL AFRICAN TRADE',
    secteurActivite: 'Import/Export',
    numeroContribuable: '34567890123456',
    adresse: 'Plateau, Abidjan',
    telephone: '+225 27 20 12 34 56',
    email: 'direction@africantrade.ci',
    dateCreation: new Date('2021-11-10'),
    responsableComptable: 'M. DIALLO',
    statut: 'actif'
  },
  {
    id: '4',
    nom: 'GIE TRANSPORT PLUS',
    raisonSociale: 'GIE TRANSPORT PLUS',
    secteurActivite: 'Transport et Logistique',
    numeroContribuable: '45678901234567',
    adresse: 'Yopougon, Abidjan',
    telephone: '+225 27 23 45 67 89',
    email: 'admin@transportplus.ci',
    dateCreation: new Date('2019-05-08'),
    responsableComptable: 'M. KONE',
    statut: 'actif'
  }
];

const typesDeclarations = [
  {
    value: 'tva',
    label: 'TVA (Taxe sur la Valeur Ajoutée)',
    description: 'Déclaration mensuelle de TVA',
    periodicite: 'mensuelle',
    echeance: 15, // 15 du mois suivant
    obligatoire: true
  },
  {
    value: 'impot-societe',
    label: 'Impôt sur les Sociétés (IS)',
    description: 'Déclaration annuelle d\'impôt sur les sociétés',
    periodicite: 'annuelle',
    echeance: 120, // 30 avril (120 jours après clôture)
    obligatoire: true
  },
  {
    value: 'patente',
    label: 'Patente',
    description: 'Contribution des patentes',
    periodicite: 'annuelle',
    echeance: 90, // 31 mars
    obligatoire: true
  },
  {
    value: 'cnss',
    label: 'CNSS (Caisse Nationale de Sécurité Sociale)',
    description: 'Déclaration des cotisations sociales',
    periodicite: 'mensuelle',
    echeance: 15, // 15 du mois suivant
    obligatoire: true
  },
  {
    value: 'bic',
    label: 'BIC (Bénéfices Industriels et Commerciaux)',
    description: 'Déclaration des bénéfices industriels et commerciaux',
    periodicite: 'annuelle',
    echeance: 120,
    obligatoire: false
  },
  {
    value: 'fdfp',
    label: 'FDFP (Fonds de Développement de la Formation Professionnelle)',
    description: 'Contribution formation professionnelle',
    periodicite: 'annuelle',
    echeance: 90,
    obligatoire: false
  }
];

const periodesTypes = {
  mensuelle: [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ],
  trimestrielle: ['T1', 'T2', 'T3', 'T4'],
  annuelle: ['Exercice']
};

export default function NewDeclarationModal({ isOpen, onClose, onSave }: NewDeclarationModalProps) {
  const [customTypes, setCustomTypes] = useState<Array<{
    value: string;
    label: string;
    description: string;
    periodicite: 'mensuelle' | 'trimestrielle' | 'annuelle';
    echeance: number;
    obligatoire: boolean;
    icon: string;
  }>>([]);

  const [showAddTypeForm, setShowAddTypeForm] = useState(false);
  const [newTypeData, setNewTypeData] = useState({
    label: '',
    description: '',
    periodicite: 'mensuelle' as 'mensuelle' | 'trimestrielle' | 'annuelle',
    echeance: 15,
    obligatoire: false
  });

  const [formData, setFormData] = useState({
    clientId: '',
    type: '',
    periode: '',
    exercice: new Date().getFullYear().toString(),
    dateEcheance: '',
    montant: '',
    observations: '',
    statut: 'a-faire' as DeclarationFiscale['statut']
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allDeclarationTypes = [...typesDeclarations, ...customTypes];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Calcul automatique de la date d'échéance selon le type de déclaration
    if (name === 'type' && value) {
      const typeDeclaration = allDeclarationTypes.find(t => t.value === value);
      if (typeDeclaration) {
        const today = new Date();
        const echeance = new Date();
        
        if (typeDeclaration.periodicite === 'mensuelle') {
          // Pour les déclarations mensuelles : 15 du mois suivant
          echeance.setMonth(today.getMonth() + 1);
          echeance.setDate(typeDeclaration.echeance);
        } else if (typeDeclaration.periodicite === 'annuelle') {
          // Pour les déclarations annuelles : selon le type
          if (value === 'impot-societe') {
            // IS : 30 avril de l'année suivante
            echeance.setFullYear(today.getFullYear() + 1);
            echeance.setMonth(3); // Avril (0-indexé)
            echeance.setDate(30);
          } else if (value === 'patente') {
            // Patente : 31 mars de l'année en cours
            echeance.setFullYear(today.getFullYear());
            echeance.setMonth(2); // Mars (0-indexé)
            echeance.setDate(31);
          }
        }
        
        setFormData(prev => ({
          ...prev,
          dateEcheance: echeance.toISOString().split('T')[0]
        }));
      }
    }

    // Génération automatique de la période selon le type
    if (name === 'type' && value) {
      const typeDeclaration = allDeclarationTypes.find(t => t.value === value);
      if (typeDeclaration?.periodicite === 'mensuelle') {
        const moisActuel = new Date().toLocaleDateString('fr-FR', { month: 'long' });
        const moisCapitalized = moisActuel.charAt(0).toUpperCase() + moisActuel.slice(1);
        setFormData(prev => ({
          ...prev,
          periode: `${moisCapitalized} ${prev.exercice}`
        }));
      } else if (typeDeclaration?.periodicite === 'annuelle') {
        setFormData(prev => ({
          ...prev,
          periode: `Exercice ${prev.exercice}`
        }));
      }
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleAddCustomType = () => {
    if (!newTypeData.label.trim() || !newTypeData.description.trim()) {
      alert('Veuillez remplir le nom et la description du type de déclaration');
      return;
    }

    const customType = {
      value: newTypeData.label.toLowerCase().replace(/\s+/g, '-'),
      label: newTypeData.label.trim(),
      description: newTypeData.description.trim(),
      periodicite: newTypeData.periodicite,
      echeance: newTypeData.echeance,
      obligatoire: newTypeData.obligatoire
    };

    setCustomTypes(prev => [...prev, customType]);
    setShowAddTypeForm(false);
    setNewTypeData({
      label: '',
      description: '',
      periodicite: 'mensuelle',
      echeance: 15,
      obligatoire: false,
      icon: '📋'
    });
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Champs obligatoires
    if (!formData.clientId) newErrors.clientId = 'Le client est obligatoire';
    if (!formData.type) newErrors.type = 'Le type de déclaration est obligatoire';
    if (!formData.periode.trim()) newErrors.periode = 'La période est obligatoire';
    if (!formData.dateEcheance) newErrors.dateEcheance = 'La date d\'échéance est obligatoire';

    // Validation du montant (optionnel mais si renseigné, doit être positif)
    if (formData.montant && parseFloat(formData.montant) < 0) {
      newErrors.montant = 'Le montant ne peut pas être négatif';
    }

    // Validation de la date d'échéance
    const dateEcheance = new Date(formData.dateEcheance);
    const today = new Date();
    const unAnAvant = new Date();
    unAnAvant.setFullYear(today.getFullYear() - 1);
    
    if (dateEcheance < unAnAvant) {
      newErrors.dateEcheance = 'La date d\'échéance ne peut pas être antérieure à un an';
    }

    // Validation de l'exercice
    const exercice = parseInt(formData.exercice);
    const anneeActuelle = new Date().getFullYear();
    if (exercice < anneeActuelle - 5 || exercice > anneeActuelle + 1) {
      newErrors.exercice = 'L\'exercice doit être entre ' + (anneeActuelle - 5) + ' et ' + (anneeActuelle + 1);
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const nouvelleDeclaration: Omit<DeclarationFiscale, 'id'> = {
        clientId: formData.clientId,
        type: formData.type as DeclarationFiscale['type'],
        periode: formData.periode.trim(),
        dateEcheance: new Date(formData.dateEcheance),
        statut: formData.statut,
        montant: formData.montant ? parseFloat(formData.montant) : undefined
      };

      onSave(nouvelleDeclaration);
      onClose();
      
      // Reset form
      setFormData({
        clientId: '',
        type: '',
        periode: '',
        exercice: new Date().getFullYear().toString(),
        dateEcheance: '',
        montant: '',
        obligatoire: false
      });
    } catch (error) {
      console.error('Erreur lors de la création de la déclaration:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatMontant = (montant: string) => {
    if (!montant) return '';
    const num = parseFloat(montant);
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XOF',
      minimumFractionDigits: 0
    }).format(num);
  };

  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : '';
  };

  const getTypeDeclaration = () => {
    return allDeclarationTypes.find(t => t.value === formData.type);
  };

  const isEcheanceProche = () => {
    if (!formData.dateEcheance) return false;
    const echeance = new Date(formData.dateEcheance);
    const today = new Date();
    const diffTime = echeance.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7 && diffDays > 0;
  };

  const isEnRetard = () => {
    if (!formData.dateEcheance) return false;
    const echeance = new Date(formData.dateEcheance);
    const today = new Date();
    return echeance < today;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Nouvelle Déclaration Fiscale</h3>
                <p className="text-sm text-gray-600">Planifier une nouvelle obligation fiscale</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Informations générales */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-blue-600" />
              Informations générales
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Client <span className="text-red-500">*</span>
                </label>
                <select
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.clientId ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Sélectionner un client</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.nom}</option>
                  ))}
                </select>
                {errors.clientId && <p className="text-red-500 text-xs mt-1">{errors.clientId}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Exercice fiscal
                </label>
                <input
                  type="number"
                  name="exercice"
                  value={formData.exercice}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.exercice ? 'border-red-300' : 'border-gray-300'
                  }`}
                  min={new Date().getFullYear() - 5}
                  max={new Date().getFullYear() + 1}
                />
                {errors.exercice && <p className="text-red-500 text-xs mt-1">{errors.exercice}</p>}
              </div>
            </div>
          </div>

          {/* Type de déclaration */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-green-600" />
              Type de déclaration
              <button
                type="button"
                onClick={() => setShowAddTypeForm(!showAddTypeForm)}
                className="ml-auto text-sm bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-1"
              >
                <span>+</span>
                <span>Ajouter un type</span>
              </button>
            </h4>
            
            {/* Formulaire d'ajout de type personnalisé */}
            {showAddTypeForm && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h5 className="font-medium text-green-900 mb-3">Ajouter un nouveau type de déclaration</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nom du type <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={newTypeData.label}
                      onChange={(e) => setNewTypeData(prev => ({ ...prev, label: e.target.value }))}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                      placeholder="Ex: Déclaration FDFP"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Description <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={newTypeData.description}
                      onChange={(e) => setNewTypeData(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                      placeholder="Description de la déclaration"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Périodicité
                    </label>
                    <select
                      value={newTypeData.periodicite}
                      onChange={(e) => setNewTypeData(prev => ({ ...prev, periodicite: e.target.value as any }))}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="mensuelle">Mensuelle</option>
                      <option value="trimestrielle">Trimestrielle</option>
                      <option value="annuelle">Annuelle</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Échéance (jours)
                    </label>
                    <input
                      type="number"
                      value={newTypeData.echeance}
                      onChange={(e) => setNewTypeData(prev => ({ ...prev, echeance: parseInt(e.target.value) || 15 }))}
                      className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                      min="1"
                      max="365"
                    />
                  </div>
                  <div className="md:col-span-2 flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={newTypeData.obligatoire}
                      onChange={(e) => setNewTypeData(prev => ({ ...prev, obligatoire: e.target.checked }))}
                      className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                    />
                    <label className="text-sm font-medium text-gray-700">
                      Déclaration obligatoire
                    </label>
                  </div>
                </div>
                <div className="flex items-center justify-end space-x-2 mt-4">
                  <button
                    type="button"
                    onClick={() => setShowAddTypeForm(false)}
                    className="px-3 py-1 text-sm border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                  >
                    Annuler
                  </button>
                  <button
                    type="button"
                    onClick={handleAddCustomType}
                    className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                  >
                    Ajouter
                  </button>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {allDeclarationTypes.map((type) => (
                <div
                  key={type.value}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    formData.type === type.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setFormData(prev => ({ ...prev, type: type.value }))}
                >
                  <div className="flex items-start">
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-900 flex items-center">
                        {type.label}
                        {type.obligatoire && (
                          <span className="ml-2 text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">
                            Obligatoire
                          </span>
                        )}
                        {!typesDeclarations.find(t => t.value === type.value) && (
                          <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                            Personnalisé
                          </span>
                        )}
                      </h5>
                      <p className="text-sm text-gray-600 mt-1">{type.description}</p>
                      <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                        <span>📅 {type.periodicite}</span>
                        <span>⏰ Échéance: {type.echeance} jours</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {errors.type && <p className="text-red-500 text-xs mt-2">{errors.type}</p>}
          </div>

          {/* Période et échéance */}
          {formData.type && (
            <div>
              <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-purple-600" />
                Période et échéance
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Période concernée <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="periode"
                    value={formData.periode}
                    onChange={handleInputChange}
                    className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.periode ? 'border-red-300' : 'border-gray-300'
                    }`}
                    placeholder="Ex: Janvier 2024, Exercice 2023"
                  />
                  {errors.periode && <p className="text-red-500 text-xs mt-1">{errors.periode}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Date d'échéance <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateEcheance"
                    value={formData.dateEcheance}
                    onChange={handleInputChange}
                    className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.dateEcheance ? 'border-red-300' : 'border-gray-300'
                    }`}
                  />
                  {errors.dateEcheance && <p className="text-red-500 text-xs mt-1">{errors.dateEcheance}</p>}
                  {isEcheanceProche() && (
                    <p className="text-orange-600 text-xs mt-1 flex items-center">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Échéance dans moins de 7 jours
                    </p>
                  )}
                  {isEnRetard() && (
                    <p className="text-red-600 text-xs mt-1 flex items-center">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Échéance dépassée
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Montant et statut */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-orange-600" />
              Montant et statut
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Montant estimé (FCFA)
                </label>
                <input
                  type="number"
                  name="montant"
                  value={formData.montant}
                  onChange={handleInputChange}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    errors.montant ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="0"
                  min="0"
                  step="1000"
                />
                {errors.montant && <p className="text-red-500 text-xs mt-1">{errors.montant}</p>}
                {formData.montant && (
                  <p className="text-sm text-gray-600 mt-1">
                    {formatMontant(formData.montant)}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  Montant optionnel, peut être mis à jour lors du dépôt
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Statut initial
                </label>
                <select
                  name="statut"
                  value={formData.statut}
                  onChange={handleInputChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="a-faire">À faire</option>
                  <option value="en-cours">En cours de préparation</option>
                </select>
              </div>
            </div>
          </div>

          {/* Observations */}
          <div>
            <h4 className="text-lg font-medium text-gray-900 mb-4">Observations</h4>
            <textarea
              name="observations"
              value={formData.observations}
              onChange={handleInputChange}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Notes particulières, documents requis, etc."
            />
          </div>

          {/* Résumé */}
          {formData.clientId && formData.type && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Résumé de la déclaration</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Client:</span>
                  <span className="ml-2 font-bold text-blue-600">
                    {getClientName(formData.clientId)}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Type:</span>
                  <span className="ml-2 font-bold text-green-600">
                    {getTypeDeclaration()?.label}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Période:</span>
                  <span className="ml-2 font-bold text-purple-600">
                    {formData.periode}
                  </span>
                </div>
              </div>
              {formData.dateEcheance && (
                <div className="mt-2 text-sm">
                  <span className="text-gray-600">Échéance: </span>
                  <span className={`font-medium ${
                    isEnRetard() ? 'text-red-600' : isEcheanceProche() ? 'text-orange-600' : 'text-gray-900'
                  }`}>
                    {new Date(formData.dateEcheance).toLocaleDateString('fr-FR')}
                  </span>
                  {isEnRetard() && <span className="ml-2 text-red-600">⚠️ En retard</span>}
                  {isEcheanceProche() && !isEnRetard() && <span className="ml-2 text-orange-600">⏰ Urgent</span>}
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              <span>{isSubmitting ? 'Création...' : 'Créer la déclaration'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}