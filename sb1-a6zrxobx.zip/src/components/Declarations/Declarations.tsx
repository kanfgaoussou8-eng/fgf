import React, { useState } from 'react';
import { Plus, Search, Filter, Calendar, AlertTriangle, CheckCircle, Clock, FileText, Send } from 'lucide-react';
import type { DeclarationFiscale, Client } from '../../types';
import NewDeclarationModal from './NewDeclarationModal';
import { useCurrency } from '../../contexts/CurrencyContext';

const mockClients: Client[] = [
  {
    id: '1',
    nom: 'SARL TEKNO SERVICES',
    raisonSociale: 'SARL TEKNO SERVICES',
    secteurActivite: 'Informatique et Services',
    numeroContribuable: '12345678901234',
    adresse: 'Cocody, Abidjan',
    telephone: '+225 27 22 44 55 66',
    email: 'contact@teknoservices.ci',
    dateCreation: new Date('2020-03-15'),
    responsableComptable: 'M. KOUAME',
    statut: 'actif'
  },
  {
    id: '2',
    nom: 'ETS MAMADOU COMMERCE',
    raisonSociale: 'ETS MAMADOU COMMERCE',
    secteurActivite: 'Commerce général',
    numeroContribuable: '23456789012345',
    adresse: 'Marcory, Abidjan',
    telephone: '+225 27 21 33 44 55',
    email: 'info@mamadoucommerce.ci',
    dateCreation: new Date('2018-07-22'),
    responsableComptable: 'Mme TRAORE',
    statut: 'actif'
  }
];

const mockDeclarations: DeclarationFiscale[] = [
  {
    id: '1',
    clientId: '1',
    type: 'tva',
    periode: 'Janvier 2024',
    dateEcheance: new Date('2024-02-15'),
    statut: 'deposee',
    montant: 3600000
  },
  {
    id: '2',
    clientId: '1',
    type: 'impot-societe',
    periode: 'Exercice 2023',
    dateEcheance: new Date('2024-04-30'),
    statut: 'en-cours',
    montant: 8500000
  },
  {
    id: '3',
    clientId: '2',
    type: 'tva',
    periode: 'Janvier 2024',
    dateEcheance: new Date('2024-02-15'),
    statut: 'retard',
    montant: 2100000
  },
  {
    id: '4',
    clientId: '2',
    type: 'cnss',
    periode: 'Janvier 2024',
    dateEcheance: new Date('2024-02-15'),
    statut: 'a-faire'
  },
  {
    id: '5',
    clientId: '1',
    type: 'patente',
    periode: '2024',
    dateEcheance: new Date('2024-03-31'),
    statut: 'a-faire',
    montant: 1200000
  }
];

const typeLabels = {
  'tva': 'TVA',
  'impot-societe': 'Impôt sur les Sociétés',
  'patente': 'Patente',
  'cnss': 'CNSS'
};

export default function Declarations() {
  const { formatAmount } = useCurrency();
  const [declarations, setDeclarations] = useState<DeclarationFiscale[]>(mockDeclarations);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('tous');
  const [filterType, setFilterType] = useState<string>('tous');
  const [isNewDeclarationModalOpen, setIsNewDeclarationModalOpen] = useState(false);

  const filteredDeclarations = declarations.filter(declaration => {
    const client = mockClients.find(c => c.id === declaration.clientId);
    const clientName = client ? client.nom : '';
    
    const matchesSearch = clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         declaration.periode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'tous' || declaration.statut === filterStatus;
    const matchesType = filterType === 'tous' || declaration.type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (statut: DeclarationFiscale['statut']) => {
    switch (statut) {
      case 'a-faire':
        return { class: 'bg-gray-100 text-gray-800', icon: Clock, label: 'À faire' };
      case 'en-cours':
        return { class: 'bg-blue-100 text-blue-800', icon: FileText, label: 'En cours' };
      case 'deposee':
        return { class: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Déposée' };
      case 'retard':
        return { class: 'bg-red-100 text-red-800', icon: AlertTriangle, label: 'En retard' };
      default:
        return { class: 'bg-gray-100 text-gray-800', icon: Clock, label: 'À faire' };
    }
  };


  const getClientName = (clientId: string) => {
    const client = mockClients.find(c => c.id === clientId);
    return client ? client.nom : 'Client inconnu';
  };

  const getDeclarationsEnRetard = () => {
    const today = new Date();
    return declarations.filter(d => d.dateEcheance < today && d.statut !== 'deposee').length;
  };

  const getDeclarationsAFaire = () => {
    return declarations.filter(d => d.statut === 'a-faire').length;
  };

  const getDeclarationsEnCours = () => {
    return declarations.filter(d => d.statut === 'en-cours').length;
  };

  const getDeclarationsDeposees = () => {
    return declarations.filter(d => d.statut === 'deposee').length;
  };

  const isEcheanceProche = (dateEcheance: Date) => {
    const today = new Date();
    const diffTime = dateEcheance.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7 && diffDays > 0;
  };

  const handleSaveNewDeclaration = (newDeclarationData: Omit<DeclarationFiscale, 'id'>) => {
    const newDeclaration: DeclarationFiscale = {
      ...newDeclarationData,
      id: (declarations.length + 1).toString()
    };
    setDeclarations(prev => [...prev, newDeclaration]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Déclarations Fiscales</h3>
          <p className="text-sm text-gray-600 mt-1">
            Suivi des déclarations TVA, IS, CNSS et autres obligations fiscales
          </p>
        </div>
        <button
          onClick={() => setIsNewDeclarationModalOpen(true)}
          onClick={() => setIsNewDeclarationModalOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nouvelle déclaration</span>
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">À faire</p>
              <p className="text-2xl font-bold text-gray-900">{getDeclarationsAFaire()}</p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <Clock className="h-6 w-6 text-gray-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">En cours</p>
              <p className="text-2xl font-bold text-gray-900">{getDeclarationsEnCours()}</p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Déposées</p>
              <p className="text-2xl font-bold text-gray-900">{getDeclarationsDeposees()}</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">En retard</p>
              <p className="text-2xl font-bold text-red-600">{getDeclarationsEnRetard()}</p>
            </div>
            <div className="p-3 bg-red-50 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par client ou période..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les types</option>
              <option value="tva">TVA</option>
              <option value="impot-societe">Impôt sur les Sociétés</option>
              <option value="patente">Patente</option>
              <option value="cnss">CNSS</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="tous">Tous les statuts</option>
              <option value="a-faire">À faire</option>
              <option value="en-cours">En cours</option>
              <option value="deposee">Déposées</option>
              <option value="retard">En retard</option>
            </select>
          </div>
        </div>
      </div>

      {/* Declarations Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Période
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Échéance
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Montant
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDeclarations.map((declaration) => {
                const statusInfo = getStatusBadge(declaration.statut);
                const StatusIcon = statusInfo.icon;
                const echeanceProche = isEcheanceProche(declaration.dateEcheance);
                
                return (
                  <tr key={declaration.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {getClientName(declaration.clientId)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                        {typeLabels[declaration.type as keyof typeof typeLabels]}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {declaration.periode}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        {declaration.dateEcheance.toLocaleDateString('fr-FR')}
                        {echeanceProche && (
                          <AlertTriangle className="h-4 w-4 ml-2 text-orange-500" />
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-mono">
                      {declaration.montant ? formatAmount(declaration.montant) : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full ${statusInfo.class}`}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {statusInfo.label}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center space-x-2">
                        {declaration.statut === 'a-faire' && (
                          <button className="text-blue-600 hover:text-blue-800">
                            <FileText className="h-4 w-4" />
                          </button>
                        )}
                        {declaration.statut === 'en-cours' && (
                          <button className="text-green-600 hover:text-green-800">
                            <Send className="h-4 w-4" />
                          </button>
                        )}
                        <button className="text-gray-600 hover:text-gray-800">
                          <Calendar className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Échéances proches */}
      {declarations.some(d => isEcheanceProche(d.dateEcheance)) && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-orange-600 mr-2" />
            <h4 className="font-medium text-orange-800">Échéances proches</h4>
          </div>
          <div className="mt-2 text-sm text-orange-700">
            Certaines déclarations arrivent à échéance dans les 7 prochains jours.
          </div>
        </div>
      )}

      {/* New Declaration Modal */}
      <NewDeclarationModal
        isOpen={isNewDeclarationModalOpen}
        onClose={() => setIsNewDeclarationModalOpen(false)}
        onSave={handleSaveNewDeclaration}
      />
      {isNewDeclarationModalOpen && (
        <NewDeclarationModal
          isOpen={isNewDeclarationModalOpen}
          onClose={() => setIsNewDeclarationModalOpen(false)}
          onSave={handleSaveNewDeclaration}
        />
      )}

      {filteredDeclarations.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune déclaration trouvée</h3>
          <p className="text-gray-600">
            {searchTerm ? 'Essayez de modifier vos critères de recherche' : 'Aucune déclaration à afficher'}
          </p>
        </div>
      )}
    </div>
  );
}