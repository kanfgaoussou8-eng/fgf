import { useState, useEffect } from 'react';
import { useClientDatabase } from '../lib/supabase';
import type { CompteComptable, EcritureComptable, Immobilisation, Facture, DeclarationFiscale } from '../types';

interface MouvementTresorerie {
  id: string;
  clientId: string;
  date: Date;
  libelle: string;
  type: 'recette' | 'depense';
  categorie: string;
  montant: number;
  modePaiement: string;
  statut: string;
  tiers?: string;
}

export function useClientData(clientId: string) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // États pour chaque type de données
  const [comptes, setComptes] = useState<CompteComptable[]>([]);
  const [ecritures, setEcritures] = useState<EcritureComptable[]>([]);
  const [immobilisations, setImmobilisations] = useState<Immobilisation[]>([]);
  const [factures, setFactures] = useState<Facture[]>([]);
  const [declarations, setDeclarations] = useState<DeclarationFiscale[]>([]);
  const [mouvementsTresorerie, setMouvementsTresorerie] = useState<MouvementTresorerie[]>([]);

  const clientDb = useClientDatabase(clientId);

  // Charger toutes les données du client
  const loadAllData = async () => {
    if (!clientId) return;

    setLoading(true);
    setError(null);

    try {
      // Charger en parallèle toutes les données
      const [
        comptesResult,
        ecrituresResult,
        immobilisationsResult,
        facturesResult,
        declarationsResult,
        tresorerieResult
      ] = await Promise.all([
        clientDb.getComptes(),
        clientDb.getEcritures(),
        clientDb.getImmobilisations(),
        clientDb.getFactures(),
        clientDb.getDeclarations(),
        clientDb.getMouvementsTresorerie()
      ]);

      // Vérifier les erreurs
      if (comptesResult.error) throw comptesResult.error;
      if (ecrituresResult.error) throw ecrituresResult.error;
      if (immobilisationsResult.error) throw immobilisationsResult.error;
      if (facturesResult.error) throw facturesResult.error;
      if (declarationsResult.error) throw declarationsResult.error;
      if (tresorerieResult.error) throw tresorerieResult.error;

      // Mettre à jour les états
      setComptes(comptesResult.data || []);
      setEcritures(ecrituresResult.data || []);
      setImmobilisations(immobilisationsResult.data || []);
      setFactures(facturesResult.data || []);
      setDeclarations(declarationsResult.data || []);
      setMouvementsTresorerie(tresorerieResult.data || []);

    } catch (err) {
      console.error('Erreur lors du chargement des données client:', err);
      setError(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setLoading(false);
    }
  };

  // Recharger les données quand le client change
  useEffect(() => {
    loadAllData();
  }, [clientId]);

  // Méthodes pour créer de nouvelles données
  const createCompte = async (compte: Omit<CompteComptable, 'numero'>) => {
    try {
      const { data, error } = await clientDb.createCompte(compte);
      if (error) throw error;
      
      // Recharger les comptes
      const { data: updatedComptes } = await clientDb.getComptes();
      setComptes(updatedComptes || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création du compte:', err);
      return { success: false, error: err };
    }
  };

  const createEcriture = async (ecriture: Omit<EcritureComptable, 'id'>) => {
    try {
      const { data, error } = await clientDb.createEcriture(ecriture);
      if (error) throw error;
      
      // Recharger les écritures
      const { data: updatedEcritures } = await clientDb.getEcritures();
      setEcritures(updatedEcritures || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création de l\'écriture:', err);
      return { success: false, error: err };
    }
  };

  const createImmobilisation = async (immobilisation: Omit<Immobilisation, 'id'>) => {
    try {
      const { data, error } = await clientDb.createImmobilisation(immobilisation);
      if (error) throw error;
      
      // Recharger les immobilisations
      const { data: updatedImmobilisations } = await clientDb.getImmobilisations();
      setImmobilisations(updatedImmobilisations || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création de l\'immobilisation:', err);
      return { success: false, error: err };
    }
  };

  const createFacture = async (facture: Omit<Facture, 'id'>) => {
    try {
      const { data, error } = await clientDb.createFacture(facture);
      if (error) throw error;
      
      // Recharger les factures
      const { data: updatedFactures } = await clientDb.getFactures();
      setFactures(updatedFactures || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création de la facture:', err);
      return { success: false, error: err };
    }
  };

  const createDeclaration = async (declaration: Omit<DeclarationFiscale, 'id'>) => {
    try {
      const { data, error } = await clientDb.createDeclaration(declaration);
      if (error) throw error;
      
      // Recharger les déclarations
      const { data: updatedDeclarations } = await clientDb.getDeclarations();
      setDeclarations(updatedDeclarations || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création de la déclaration:', err);
      return { success: false, error: err };
    }
  };

  const createMouvementTresorerie = async (mouvement: Omit<MouvementTresorerie, 'id'>) => {
    try {
      const { data, error } = await clientDb.createMouvementTresorerie(mouvement);
      if (error) throw error;
      
      // Recharger les mouvements
      const { data: updatedMouvements } = await clientDb.getMouvementsTresorerie();
      setMouvementsTresorerie(updatedMouvements || []);
      
      return { success: true, data };
    } catch (err) {
      console.error('Erreur lors de la création du mouvement:', err);
      return { success: false, error: err };
    }
  };

  // Statistiques calculées
  const getStatistics = () => {
    const totalImmobilisations = immobilisations.reduce((sum, immo) => sum + immo.valeurNetteComptable, 0);
    const totalFactures = factures.reduce((sum, facture) => sum + facture.montantTTC, 0);
    const totalRecettes = mouvementsTresorerie
      .filter(m => m.type === 'recette')
      .reduce((sum, m) => sum + m.montant, 0);
    const totalDepenses = mouvementsTresorerie
      .filter(m => m.type === 'depense')
      .reduce((sum, m) => sum + m.montant, 0);

    return {
      nombreComptes: comptes.length,
      nombreEcritures: ecritures.length,
      nombreImmobilisations: immobilisations.length,
      nombreFactures: factures.length,
      nombreDeclarations: declarations.length,
      nombreMouvements: mouvementsTresorerie.length,
      totalImmobilisations,
      totalFactures,
      totalRecettes,
      totalDepenses,
      soldeTresorerie: totalRecettes - totalDepenses
    };
  };

  return {
    // États
    loading,
    error,
    comptes,
    ecritures,
    immobilisations,
    factures,
    declarations,
    mouvementsTresorerie,
    
    // Méthodes de création
    createCompte,
    createEcriture,
    createImmobilisation,
    createFacture,
    createDeclaration,
    createMouvementTresorerie,
    
    // Utilitaires
    loadAllData,
    getStatistics
  };
}